package com.customlibraries.adsutils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;

import com.customlibraries.loadads.LoadAds;
import com.customlibraries.loadads.R;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;

import java.util.Random;

import androidx.cardview.widget.CardView;

public class AdsUtils {
    private static String TAG = AdsUtils.class.getSimpleName();
    public static boolean isAppAdsFree = false;

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static boolean isEmptyVal(String text) {
        return (text == null || text.equals("") || text.trim().equals("null") || text.trim().length() == 0);
    }

    public static void loadInterstitialAds(Activity activity, boolean isRandomAds) {
        Log.e(TAG, "loadInterstitialAds:0000 " + activity.getLocalClassName());
        if (!isAppAdsFree) {
            if (isNetworkAvailable(activity)) {
                if (isRandomAds) {
                    int randomVal = getRandomNumber(1, 3);
                    Log.e(TAG, "RANDOM_VAL >>>>> " + "" + randomVal);
                    if (randomVal == 1) {
                        showInterstitialAds(activity);
                    }
                } else {
                    showInterstitialAds(activity);
                }
            }
        }
    }

    public static void loadBannerAds(Activity activity, FrameLayout frameBannerAd) {
        if (!isAppAdsFree && activity != null) {
            LoadAds.getInstance(activity)
                    .showBannerAd(activity, frameBannerAd, LoadAds.strAdaptiveBannerAdsId);
        }
    }

    public static void loadMediumBannerSizedListNativeAd(Activity activity, FrameLayout frameNativeLayout) {
        if (!isAppAdsFree && activity != null) {
            LoadAds.getInstance(activity)
                    .loadMediumBannerSizedListNativeAd(activity, frameNativeLayout);
        }
    }

    public static void loadRateUSNativeAd(Activity activity, LoadAds.AdEventListener adEventListener) {
        if (!isAppAdsFree && activity != null) {
//            LoadAds.getInstance(activity).LoadNativeRateAd(activity, adEventListener, LoadAds.strNativeAdsId_1);
            LoadAds.getInstance(activity).LoadNativeAd(activity, LoadAds.strNativeAdsId_1,adEventListener);

        }
    }

    public static void populateNativeRateUsAdView(Activity activity, NativeAd nativeRateAd, NativeAdView adView, FrameLayout adsFrameLayout) {
        if (!isAppAdsFree && activity != null) {
//            LoadAds.getInstance(activity).populateUnifiedNativeAdView(nativeRateAd, adView, true);
            LoadAds.getInstance(activity).populateUnifiedNativeAdView(activity,adsFrameLayout,nativeRateAd, true, true);

//            if (adsFrameLayout != null) {
//                adsFrameLayout.removeAllViews();
//                adsFrameLayout.addView(adView);
//                adsFrameLayout.setVisibility(View.VISIBLE);
//            }


        }
    }

    public static void loadOneTimeFetchOnlyNativeAd(Activity activity, AdsEnum.AdsPageType adsPageType, ShimmerFrameLayout mShimmerViewContainer, LoadAds.AdEventListener adEventListener) {
        if (!isAppAdsFree && activity != null) {
            LoadAds.getInstance(activity).loadOneTimeFetchOnlyNativeAd(activity, adsPageType, mShimmerViewContainer, adEventListener);
        }
    }

    public static void checkAndLoadOneTimeFetchOnlyNativeAds(Activity activity, AdsEnum.AdsPageType adsPageType, CardView cardView, ShimmerFrameLayout mShimmerViewContainer, FrameLayout adsFrameLayout) {
        if (!isAppAdsFree && activity != null) {
            LoadAds loadAds = LoadAds.getInstance(activity);
            LayoutInflater inflater = activity.getLayoutInflater();
            NativeAdView adView = (NativeAdView) inflater.inflate(R.layout.layout_big_native_ad_mob, null);

            NativeAd mNativeRateAd = null;
            if (adsPageType == AdsEnum.AdsPageType.NATIVE_ADS_SEARCH) {
                mNativeRateAd = loadAds.mNativeSearchPageAds;
            } else if (adsPageType == AdsEnum.AdsPageType.NATIVE_ADS_SETTINGS) {
                mNativeRateAd = loadAds.mNativeSettingsPageAds;
            }

            if (mNativeRateAd != null) {
                populateOneTimeFetchOnlyNativeAdView(activity, mShimmerViewContainer, mNativeRateAd, adView, cardView, adsFrameLayout);
            } else {
                loadOneTimeFetchOnlyNativeAd(activity, adsPageType, mShimmerViewContainer, new LoadAds.AdEventListener() {
                    @Override
                    public void onAdLoaded(Object object) {
                        populateOneTimeFetchOnlyNativeAdView(activity, mShimmerViewContainer, (NativeAd) object, adView, cardView, adsFrameLayout);
                        cardView.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onAdClosed() {
                        cardView.setVisibility(View.GONE);
                    }

                    @Override
                    public void onLoadError(String errorCode) {
                        cardView.setVisibility(View.GONE);
                    }
                });
            }
        } else {
            cardView.setVisibility(View.GONE);
        }
    }

    public static void populateOneTimeFetchOnlyNativeAdView(Activity activity, ShimmerFrameLayout mShimmerViewContainer, NativeAd nativeRateAd, NativeAdView adView, CardView cardView, FrameLayout adsFrameLayout) {
        if (!isAppAdsFree && activity != null) {
            LoadAds.getInstance(activity).populateUnifiedNativeAdView(nativeRateAd, adView, true);
            LoadAds.getInstance(activity).showHideShimmerLayout(mShimmerViewContainer, false);

            if (adsFrameLayout != null) {
                adsFrameLayout.removeAllViews();
                adsFrameLayout.addView(adView);
                adsFrameLayout.setVisibility(View.VISIBLE);
                cardView.setVisibility(View.VISIBLE);
            }
        }
    }

    public static void loadLargerThanLargeSizedNativeAd(Activity activity, FrameLayout frameNativeLayout) {
        if (!isAppAdsFree && activity != null) {
            LoadAds.getInstance(activity)
                    .loadLargerThanMediumSizedNativeAd(activity, frameNativeLayout, false, true, LoadAds.strNativeAdsId_1);
        }
    }

    public static void loadLargerThanMediumSizedNativeAdWithCard(Activity activity, FrameLayout frameNativeLayout) {
        if (!isAppAdsFree && activity != null) {
            LoadAds.getInstance(activity)
                    .loadLargerThanMediumSizedNativeAd1(activity, frameNativeLayout, false, false, LoadAds.strNativeAdsId_1);
        }
    }


    public static void showInterstitialAds(Activity activity) {
        try {
            Log.e(TAG, "LOAD_ADS >>>0000 " + LoadAds.getInstance(activity).isAdLoad());
            if (LoadAds.getInstance(activity).isAdLoad()) {
                showFinalAds(activity);
            } else {
                LoadAds.getInstance(activity).setShowInterstitialAdListener(new LoadAds.ShowInterstitialAdListener() {
                    @Override
                    public void showInterstitialAd(Activity activity1) {
                        Log.e(TAG, "showInterstitialAd:==== " + activity.getLocalClassName());
                        Log.e(TAG, "showInterstitialAd:====activity1 " + activity1.getLocalClassName());
                            showFinalAds(activity);
                        //dismissProgressDialog(activity);
                        //LoadAds.getInstance(activity).showInterstitialAd(activity);
                    }

                    @Override
                    public void dismissInterstitialAd(Activity activity1) {
                        Log.e(TAG, "dismissInterstitialAd: ");
                        dismissProgressDialog(activity);
                        //Log.e(TAG, "DISMISS_FINAL_ADS");
                    }
                });
            }

            new Handler().postDelayed(() -> dismissProgressDialog(activity), 3000);
        } catch (Exception e) {
            e.printStackTrace();
            dismissProgressDialog(activity);
        }
    }

    private static void showFinalAds(Activity activity) {
        Log.e(TAG, "showFinalAds:---- " + activity.getLocalClassName());
        showProgressDialog(activity);

        new Handler(Looper.myLooper()).postDelayed(() -> {
            Log.e(TAG, "showFinalAds:----11>>> " + activity.getLocalClassName());
            dismissProgressDialog(activity);
            LoadAds.getInstance(activity).showInterstitialAd(activity);
        }, 1000);
        //Log.e(TAG, "SHOW_FINAL_ADS");
    }

    public static int getRandomNumber(int min, int max) {
        Random r = new Random();
        return r.nextInt(max - min + 1) + min;
    }

    private static ProgressDialog progress;

    public static void showProgressDialog(Activity activity) {
        try {
            if (activity != null) {
                Log.e(TAG, "SHOW_FINAL_ADS >>> " + "showProgressDialog SHOW_PROGRESS_DIALOG >>> " + activity.getLocalClassName());

                progress = new ProgressDialog(activity);
                progress.setMessage("Ad Showing....");
                progress.setCancelable(true);
                progress.setIndeterminate(true);
                progress.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void dismissProgressDialog(Activity activity) {
        if (activity != null && !activity.isFinishing()) {
            Log.e(TAG, "dismissProgressDialog:=== " + activity.getLocalClassName());
            try {
                if (activity != null) {
                    if (progress != null && progress.isShowing()) {
                        progress.dismiss();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
