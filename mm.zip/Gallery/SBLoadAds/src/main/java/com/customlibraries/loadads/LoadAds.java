package com.customlibraries.loadads;

import static com.customlibraries.adsutils.AdsUtils.isNetworkAvailable;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.customlibraries.adsutils.AdsEnum;
import com.customlibraries.adsutils.AdsUtils;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;

public class LoadAds {
    private static final String TAG = LoadAds.class.getSimpleName();
    Activity activity;

    public InterstitialAd interstitialAd;
    public NativeAd nativeAd;
    public NativeAd openNativeAd;

    public static LoadAds loadAds;

    //    boolean isShowNativeAdx = false;
//    boolean isShowNativeBanner = false;
//    boolean isShowInterstitialAdx = false;
    boolean isAdLoad = false;

    private AdView adMobAdView;
    //private com.facebook.ads.AdView adView;
    Handler handler = new Handler(Looper.myLooper());

    ShowInterstitialAdListener showInterstitialAdListener = null;
    ShowNativeAdListener showNativeAdListener;
    public static String strAdaptiveBannerAdsId = "";
    public static String strInterstitialAdsId = "";
    public static String strNativeAdsId_1 = "";


    public String adxBannerAdsId = "";
    public String adxInterstitialAdsId = "";
    public String adxNativeAdsId_1 = "";


    public LoadAds(Activity activity) {
        this.activity = activity;
    }

    public void setAllAdsIds(String strAdaptiveBannerAdsId, String strInterstitialAdsId, String strNativeAdsId_1, String adxBannerAdsId, String adxInterstitialAdsId, String adxNativeAdsId_1) {
        this.strAdaptiveBannerAdsId = strAdaptiveBannerAdsId;
        this.strInterstitialAdsId = strInterstitialAdsId;
        this.strNativeAdsId_1 = strNativeAdsId_1;
        this.adxBannerAdsId = adxBannerAdsId;
        this.adxInterstitialAdsId = adxInterstitialAdsId;
        this.adxNativeAdsId_1 = adxInterstitialAdsId;
    }

    public static LoadAds getInstance(Activity activity1) {

        if (loadAds == null) {
            loadAds = new LoadAds(activity1);
        }
        return loadAds;
    }

    public void setShowInterstitialAdListener(ShowInterstitialAdListener showInterstitialAdListener) {
        this.showInterstitialAdListener = showInterstitialAdListener;
    }

    public void setShowNativeAdListener(ShowNativeAdListener showNativeAdListener) {
        this.showNativeAdListener = showNativeAdListener;
    }

    public boolean isAdLoad() {
        return isAdLoad;
    }

    public void loadInterstitialAd(Activity activity, String interstitialAdId) {
        if (!AdsUtils.isAppAdsFree) {
            if (isNetworkAvailable(activity)) {
                AdRequest adRequest = new AdRequest.Builder().build();
//                InterstitialAd.load(activity, strInterstitialAdsId, adRequest, new InterstitialAdLoadCallback() {
                InterstitialAd.load(activity, interstitialAdId, adRequest, new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAds) {
                        super.onAdLoaded(interstitialAds);
                        isAdLoad = true;
                        //Log.e(TAG,"SUCCESS >>> ");

                        interstitialAd = null;

                        interstitialAd = interstitialAds;
                        if (showInterstitialAdListener != null) {
                            Log.e(TAG, "onAdLoaded: 11");
                            showInterstitialAdListener.showInterstitialAd(activity);
                            showInterstitialAdListener = null;
                        }
                        setInterstitialAdListener(interstitialAdId);
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        Log.e(TAG, "FAILED >>> " + loadAdError.getMessage() + " CODE >>> " + loadAdError.getCode());
                        if (!interstitialAdId.equalsIgnoreCase(adxInterstitialAdsId)) {
                            interstitialAd = null;
                            loadInterstitialAd(activity, adxInterstitialAdsId);
                        } else {
                            dismissInterstitialAd();
                        }
                    }
                });
            }
        }
    }

    public void setInterstitialAdListener(String adId) {
        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                super.onAdDismissedFullScreenContent();
                //constant.SHOW_OPEN_ADS = true;
                dismissInterstitialAd();
                interstitialAd = null;
                loadInterstitialAd(activity, adId);
            }

            @Override
            public void onAdFailedToShowFullScreenContent(AdError adError) {
                //Log.e(TAG,"FAILED >>> "+adError.getMessage() + " CODE >>> "+adError.getCode());
                super.onAdFailedToShowFullScreenContent(adError);
//                loadInterstitialNativeAd(activity);
                loadInterstitialAd(activity, adId);
            }
        });
    }

    private void dismissInterstitialAd() {
        if (showInterstitialAdListener != null) {
            showInterstitialAdListener.dismissInterstitialAd(activity);
            showInterstitialAdListener = null;
        }
    }

    private void dismissNativeAd() {
        if (showNativeAdListener != null) {
            showNativeAdListener.dismissNativeAd(activity);
            showNativeAdListener = null;
        }
    }

    private void showNativeAd() {
        if (showNativeAdListener != null) {
            showNativeAdListener.showNativeAd(activity);
        }
    }

    public void showInterstitialAd(Activity activity) {
        if (interstitialAd != null) {
            interstitialAd.show(activity);
        }/* else if (nativeAd != null) {
            activity.startActivity(new Intent(activity, NativeAdScreen.class));
        }*/
    }

    private static ProgressDialog progressNew;

    public static void showProgressDialogNew(Activity activity) {
        Log.e(TAG, "SHOW_FINAL_ADS >>> " + " SHOW_PROGRESS_DIALOG >>> " + activity.getLocalClassName());
        try {
            if (activity != null) {
                progressNew = new ProgressDialog(activity);
                progressNew.setMessage("Ad Showing....");
                progressNew.setCancelable(true);
                progressNew.setIndeterminate(true);
                progressNew.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void dismissProgressDialogNew(Activity activity) {
        if (activity != null && !activity.isFinishing()) {
            Log.e(TAG, "dismissProgressDialog:=== " + activity.getLocalClassName());
            try {
                if (activity != null) {
                    if (progressNew != null && progressNew.isShowing()) {
                        progressNew.dismiss();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public InterstitialAd getInterstitialAd() {
        return interstitialAd;
    }

    public void showBannerAd(Activity activity, FrameLayout adContainerView, String bannerAdId) {
        if (!AdsUtils.isAppAdsFree) {
            if (isNetworkAvailable(activity)) {
                AdView adView = new AdView(activity);
                adView.setAdSize(getAdSize(activity, adContainerView));


//                adView.setAdUnitId(strAdaptiveBannerAdsId);
                adView.setAdUnitId(bannerAdId);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);
                adContainerView.removeAllViews();
                adContainerView.addView(adView);

                adView.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        if (!bannerAdId.equalsIgnoreCase(adxBannerAdsId)) {
                            showBannerAd(activity, adContainerView, adxBannerAdsId);
                        } else {
                            dismissInterstitialAd();
                        }

                    }

                    @Override
                    public void onAdOpened() {
                        super.onAdOpened();
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                    }

                    @Override
                    public void onAdClicked() {
                        super.onAdClicked();
                    }

                    @Override
                    public void onAdImpression() {
                        super.onAdImpression();
                    }
                });
            }
        }
    }

    public AdSize getAdSize(Activity context, FrameLayout adContainerView) {
        Display display = ((Activity) context).getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float density = outMetrics.density;

        float adWidthPixels = adContainerView.getWidth();
        if (adWidthPixels == 0) {
            adWidthPixels = outMetrics.widthPixels;
        }

        int adWidth = (int) (adWidthPixels / density);

        return AdSize.getPortraitAnchoredAdaptiveBannerAdSize(context, adWidth);
    }

    public void loadInterstitialNativeAd(Activity context) {
        if (!AdsUtils.isAppAdsFree) {
            if (isNetworkAvailable(activity)) {
                if (nativeAd == null) {
//                    isShowNativeInterstitial = true;
                    VideoOptions videoOptions = new VideoOptions.Builder()
                            .setStartMuted(false)
                            .build();
                    NativeAdOptions adOptions = new NativeAdOptions.Builder()
                            .setVideoOptions(videoOptions)
                            .build();

                    AdLoader adLoader = new AdLoader.Builder(context, strNativeAdsId_1)
                            .forNativeAd(nativeAds -> {
                                nativeAd = nativeAds;
                                if (showInterstitialAdListener != null) {
                                    showInterstitialAdListener.showInterstitialAd(activity);
                                    showInterstitialAdListener = null;
                                }
                            }).withAdListener(new AdListener() {
                                @Override
                                public void onAdLoaded() {
                                    super.onAdLoaded();
                                }

                                @Override
                                public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                    super.onAdFailedToLoad(loadAdError);
                                    dismissInterstitialAd();
                                }

                                @Override
                                public void onAdClosed() {
                                    super.onAdClosed();
                                }
                            }).withNativeAdOptions(adOptions).build();

                    adLoader.loadAd(new AdRequest.Builder().build());
                }
            }
        }
    }

    private void setCountdown(Activity activity, TextView countdown_txt, ImageView close, int count) {
        handler.postDelayed(() -> activity.runOnUiThread(() -> {
            countdown_txt.setText(String.valueOf((count - 1)));
            if (count == 0) {
                countdown_txt.setVisibility(View.GONE);
                close.setVisibility(View.VISIBLE);
            } else {
                setCountdown(activity, countdown_txt, close, count - 1);
            }
        }), 1000);
    }

    public void showNativeAd(Activity context, FrameLayout adFrameLayout, CardView image_close, CardView video_close, TextView countdown_txt, ImageView close) {
        if (nativeAd != null) {
            int resource;
            boolean isShopView = false;
            if (nativeAd.getMediaContent().hasVideoContent()) {
                resource = R.layout.activity_native_video_ad;
                image_close.setVisibility(View.GONE);
                video_close.setVisibility(View.VISIBLE);
                int c = 5;
                countdown_txt.setVisibility(View.VISIBLE);
                close.setVisibility(View.GONE);
                countdown_txt.setText(String.valueOf(c));
                handler.postDelayed(() -> activity.runOnUiThread(() -> {
                    countdown_txt.setText(String.valueOf((c - 1)));
                    setCountdown(context, countdown_txt, close, (c - 1));
                }), 1000);
            } else if (!TextUtils.isEmpty(nativeAd.getCallToAction()) && nativeAd.getCallToAction().contains("shop")) {
                isShopView = true;
                resource = R.layout.activity_native_ads_shop;
                image_close.setVisibility(View.GONE);
                video_close.setVisibility(View.GONE);
            } else {
                isShopView = true;
                if (nativeAd.getIcon() == null) {
                    resource = R.layout.activity_native_ads_shop;
                } else {
                    resource = R.layout.activity_native_ad_app;
                }

                image_close.setVisibility(View.GONE);
                video_close.setVisibility(View.GONE);
            }

            LayoutInflater layoutInflater = LayoutInflater.from(context);
            NativeAdView adView = (NativeAdView) layoutInflater.inflate(resource, null);
            if (isShopView) {
                View closeBtn = adView.findViewById(R.id.close);
                closeBtn.setOnClickListener(v -> {
                    dismissInterstitialAd();
                    context.finish();
                });
            }
            populateUnifiedNativeAdView(nativeAd, adView, true);
            adFrameLayout.removeAllViews();
            adFrameLayout.addView(adView);

            dismissInterstitialAd();
            nativeAd = null;
        }
    }

    public void loadBannerNativeAd(Activity context, FrameLayout adFrameLayout) {
        //isShowNativeBanner = true;
        if (!AdsUtils.isAppAdsFree) {
            if (isNetworkAvailable(activity)) {
                AdLoader.Builder builder = new AdLoader.Builder(context, strNativeAdsId_1);
                builder.forNativeAd(unifiedNativeAd -> {
                    try {
                        LayoutInflater inflater = LayoutInflater.from(context);
                        NativeAdView adView = (NativeAdView) inflater.inflate(R.layout.layout_banner_native_ad, null);
                        populateUnifiedNativeAdView(unifiedNativeAd, adView, false);
                        adFrameLayout.removeAllViews();
                        adFrameLayout.addView(adView);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });

                NativeAdOptions adOptions = new NativeAdOptions.Builder().build();

                builder.withNativeAdOptions(adOptions);

                AdLoader adLoader = builder.withAdListener(new AdListener() {
                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
                        //Log.e(TAG,"FAILED >>> "+loadAdError.getMessage() + " CODE >>> "+loadAdError.getCode());
                        dismissNativeAd();
                    }

                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                    }

                }).build();
                adLoader.loadAd(new AdRequest.Builder().build());
            }
        }
    }

    public void loadLargerThanMediumSizedNativeAd1(Activity context, FrameLayout adFrameLayout, boolean isGrid, boolean isShowMedia, String adId) {
        if (!AdsUtils.isAppAdsFree) {
            if (isNetworkAvailable(activity)) {
                loadLargerThanMediumSizedNativeAd(context, adFrameLayout, isGrid, isShowMedia, adId);
                setShowNativeAdListener(new LoadAds.ShowNativeAdListener() {
                    @Override
                    public void showNativeAd(Activity activity) {
//                        cardView.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void dismissNativeAd(Activity activity) {
//                        cardView.setVisibility(View.GONE);
                    }
                });
            } else {
//                cardView.setVisibility(View.GONE);
            }
        } else {
//            cardView.setVisibility(View.GONE);
        }
    }

    public void loadLargerThanMediumSizedNativeAd(Activity context, FrameLayout adFrameLayout, boolean isGrid, boolean isShowMedia, String adID) {
        //isShowNativeBanner = true;
        AdLoader.Builder builder = new AdLoader.Builder(context, adID);
//        AdLoader.Builder builder = new AdLoader.Builder(context, strNativeAdsId_1);
        builder.forNativeAd(unifiedNativeAd -> {
            try {
                LayoutInflater inflater = LayoutInflater.from(context);
                NativeAdView adView;
                if (isGrid) {
                    adView = (NativeAdView) inflater.inflate(R.layout.layout_big_native_ad_mob, null);
                } else {
                    adView = isShowMedia ?
                            (NativeAdView) inflater.inflate(R.layout.layout_big_native_ad_mob, null) :
                            (NativeAdView) inflater.inflate(R.layout.layout_small_native_ad_mob, null);
                }
                populateUnifiedNativeAdView(unifiedNativeAd, adView, true);
                adFrameLayout.removeAllViews();
                adFrameLayout.addView(adView);
//                showHideShimmerLayout(mShimmerViewContainer, false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        NativeAdOptions adOptions = new NativeAdOptions.Builder().build();

        builder.withNativeAdOptions(adOptions);

        AdLoader adLoader = builder.withAdListener(new AdListener() {
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                Log.e(TAG, "ON_AD_FAILED_TO_LOAD_NATIVE >>> MEDIUM_SIZE >>> " + loadAdError.getCode() + " ???isShowNativeAdx ");
                if (!adID.equalsIgnoreCase(adxNativeAdsId_1)) {
                    loadLargerThanMediumSizedNativeAd(context, adFrameLayout, isGrid, isShowMedia, adxNativeAdsId_1);
                } else {
                    dismissNativeAd();
                }
//                showHideShimmerLayout(mShimmerViewContainer, false);
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                //Log.e(TAG,"ON_AD_LOADED");
//                showHideShimmerLayout(mShimmerViewContainer, false);
                showNativeAd();
            }
        }).build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void loadMediumBannerSizedListNativeAd(Activity activity, FrameLayout frameLayout) {
        if (!AdsUtils.isAppAdsFree) {
            if (isNetworkAvailable(activity)) {
//                showHideShimmerLayout(mShimmerViewContainer, true);

                AdLoader.Builder builder = new AdLoader.Builder(activity, strNativeAdsId_1);
                builder.forNativeAd(NativeAd -> {
//                    if (advertizeLayout != null) {
//                        advertizeLayout.setVisibility(View.VISIBLE);
//                    }
                    LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    NativeAdView adView = (NativeAdView) inflater.inflate(R.layout.layout_native_ad_medium_banner, null);

                    populateUnifiedNativeAdView(NativeAd, adView, false);
                    frameLayout.removeAllViews();
                    frameLayout.addView(adView);
//                    showHideShimmerLayout(mShimmerViewContainer, false);
                    frameLayout.setVisibility(View.VISIBLE);
                });
                builder.withAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
//                        showHideShimmerLayout(mShimmerViewContainer, false);
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
//                        showHideShimmerLayout(mShimmerViewContainer, false);
                        //Log.e(TAG, "onAdFailedToLoadNative:" + loadAdError.getCode());
                    }
                });
                builder.build();
                AdLoader adLoader = builder.build();
                adLoader.loadAd(new AdRequest.Builder().build());
            }
        }
    }


    public void populateUnifiedNativeAdView(NativeAd nativeAd, NativeAdView adView, boolean isAllowMediaView) {
        try {
            adView.setMediaView(adView.findViewById(R.id.mediaView));
            adView.setHeadlineView(adView.findViewById(R.id.adTitle));
            adView.setBodyView(adView.findViewById(R.id.adDescription));
            adView.setCallToActionView(adView.findViewById(R.id.callToAction));
            adView.setIconView(adView.findViewById(R.id.adIcon));
            adView.setAdvertiserView(adView.findViewById(R.id.adAdvertiser));
            adView.setStarRatingView(adView.findViewById(R.id.adStars));



            /*adView.setPriceView(adView.findViewById(R.id.adPrice));
            adView.setStoreView(adView.findViewById(R.id.adStore));*/

            ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
            Log.e(TAG, "populateUnifiedNativeAdView:isAllowMediaView ==1 " + isAllowMediaView);

            if (isAllowMediaView) {
                adView.getMediaView().setBackgroundColor(activity.getResources().getColor(R.color.ads_banner_bg));
                Log.e(TAG, "populateUnifiedNativeAdView:isAllowMediaView ==2 " + isAllowMediaView);
                if (nativeAd.getMediaContent() != null) {
//                    if (nativeAd.getMediaContent().hasVideoContent()) {
                    Log.e(TAG, "populateUnifiedNativeAdView:isAllowMediaView ==3 " + isAllowMediaView);
//                    adView.getMediaView().setVisibility(View.VISIBLE);
                    adView.getMediaView().setMediaContent(nativeAd.getMediaContent());


//                    }else {
                    adView.getMediaView().setMediaContent(nativeAd.getMediaContent());
                    adView.getMediaView().setImageScaleType(ImageView.ScaleType.FIT_CENTER);
//                    }
                } else {
                    adView.getMediaView().setVisibility(View.GONE);
                    Log.e(TAG, "populateUnifiedNativeAdView:isAllowMediaView ==4 " + isAllowMediaView);

                }

            } else {
                adView.getMediaView().setVisibility(View.GONE);
            }

            if (nativeAd.getBody() == null) {
                adView.getBodyView().setVisibility(View.INVISIBLE);
            } else {
                if (adView.getBodyView() != null) {
                    adView.getBodyView().setVisibility(View.VISIBLE);
                    ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
                }
            }

            if (nativeAd.getCallToAction() == null) {
                adView.getCallToActionView().setVisibility(View.INVISIBLE);
            } else {
                adView.getCallToActionView().setVisibility(View.VISIBLE);
                ((Button) adView.getCallToActionView()).setText(nativeAd.getCallToAction());
            }

            if (nativeAd.getIcon() == null) {
                adView.getIconView().setVisibility(View.INVISIBLE);
                if (adView.findViewById(R.id.iconView) != null) {
                    adView.findViewById(R.id.iconView).setVisibility(View.INVISIBLE);
                }
                if (adView.findViewById(R.id.google_play) != null) {
                    adView.findViewById(R.id.google_play).setVisibility(View.VISIBLE);
                }
            } else {
                ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                adView.getIconView().setVisibility(View.VISIBLE);
                if (adView.findViewById(R.id.iconView) != null) {
                    adView.findViewById(R.id.iconView).setVisibility(View.VISIBLE);
                }
                if (adView.findViewById(R.id.google_play) != null) {
                    adView.findViewById(R.id.google_play).setVisibility(View.INVISIBLE);
                }
            }

            if (nativeAd.getAdvertiser() == null) {
                if (adView.getAdvertiserView() != null) {
                    adView.getAdvertiserView().setVisibility(View.GONE);
                }
            } else {
                if (adView.getAdvertiserView() != null) {
                    ((TextView) adView.getAdvertiserView()).setText(nativeAd.getAdvertiser());
                    adView.getAdvertiserView().setVisibility(View.VISIBLE);
                }
            }

            if (nativeAd.getStarRating() == null) {
                if (adView.getStarRatingView() != null) {
                    adView.getStarRatingView().setVisibility(View.INVISIBLE);
                }
            } else {
                if (adView.getStarRatingView() != null) {
                    ((RatingBar) adView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
                    adView.getStarRatingView().setVisibility(View.VISIBLE);
                }
            }

            if (nativeAd.getPrice() == null) {
                if (adView.getPriceView() != null) {
                    adView.getPriceView().setVisibility(View.INVISIBLE);
                }
            } else {
                if (adView.getPriceView() != null) {
                    adView.getPriceView().setVisibility(View.VISIBLE);
                    ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
                }
            }

            if (nativeAd.getStore() == null) {
                if (adView.getStoreView() != null) {
                    adView.getStoreView().setVisibility(View.INVISIBLE);
                }
            } else {
                if (adView.getStoreView() != null) {
                    adView.getStoreView().setVisibility(View.VISIBLE);
                    ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
                }
            }

            adView.setNativeAd(nativeAd);
            VideoController vc = nativeAd.getMediaContent().getVideoController();
            vc.mute(true);
            if (vc.hasVideoContent()) {
                vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                    @Override
                    public void onVideoEnd() {
                        super.onVideoEnd();
                    }
                });
            }


            adView.setNativeAd(nativeAd);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface ShowInterstitialAdListener {
        public void showInterstitialAd(Activity activity);

        public void dismissInterstitialAd(Activity activity);
    }

    public interface ShowNativeAdListener {
        public void showNativeAd(Activity activity);

        public void dismissNativeAd(Activity activity);
    }

    public AdView getBannerAdView() {
        return adMobAdView;
    }

    public void loadAdaptiveBanner(Context context, FrameLayout adContainerView) {
        MobileAds.initialize(context, initializationStatus -> {
        });
        adMobAdView = new AdView(context);
        adMobAdView.setAdSize(AdSize.SMART_BANNER);
        //adMobAdView.setAdUnitId(Application.getBannerAdId(context));
        adMobAdView.setAdUnitId(strAdaptiveBannerAdsId);
        AdRequest adRequest = new AdRequest.Builder().build();
        adMobAdView.loadAd(adRequest);
        adContainerView.removeAllViews();
        adContainerView.addView(adMobAdView);
    }

    public void showHideShimmerLayout(ShimmerFrameLayout mShimmerViewContainer, boolean isShowShimmer) {
        if (mShimmerViewContainer != null) {
            if (isShowShimmer) {
                mShimmerViewContainer.startShimmer();
                mShimmerViewContainer.setVisibility(View.VISIBLE);
            } else {
                mShimmerViewContainer.stopShimmer();
                mShimmerViewContainer.setVisibility(View.GONE);
            }
        }
    }

    public NativeAd mNativeRateAd = null;
    boolean isNativeRateAdLoad = false;

    public void LoadNativeRateAd(final Context context, final AdEventListener adEventListener, String nativeAdID) {
        if (isNetworkAvailable(context)) {
            AdLoader.Builder builder = new AdLoader.Builder(context, nativeAdID);
//            AdLoader.Builder builder = new AdLoader.Builder(context, strNativeAdsId_1);
            builder.forNativeAd(unifiedNativeAd -> {
                mNativeRateAd = unifiedNativeAd;
                if (adEventListener != null) {
                    adEventListener.onAdLoaded(unifiedNativeAd);
                }
            }).withAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                }

                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    if (!isNativeRateAdLoad) {
                        isNativeRateAdLoad = true;
                        LoadNativeRateAd(context, adEventListener, adxNativeAdsId_1);
                    }
                    if (adEventListener != null) {
                        adEventListener.onLoadError(loadAdError.getMessage());
                    }
                    //Log.e(TAG, "onAdFailedToLoadNative:" + loadAdError.getCode());
                }

                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                }
            });
//            VideoOptions videoOptions = new VideoOptions.Builder()
//                    .setStartMuted(true)
//                    .build();
//            com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
//            builder.withNativeAdOptions(adOptions);

            VideoOptions videoOptions = new VideoOptions.Builder()
                    .setStartMuted(false)
                    .build();

            NativeAdOptions adOptions = new NativeAdOptions.Builder()
                    .setVideoOptions(videoOptions)
                    .build();
            builder.withNativeAdOptions(adOptions);

            AdLoader adLoader = builder.build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            mNativeRateAd = null;
        }
    }

    public NativeAd mNativeSearchPageAds = null;
    public NativeAd mNativeSettingsPageAds = null;

    public void loadOneTimeFetchOnlyNativeAd(final Context context, AdsEnum.AdsPageType adsPageType, ShimmerFrameLayout mShimmerViewContainer, final AdEventListener adEventListener) {
        if (isNetworkAvailable(context)) {
            showHideShimmerLayout(mShimmerViewContainer, true);
            AdLoader.Builder builder = new AdLoader.Builder(context, strNativeAdsId_1);
            builder.forNativeAd(unifiedNativeAd -> {
                if (adsPageType == AdsEnum.AdsPageType.NATIVE_ADS_SEARCH) {
                    mNativeSearchPageAds = unifiedNativeAd;
                } else if (adsPageType == AdsEnum.AdsPageType.NATIVE_ADS_SETTINGS) {
                    mNativeSettingsPageAds = unifiedNativeAd;
                }
                if (adEventListener != null) {
                    adEventListener.onAdLoaded(unifiedNativeAd);
                }
            }).withAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    showHideShimmerLayout(mShimmerViewContainer, false);
                }

                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    if (adEventListener != null) {
                        adEventListener.onLoadError(loadAdError.getMessage());
                    }
                    showHideShimmerLayout(mShimmerViewContainer, false);
                    //Log.e(TAG, "onAdFailedToLoadNative:" + loadAdError.getCode());
                }

                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                }
            });
            VideoOptions videoOptions = new VideoOptions.Builder()
                    .setStartMuted(true)
                    .build();
            com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
            builder.withNativeAdOptions(adOptions);
            AdLoader adLoader = builder.build();
            adLoader.loadAd(new AdRequest.Builder().build());
        } else {
            if (adsPageType == AdsEnum.AdsPageType.NATIVE_ADS_SEARCH) {
                mNativeSearchPageAds = null;
            } else if (adsPageType == AdsEnum.AdsPageType.NATIVE_ADS_SETTINGS) {
                mNativeSettingsPageAds = null;
            }
        }
    }

    public void makeOneTimeLoadedNativeAdsNullOnStartUp() {
        mNativeSearchPageAds = null;
        mNativeSettingsPageAds = null;
    }

    public interface AdEventListener {

        void onAdLoaded(Object object);

        void onAdClosed();

        void onLoadError(String errorCode);
    }

    //======================================================================================================
    public void LoadNativeAd(final Context context, String nativeAdID, final AdEventListener adEventListener) {
        AdLoader.Builder builder = new AdLoader.Builder(context, nativeAdID);

        builder.forNativeAd(unifiedNativeAd -> {
            mNativeRateAd = unifiedNativeAd;
            if (adEventListener != null) {
                adEventListener.onAdLoaded(unifiedNativeAd);
            }
        }).withAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
            }

            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                if (!isNativeRateAdLoad) {
                    isNativeRateAdLoad = true;
                    LoadNativeAd(context, adxNativeAdsId_1, adEventListener);
                }
                if (adEventListener != null) {
                    adEventListener.onLoadError(loadAdError.getMessage());
                }
                Log.e(TAG, "onAdFailedToLoadNative:" + loadAdError.getCode());
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder()
                .setStartMuted(true)
                .build();
        com.google.android.gms.ads.nativead.NativeAdOptions adOptions = new com.google.android.gms.ads.nativead.NativeAdOptions.Builder().setVideoOptions(videoOptions).build();
        builder.withNativeAdOptions(adOptions);
        AdLoader adLoader = builder.build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    public void populateUnifiedNativeAdView(Context context, FrameLayout frameLayout, NativeAd nativeAd, boolean isShowMedia, boolean isGrid) {
        if (isNetworkAvailable(context)) {
            LayoutInflater inflater = LayoutInflater.from(context);
            // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
            NativeAdView adView;
            if (isGrid) {
                adView = (NativeAdView) inflater.inflate(R.layout.layout_big_native_ad_mob, null);
            } else {
                adView = (NativeAdView) (isShowMedia ?
                        inflater.inflate(R.layout.layout_big_native_ad_mob, null) :
                        inflater.inflate(R.layout.layout_small_native_ad_mob, null));
            }

            if (frameLayout != null) {
                frameLayout.removeAllViews();
                frameLayout.addView(adView);
                frameLayout.setVisibility(View.VISIBLE);
            }
            try {
                com.google.android.gms.ads.nativead.MediaView mediaView = adView.findViewById(R.id.mediaView);
                mediaView.setMediaContent(nativeAd.getMediaContent());
//            mediaView.setImageScaleType(ImageView.ScaleType.CENTER_CROP);
                adView.setMediaView(mediaView);
//
//                if (color == 1) {
//                    mediaView.setVisibility(View.VISIBLE);
//                } else {
//                    mediaView.setVisibility(View.GONE);
//                }

                adView.setHeadlineView(adView.findViewById(R.id.adTitle));
                adView.setBodyView(adView.findViewById(R.id.adDescription));
                adView.setIconView(adView.findViewById(R.id.adIcon));

                ((TextView) adView.getHeadlineView()).setText(nativeAd.getHeadline());
//                adView.getMediaView().setMediaContent(nativeAd.getMediaContent());


                if (nativeAd.getBody() == null) {
                    adView.getBodyView().setVisibility(View.INVISIBLE);
                } else {
                    adView.getBodyView().setVisibility(View.VISIBLE);
                    ((TextView) adView.getBodyView()).setText(nativeAd.getBody());
                }


                if (nativeAd.getIcon() == null) {
                    adView.getIconView().setVisibility(View.GONE);
                } else {
                    ((ImageView) adView.getIconView()).setImageDrawable(nativeAd.getIcon().getDrawable());
                    adView.getIconView().setVisibility(View.VISIBLE);
                }

                if (isShowMedia) {
                    adView.getMediaView().setVisibility(View.VISIBLE);
                } else {
                    adView.getMediaView().setVisibility(View.GONE);
                }

                adView.setNativeAd(nativeAd);
                VideoController vc = nativeAd.getMediaContent().getVideoController();
                vc.mute(true);
                if (vc.hasVideoContent()) {
                    vc.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                        @Override
                        public void onVideoEnd() {
                            super.onVideoEnd();
                        }
                    });
                }


                adView.setNativeAd(nativeAd);

            } catch (Exception e) {
                e.printStackTrace();
                Log.e("TAG", "populateUnifiedNativeAdView Exception: " + e.getMessage());
            }
        }
    }

}
