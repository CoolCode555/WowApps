package com.customlibraries.adsutils;

public class AdsConstant {
    public static boolean SHOW_OPEN_ADS = true;
    public static boolean OPEN_ADS = true;
}
