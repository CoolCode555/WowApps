package com.customlibraries.loadads;

import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;


public class NativeAdScreen extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nativead);

        FrameLayout frameLayout = findViewById(R.id.ad);
        CardView image_close = findViewById(R.id.image_close);
        CardView video_close = findViewById(R.id.video_close);
        ImageView close = findViewById(R.id.close);
        TextView countdown_txt = findViewById(R.id.countdown_txt);
        ProgressBar progressBar = findViewById(R.id.progressBar);

        image_close.setOnClickListener(v -> finish());
        close.setOnClickListener(v -> finish());

        LoadAds.getInstance(this).showNativeAd(this, frameLayout, image_close, video_close, countdown_txt, close);
    }

    @Override
    public void onBackPressed() {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
