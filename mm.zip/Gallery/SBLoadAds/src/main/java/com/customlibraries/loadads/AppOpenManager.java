package com.customlibraries.loadads;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;

import java.util.Date;

import static androidx.lifecycle.Lifecycle.Event.ON_START;
import static com.customlibraries.adsutils.AdsConstant.OPEN_ADS;
import static com.customlibraries.adsutils.AdsConstant.SHOW_OPEN_ADS;

public class AppOpenManager implements LifecycleObserver, Application.ActivityLifecycleCallbacks {
    private static final String LOG_TAG = "AppOpenManager";
    public String AD_UNIT_ID = "";
    public String ADX_UNIT_ID = "";

    private AppOpenAd appOpenAd = null;

    private AppOpenAd.AppOpenAdLoadCallback loadCallback;

    private final Application myApplication;
    private Activity currentActivity;

    private static boolean isShowingAd = false;
    private long loadTime = 0;

    public AppOpenManager(Application myApplication) {
        this.myApplication = myApplication;
        this.myApplication.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
    }

    public void setAppOpenAdsId(String strAdId,String adxAdId){
        this.AD_UNIT_ID = strAdId;
        this.ADX_UNIT_ID = adxAdId;
    }

    @OnLifecycleEvent(ON_START)
    public void onStart() {
        if (SHOW_OPEN_ADS) {
            if (currentActivity != null && OPEN_ADS) {
                showAdIfAvailable();
            } else {
                fetchAd();
            }
        }
        //Log.e(LOG_TAG, "onStart SHOW_OPEN_ADS >>> "+SHOW_OPEN_ADS);
    }

    public void fetchAd() {
        if (isAdAvailable()) {
            return;
        }

        loadCallback = new AppOpenAd.AppOpenAdLoadCallback() {
            @Override
            public void onAdLoaded(AppOpenAd ad) {
                AppOpenManager.this.appOpenAd = ad;
            }

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                AdRequest request = getAdRequest();
                if (currentActivity != null) {
                    AppOpenAd.load(
                            myApplication, ADX_UNIT_ID, request,
                            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);
                }

            }
        };

        AdRequest request = getAdRequest();
        if (currentActivity != null) {
            AppOpenAd.load(
                    myApplication, AD_UNIT_ID, request,
                    AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);
        }
    }

    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }

    public boolean isAdAvailable() {
        return appOpenAd != null;
    }

    private boolean wasLoadTimeLessThanNHoursAgo(long numHours) {
        long dateDifference = (new Date()).getTime() - this.loadTime;
        long numMilliSecondsPerHour = 3600000;
        return (dateDifference < (numMilliSecondsPerHour * numHours));
    }

    public void showAdIfAvailable() {
        if (!isShowingAd && isAdAvailable()) {
            //Log.d(LOG_TAG, "Will show ad.");

            FullScreenContentCallback fullScreenContentCallback =
                    new FullScreenContentCallback() {
                        @Override
                        public void onAdDismissedFullScreenContent() {
                            // Set the reference to null so isAdAvailable() returns false.
                            AppOpenManager.this.appOpenAd = null;
                            isShowingAd = false;
                            fetchAd();
                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(AdError adError) {
                            //Log.d(LOG_TAG, "Error display show ad." + adError.getMessage());
                        }

                        @Override
                        public void onAdShowedFullScreenContent() {
                            isShowingAd = true;
                        }
                    };

            //Log.d(LOG_TAG, String.valueOf(currentActivity));
            appOpenAd.show(currentActivity);
            appOpenAd.setFullScreenContentCallback(fullScreenContentCallback);
        } else {
            //Log.d(LOG_TAG, "Can not show ad.");
            fetchAd();
        }
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle bundle) {
        //Log.d("Data", "onActivityCreated: ====> create");
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        //Log.d("Data", "onActivityCreated: ====> started");
        currentActivity = activity;
    }

    @Override
    public void onActivityResumed(@NonNull Activity activity) {
        //Log.d("Data", "onActivityCreated: ====> resume");
        currentActivity = activity;
    }

    @Override
    public void onActivityPaused(@NonNull Activity activity) {
        //Log.d("Data", "onActivityCreated: ====> pause");
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        //Log.d("Data", "onActivityCreated: ====> stopped");
    }

    @Override
    public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle bundle) {
        //Log.d("Data", "onActivityCreated: ====> save");
    }

    @Override
    public void onActivityDestroyed(@NonNull Activity activity) {
        //Log.d("Data", "onActivityCreated: ====> destroy");
        currentActivity = null;
    }
}
