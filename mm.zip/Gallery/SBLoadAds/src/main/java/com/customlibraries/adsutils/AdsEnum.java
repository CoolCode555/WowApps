package com.customlibraries.adsutils;

public class AdsEnum {
    public enum AdsPageType{
        NATIVE_ADS_SEARCH, NATIVE_ADS_SETTINGS
    }
}
