package com.customlibraries.loadads;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.customlibraries.adsutils.AdsUtils;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class ExitDialogNative extends BottomSheetDialogFragment {
    View view;
    private LoadAds loadAds;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.exitDialogBottomSheetDialogTheme);

        loadAds = LoadAds.getInstance(getActivity());
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.bottom_navigation_exit, container, false);

        initView();
        if (getDialog() != null) {
            getDialog().setOnShowListener(
                    dialog -> {
                        new Handler(Looper.myLooper())
                                .postDelayed(
                                        () -> {
                                            BottomSheetDialog d = (BottomSheetDialog) dialog;
                                            FrameLayout bottomSheet = d.findViewById(com.google.android.material.R.id.design_bottom_sheet);
                                            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
                                            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                                            bottomSheetBehavior.setSkipCollapsed(true);
                                        },
                                        0);
                    });
        }
        return view;
    }

    private void initView() {
        TextView tv_exit = view.findViewById(R.id.tv_exit);
        FrameLayout adLayout = view.findViewById(R.id.adLayout);

        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        NativeAdView adView = (NativeAdView) inflater.inflate(R.layout.layout_big_native_ad_mob, null);

        if (loadAds.mNativeRateAd != null) {
            AdsUtils.populateNativeRateUsAdView(getActivity(), loadAds.mNativeRateAd, adView, adLayout);
        } else {
            AdsUtils.loadRateUSNativeAd(getActivity(), new LoadAds.AdEventListener() {
                @Override
                public void onAdLoaded(Object object) {
                    AdsUtils.populateNativeRateUsAdView(getActivity(), (NativeAd) object, adView, adLayout);
                }

                @Override
                public void onAdClosed() {

                }

                @Override
                public void onLoadError(String errorCode) {

                }
            });
        }

        tv_exit.setOnClickListener(view -> {
            try {
                dismiss();
                getActivity().finish();
                System.exit(0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
/*
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Window window = dialog.getWindow();
            if (window != null) {
                DisplayMetrics metrics = new DisplayMetrics();
                window.getWindowManager().getDefaultDisplay().getMetrics(metrics);

                GradientDrawable dimDrawable = new GradientDrawable();

                GradientDrawable navigationBarDrawable = new GradientDrawable();
                navigationBarDrawable.setShape(GradientDrawable.RECTANGLE);
                navigationBarDrawable.setColor(getResources().getColor(R.color.ca_white));

                Drawable[] layers = {dimDrawable, navigationBarDrawable};

                LayerDrawable windowBackground = new LayerDrawable(layers);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    windowBackground.setLayerInsetTop(1, metrics.heightPixels);
                }
                window.setBackgroundDrawable(windowBackground);
            }
        }
*/
        return dialog;
    }
}
