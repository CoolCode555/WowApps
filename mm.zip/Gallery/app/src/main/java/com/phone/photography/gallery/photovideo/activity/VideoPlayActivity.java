package com.phone.photography.gallery.photovideo.activity;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.util.Constant;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class VideoPlayActivity extends AppCompatActivity {


    String filePath, filename, duration;
    @BindView(R.id.video_view)
    VideoView videoView;
    @BindView(R.id.iv_back)
    ImageView ivBack;
    @BindView(R.id.txt_title)
    TextView txtTitle;
    @BindView(R.id.iv_more)
    ImageView ivMore;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.iv_center_play_pause)
    ImageView ivCenterPlayPause;
    @BindView(R.id.btn_play_pause)
    CardView btnPlayPause;
    @BindView(R.id.txt_video_current_dur)
    AppCompatTextView txtVideoCurrentDur;
    @BindView(R.id.video_seek)
    SeekBar videoSeek;
    @BindView(R.id.txt_video_total_dur)
    AppCompatTextView txtVideoTotalDur;
    @BindView(R.id.lout_center)
    RelativeLayout loutCenter;
    @BindView(R.id.lout_bottom)
    LinearLayout loutBottom;

    int currentDur = 0;

    Handler mHandler = new Handler();
    boolean isFirstTime = true;

    boolean isCustomChangeSeekbar = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        setContentView(R.layout.activity_video_play);
        ButterKnife.bind(this);

        intView();
    }

    private void intView() {
        Intent intent = getIntent();

        if (intent != null) {

            filePath = intent.getStringExtra("FilePath");
            filename = intent.getStringExtra("FileName");
            duration = intent.getStringExtra("Duration");

            txtTitle.setText(filename);

            videoView.setVideoPath(filePath);
            videoView.requestFocus();
            videoView.start();

            videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    // videoView.seekTo(1);
                    ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_pause));
                    txtVideoCurrentDur.setText(getDurationString(videoView.getCurrentPosition()));
                    videoSeek.setMax(videoView.getDuration());
                    int duration = mp.getDuration() / 1000;
                    int hours = duration / 3600;

                    Log.e("videoView", "videoView Duration " + videoView.getDuration());
                    Log.e("videoView", "seekbar Duration " + videoSeek.getMax());
                    int minutes = (duration / 60) - (hours * 60);
                    int seconds = duration - (hours * 3600) - (minutes * 60);
                    String formatted = String.format("%02d:%02d", minutes, seconds);
                    txtVideoTotalDur.setText(formatted);
                    videoSeek.setProgress(videoView.getCurrentPosition());
                    updateProgressBar();
                }
            });

            videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    ivCenterPlayPause.setVisibility(View.VISIBLE);
                    ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_play));
                }
            });

            videoSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                    Log.e("videoView", "onStartTrackingTouch progress ");
                    if (videoView != null)
                        videoView.pause();
                    mHandler.removeCallbacks(mUpdateTimeTask);
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                    int progress = seekBar.getProgress();
                    Log.e("videoView", "seekbar Duration progress " + progress);
                    if (videoView != null) {
                        videoView.seekTo(progress);
                        Log.e("videoView", "videoView Duration progress " + videoView.getCurrentPosition());
                        txtVideoCurrentDur.setText(getDurationString(videoView.getCurrentPosition()));
                        if (!videoView.isPlaying()) {
                            videoView.start();
                        }
                        isCustomChangeSeekbar = true;
                        updateProgressBar();
                    }

                }
            });

        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("VideoPlay", "onResume");
        if (isFirstTime) {
            isFirstTime = false;
        } else {
            if (videoView != null) {
                if (videoView.isPlaying()) {
                    videoView.pause();
                    ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_play));
                    toolbar.setVisibility(View.VISIBLE);
                    btnPlayPause.setVisibility(View.VISIBLE);
                    loutBottom.setVisibility(View.VISIBLE);
                } else {
                    videoView.seekTo(currentDur);
                    videoView.start();
                    ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_pause));
                }
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("VideoPlay", "onPause");
        if (videoView != null) {

            if (videoView.isPlaying()) {
                videoView.pause();
                currentDur = videoView.getCurrentPosition();
                toolbar.setVisibility(View.VISIBLE);
                btnPlayPause.setVisibility(View.VISIBLE);
                loutBottom.setVisibility(View.VISIBLE);
                ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_play));
            } else {
                currentDur = videoView.getCurrentPosition();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (videoView.isPlaying())
            videoView.pause();
        super.onBackPressed();
    }

    @OnClick({R.id.iv_back, R.id.iv_more, R.id.btn_play_pause, R.id.lout_center})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.iv_more:
                if (videoView.isPlaying()) {
                    videoView.pause();
                    ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_play));
                }
                showDetailDialog();
                break;
            case R.id.lout_center:
                if (toolbar.getVisibility() == View.VISIBLE) {
                    toolbar.setVisibility(View.GONE);
                    btnPlayPause.setVisibility(View.GONE);
                    loutBottom.setVisibility(View.GONE);
                } else {
                    toolbar.setVisibility(View.VISIBLE);
                    btnPlayPause.setVisibility(View.VISIBLE);
                    loutBottom.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.btn_play_pause:
                if (videoView.isPlaying()) {
                    videoView.pause();
                    ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_play));
                } else {
                    videoView.start();
                    ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_pause));

                }
                break;
        }
    }

    private void showDetailDialog() {
        final Dialog dialog = new Dialog(VideoPlayActivity.this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_details);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.BOTTOM);


        TextView txt_title = dialog.findViewById(R.id.txt_title);
        TextView txt_format = dialog.findViewById(R.id.txt_format);
        TextView txt_time = dialog.findViewById(R.id.txt_time);
        TextView txt_resolution = dialog.findViewById(R.id.txt_resolution);
        TextView txt_file_size = dialog.findViewById(R.id.txt_file_size);
        TextView txt_duration = dialog.findViewById(R.id.txt_duration);
        TextView txt_path = dialog.findViewById(R.id.txt_path);


        TextView btn_ok = dialog.findViewById(R.id.btn_ok);
        txt_title.setText(filename);


        File file = new File(filePath);
        if (file.exists()) {
            String type = Constant.getMimeTypeFromFilePath(filePath);

            txt_format.setText(type);

            txt_file_size.setText(Formatter.formatShortFileSize(this, file.length()));

            SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm a");
            String strDate = format.format(file.lastModified());

            txt_time.setText(strDate);

            try {
                MediaMetadataRetriever metaRetriever = new MediaMetadataRetriever();
                metaRetriever.setDataSource(filePath);
                int height = Integer.parseInt(Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)));
                int width = Integer.parseInt(Objects.requireNonNull(metaRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)));

                txt_resolution.setText(width + "X" + height);
                txt_resolution.setVisibility(View.VISIBLE);

            } catch (Exception e) {
                e.printStackTrace();
                txt_resolution.setVisibility(View.GONE);
            }


        }

        txt_duration.setText(duration);
        txt_path.setText(filePath);


        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });


        dialog.show();
    }

    private void updateProgressBar() {


        mHandler.postDelayed(mUpdateTimeTask, 200);
    }

    private Runnable mUpdateTimeTask = new Runnable() {
        public void run() {
            if (videoView != null) {
                if (videoView.isPlaying()) {
                    ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_pause));
                } else {
                    ivCenterPlayPause.setImageDrawable(getResources().getDrawable(R.drawable.ic_play));
                }
                if (!isCustomChangeSeekbar) {
                    videoSeek.setProgress(videoView.getCurrentPosition());
                } else {
                    isCustomChangeSeekbar = false;
                }
                txtVideoTotalDur.setText(getDurationString(videoView.getDuration()));
                txtVideoCurrentDur.setText(getDurationString(videoView.getCurrentPosition()));

            }

            mHandler.postDelayed(this, 200);
        }
    };

    private String getDurationString(int duration) {

        long hours = TimeUnit.MILLISECONDS.toHours(duration);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(duration);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration));

        String strMin = "";
        if (minutes < 10) {
            strMin = "0" + minutes;
        } else {
            strMin = String.valueOf(minutes);
        }

        String strSec = "";
        if (seconds < 10) {
            strSec = "0" + seconds;
        } else {
            strSec = String.valueOf(seconds);
        }

        String strHour = "";
        if (hours < 10) {
            strHour = "0" + hours;
        } else {
            strHour = String.valueOf(hours);
        }

        if (hours == 0) {
            return strMin + ":" + strSec;
        } else
            return strHour + ":" + strMin + ":" + strSec;


    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mUpdateTimeTask);
    }
}