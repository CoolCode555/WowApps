package com.phone.photography.gallery.photovideo.activity;

import static com.customlibraries.adsutils.AdsUtils.getRandomNumber;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.adapter.PhotoAdapter;
import com.phone.photography.gallery.photovideo.adapter.PhotoAlbumAdapter;
import com.phone.photography.gallery.photovideo.model.DeleteEvent;
import com.phone.photography.gallery.photovideo.model.DisplayDeleteEvent;
import com.phone.photography.gallery.photovideo.model.DisplayUnFavoriteEvent;
import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;
import com.phone.photography.gallery.photovideo.util.Constant;
import com.phone.photography.gallery.photovideo.util.PreferencesUtility;
import com.phone.photography.gallery.photovideo.util.RxBus;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class FavoriteListActivity extends AppCompatActivity {

    @BindView(R.id.iv_back)
    ImageView ivBack;
    @BindView(R.id.txt_title)
    TextView txtTitle;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @BindView(R.id.lout_no_data)
    LinearLayout loutNoData;

    List<Object> photoList = new ArrayList<>();
    PhotoAlbumAdapter adapter;
    @BindView(R.id.lout_toolbar)
    RelativeLayout loutToolbar;
    @BindView(R.id.iv_close_select)
    ImageView ivCloseSelect;
    @BindView(R.id.txt_select)
    TextView txtSelect;
    @BindView(R.id.lout_select)
    RelativeLayout loutSelect;
    @BindView(R.id.iv_share)
    ImageView ivShare;
    @BindView(R.id.iv_delete)
    ImageView ivDelete;
    @BindView(R.id.lout_select_bottom)
    LinearLayout loutSelectBottom;

    int selected_Item = 0;
    ProgressDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        setContentView(R.layout.activity_album_image);
        ButterKnife.bind(this);

        intView();
        loadingDialog = new ProgressDialog(FavoriteListActivity.this);
        loadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        loadingDialog.setCancelable(false);
        loadingDialog.setMessage("Delete image...");
        loadingDialog.setCanceledOnTouchOutside(false);

        displayDeleteEvent();
        displayUnFavoriteEvent();
        deleteEvent();
    }

    private void intView() {

        txtTitle.setText("Favourite");
        progressBar.setVisibility(View.VISIBLE);
        new Thread(this::getData).start();
    }


    private void setAdapter() {
        progressBar.setVisibility(View.GONE);

        if (photoList != null && photoList.size() != 0) {
            recyclerView.setVisibility(View.VISIBLE);
            loutNoData.setVisibility(View.GONE);

            GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 4, LinearLayoutManager.VERTICAL, false);
            recyclerView.setLayoutManager(gridLayoutManager);
            if (getRandomNumber(1, 3) == 1)
                photoList.add(0, null);
            adapter = new PhotoAlbumAdapter(FavoriteListActivity.this, photoList);
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(final int position) {
                    if (adapter.getItemViewType(position) == PhotoAdapter.ITEM_HEADER_TYPE || adapter.getItemViewType(position) == PhotoAdapter.TYPE_AD) {
                        return 4;
                    }
                    return 1;
                }
            });
            recyclerView.setAdapter(adapter);

            adapter.setOnItemClickListener(new PhotoAlbumAdapter.ClickListener() {
                @Override
                public void onItemClick(int position, View v) {
                    if (photoList.get(position) instanceof PhotoData) {
                        PhotoData imageList = (PhotoData) photoList.get(position);
                        if (imageList.isCheckboxVisible()) {

                            if (imageList.isSelected()) {
                                imageList.setSelected(false);
                            } else
                                imageList.setSelected(true);
                            adapter.notifyItemChanged(position);
                            setSelectedFile();

                        } else {
                            int pos = -1;
                            List<PhotoData> dataList = new ArrayList<>();

                            for (int i = 0; i < photoList.size(); i++) {
                                if (photoList.get(i) instanceof PhotoData) {
                                    dataList.add((PhotoData) photoList.get(i));
                                    if (position == i) {
                                        pos = dataList.size() - 1;
                                    }
                                }
                            }

                            Constant.displayImageList = new ArrayList<>();
                            Constant.displayImageList.addAll(dataList);
                            Intent intent = new Intent(FavoriteListActivity.this, DisplayImageActivity.class);
                            intent.putExtra("pos", pos);
                            intent.putExtra("IsFavList", true);
                            startActivity(intent);

                        }
                    }

                }
            });

            adapter.setOnLongClickListener(new PhotoAlbumAdapter.LongClickListener() {
                @Override
                public void onItemLongClick(int position, View v) {
                    if (photoList.get(position) instanceof PhotoData) {
                        PhotoData imageList = (PhotoData) photoList.get(position);

                        for (int i = 0; i < photoList.size(); i++) {
                            if (photoList.get(i) != null)

                                if (photoList.get(i) instanceof PhotoData) {

                                    PhotoData model = (PhotoData) photoList.get(i);
                                    model.setCheckboxVisible(true);

                                }

                        }
                        imageList.setCheckboxVisible(true);
                        imageList.setSelected(true);

                        adapter.notifyDataSetChanged();
                        setSelectedFile();

                    }
                }
            });

        } else {
            recyclerView.setVisibility(View.GONE);
            loutNoData.setVisibility(View.VISIBLE);
        }
    }

    @OnClick({R.id.iv_close_select, R.id.iv_share, R.id.iv_delete, R.id.iv_back})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.iv_close_select:
                setClose();
                break;
            case R.id.iv_share:
                if (selected_Item != 0) {

                    shareImage();
                } else {
                    Toast.makeText(this, "Please select image", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.iv_delete:
                if (selected_Item != 0) {
                    showDeleteDialog();
                } else {
                    Toast.makeText(this, "Please select image", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (loutSelect.getVisibility() == View.VISIBLE) {

            setClose();

        } else
            super.onBackPressed();
    }

    private void shareImage() {
        ArrayList<Uri> uris = new ArrayList<>();
        Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);

        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    if (model.isSelected()) {
                        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(model.getFilePath()));
                        uris.add(uri);
                    }

                }
        }

        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(Intent.createChooser(intent, "Share with..."));
    }

    private void setSelectedFile() {
        int selected = 0;

        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                    }

                }
        }


        if (selected == 0) {

            OnSelected(true, false, selected);
            setClose();
        } else {
            OnSelected(false, true, selected);

        }
        selected_Item = selected;
    }

    private void getData() {
        List<String> favList = PreferencesUtility.getFavoriteList(FavoriteListActivity.this);

        LinkedHashMap<String, ArrayList<PhotoData>> bucketimagesDataPhotoHashMap = new LinkedHashMap<>();
        ArrayList<PhotoData> list = new ArrayList<>();

        if (favList == null) {
            favList = new ArrayList<>();
        }

        Collections.sort(favList, new Comparator<String>() {
            @Override
            public int compare(String i1, String i2) {
                File file1 = new File(i1);
                File file2 = new File(i2);

                SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm");
                String strDate1 = format.format(file1.lastModified());
                String strDate2 = format.format(file2.lastModified());

                int compareResult = 0;

                Date date1 = null;
                Date date2 = null;
                try {
                    date1 = format.parse(strDate1);
                    date2 = format.parse(strDate2);
                } catch (ParseException e) {
                    e.printStackTrace();
                }


                compareResult = date2.compareTo(date1);

                return compareResult;
            }
        });

        for (int f = 0; f < favList.size(); f++) {

            File file = new File(favList.get(f));

            if (file != null && file.exists()) {

                SimpleDateFormat format = new SimpleDateFormat("MMM yyyy");
                String strDate = format.format(file.lastModified());

                PhotoData imagesData = new PhotoData();
                imagesData.setFilePath(file.getPath());
                imagesData.setFileName(file.getName());
                imagesData.setFavorite(true);

                if (bucketimagesDataPhotoHashMap.containsKey(strDate)) {
                    ArrayList<PhotoData> imagesData1 = bucketimagesDataPhotoHashMap.get(strDate);
                    if (imagesData1 == null)
                        imagesData1 = new ArrayList<>();

                    imagesData1.add(imagesData);
                    bucketimagesDataPhotoHashMap.put(strDate, imagesData1);

                } else {
                    ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                    imagesData1.add(imagesData);
                    bucketimagesDataPhotoHashMap.put(strDate, imagesData1);
                }
            }

        }

        Set<String> keys = bucketimagesDataPhotoHashMap.keySet();
        ArrayList<String> listkeys = new ArrayList<>();
        listkeys.addAll(keys);

        for (int i = 0; i < listkeys.size(); i++) {
            ArrayList<PhotoData> imagesData = bucketimagesDataPhotoHashMap.get(listkeys.get(i));

            if (imagesData != null && imagesData.size() != 0) {

                PhotoHeader bucketData = new PhotoHeader();

                bucketData.setTitle(listkeys.get(i));
                bucketData.setPhotoList(imagesData);

                photoList.add(bucketData);
                photoList.addAll(imagesData);
            }
        }


        runOnUiThread(() -> {
            setAdapter();
        });
    }

    private void setClose() {

        selected_Item = 0;
        setCloseData();
        loutSelect.setVisibility(View.GONE);
        loutSelectBottom.setVisibility(View.GONE);
        loutToolbar.setVisibility(View.VISIBLE);


    }

    private void setCloseData() {
        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);

                }
        }
        if (adapter != null)
            adapter.notifyDataSetChanged();
        selected_Item = 0;
    }

    private void displayUnFavoriteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayUnFavoriteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DisplayUnFavoriteEvent>() {
            @Override
            public void call(DisplayUnFavoriteEvent event) {

                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> deleteList = new ArrayList<>();
                    deleteList = event.getDeleteList();


                    if (photoList != null && photoList.size() != 0) {

                        for (int d = 0; d < deleteList.size(); d++) {

                            for (int i = 0; i < photoList.size(); i++) {

                                if (photoList.get(i) instanceof PhotoData) {
                                    PhotoData model = (PhotoData) photoList.get(i);

                                    if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {

                                        boolean isPre = false, isNext = false;

                                        if (i != 0) {
                                            if (photoList.get(i - 1) instanceof PhotoHeader) {
                                                isPre = true;
                                            } else {
                                                isPre = false;
                                            }
                                        }

                                        if (i < (photoList.size() - 2)) {
                                            if (photoList.get(i + 1) instanceof PhotoHeader) {
                                                isNext = true;
                                            } else {
                                                isNext = false;
                                            }
                                        }

                                        if (isPre && isNext) {
                                            //  objectList.remove(i + 1);
                                            photoList.remove(i);
                                            photoList.remove(i - 1);

                                        } else if (i == (photoList.size() - 1)) {
                                            if (isPre) {
                                                photoList.remove(i);
                                                photoList.remove(i - 1);
                                            } else {
                                                photoList.remove(i);
                                            }
                                        } else {
                                            photoList.remove(i);
                                        }

                                        if (i != 0) {
                                            i--;
                                        }

                                        if (d == deleteList.size() - 1) {
                                            break;
                                        }

                                    }

                                }

                            }
                        }

                        if (adapter != null) {
                            adapter.notifyDataSetChanged();
                        }
                        if (photoList != null && photoList.size() != 0) {
                            recyclerView.setVisibility(View.VISIBLE);
                            loutNoData.setVisibility(View.GONE);
                        } else {
                            recyclerView.setVisibility(View.GONE);
                            loutNoData.setVisibility(View.VISIBLE);
                        }
                    }

                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }


    private void displayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DisplayDeleteEvent>() {
            @Override
            public void call(DisplayDeleteEvent event) {

                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> deleteList = new ArrayList<>();
                    deleteList = event.getDeleteList();


                    if (photoList != null && photoList.size() != 0) {

                        for (int d = 0; d < deleteList.size(); d++) {

                            for (int i = 0; i < photoList.size(); i++) {

                                if (photoList.get(i) instanceof PhotoData) {
                                    PhotoData model = (PhotoData) photoList.get(i);

                                    if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {

                                        boolean isPre = false, isNext = false;

                                        if (i != 0) {
                                            if (photoList.get(i - 1) instanceof PhotoHeader) {
                                                isPre = true;
                                            } else {
                                                isPre = false;
                                            }
                                        }

                                        if (i < (photoList.size() - 2)) {
                                            if (photoList.get(i + 1) instanceof PhotoHeader) {
                                                isNext = true;
                                            } else {
                                                isNext = false;
                                            }
                                        }

                                        if (isPre && isNext) {
                                            //  objectList.remove(i + 1);
                                            photoList.remove(i);
                                            photoList.remove(i - 1);

                                        } else if (i == (photoList.size() - 1)) {
                                            if (isPre) {
                                                photoList.remove(i);
                                                photoList.remove(i - 1);
                                            } else {
                                                photoList.remove(i);
                                            }
                                        } else {
                                            photoList.remove(i);
                                        }

                                        if (i != 0) {
                                            i--;
                                        }

                                        if (d == deleteList.size() - 1) {
                                            break;
                                        }

                                    }

                                }

                            }
                        }

                        if (adapter != null) {
                            adapter.notifyDataSetChanged();
                        }
                        if (photoList != null && photoList.size() != 0) {
                            recyclerView.setVisibility(View.VISIBLE);
                            loutNoData.setVisibility(View.GONE);
                        } else {
                            recyclerView.setVisibility(View.GONE);
                            loutNoData.setVisibility(View.VISIBLE);
                        }
                    }

                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void deleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DeleteEvent>() {
            @Override
            public void call(DeleteEvent event) {

                if (event.getPos() != -1) {
                    if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                        ArrayList<String> deleteList = new ArrayList<>();
                        deleteList = event.getDeleteList();


                        if (photoList != null && photoList.size() != 0) {

                            for (int d = 0; d < deleteList.size(); d++) {

                                for (int i = 0; i < photoList.size(); i++) {

                                    if (photoList.get(i) instanceof PhotoData) {
                                        PhotoData model = (PhotoData) photoList.get(i);

                                        if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {

                                            boolean isPre = false, isNext = false;

                                            if (i != 0) {
                                                if (photoList.get(i - 1) instanceof PhotoHeader) {
                                                    isPre = true;
                                                } else {
                                                    isPre = false;
                                                }
                                            }

                                            if (i < (photoList.size() - 2)) {
                                                if (photoList.get(i + 1) instanceof PhotoHeader) {
                                                    isNext = true;
                                                } else {
                                                    isNext = false;
                                                }
                                            }

                                            if (isPre && isNext) {
                                                //  objectList.remove(i + 1);
                                                photoList.remove(i);
                                                photoList.remove(i - 1);

                                            } else if (i == (photoList.size() - 1)) {
                                                if (isPre) {
                                                    photoList.remove(i);
                                                    photoList.remove(i - 1);
                                                } else {
                                                    photoList.remove(i);
                                                }
                                            } else {
                                                photoList.remove(i);
                                            }

                                            if (i != 0) {
                                                i--;
                                            }

                                            if (d == deleteList.size() - 1) {
                                                break;
                                            }

                                        }

                                    }

                                }
                            }

                            if (adapter != null) {
                                adapter.notifyDataSetChanged();
                            }
                            if (photoList != null && photoList.size() != 0) {
                                recyclerView.setVisibility(View.VISIBLE);
                                loutNoData.setVisibility(View.GONE);
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                loutNoData.setVisibility(View.VISIBLE);
                            }
                        }

                    }
                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    public void OnSelected(boolean isShowToolbar, boolean isShowSelected, int selected) {
        if (isShowToolbar) {
            loutToolbar.setVisibility(View.VISIBLE);
        } else {
            loutToolbar.setVisibility(View.GONE);
        }

        if (isShowSelected) {
            loutSelect.setVisibility(View.VISIBLE);
            loutSelectBottom.setVisibility(View.VISIBLE);
        } else {
            loutSelect.setVisibility(View.GONE);
            loutSelectBottom.setVisibility(View.GONE);
        }
        txtSelect.setText(selected + " Selected");

    }

    private void showDeleteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(FavoriteListActivity.this, R.style.AppCompatAlert);
        builder.setMessage("Are you sure do you want to delete it?");
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (loadingDialog != null)
                    if (!loadingDialog.isShowing()) {
                        loadingDialog.setMessage("Delete image...");
                        loadingDialog.show();
                    }

                new Thread(this::deletePhoto).start();
            }

            private void deletePhoto() {

                ArrayList<String> deleteList = new ArrayList<>();
                for (int i = 0; i < photoList.size(); i++) {

                    if (photoList.get(i) != null)
                        if (photoList.get(i) instanceof PhotoData) {

                            PhotoData model = (PhotoData) photoList.get(i);
                            if (model.isSelected()) {

                                File file = new File(model.getFilePath());
                                Uri deleteUrl = FileProvider.getUriForFile(FavoriteListActivity.this, getApplicationContext().getPackageName() + ".provider", file);
                                ContentResolver contentResolver = getContentResolver();
                                contentResolver.delete(deleteUrl, null, null);

                                MediaScannerConnection.scanFile(FavoriteListActivity.this, new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                    public void onScanCompleted(String path, Uri uri) {
                                        // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                                    }
                                });


                                try {
                                    FileUtils.deleteDirectory(file);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                deleteList.add(file.getPath());
                            } else {

                                model.setCheckboxVisible(false);
                            }

                        }
                }

                for (int i = 0; i < photoList.size(); i++) {
                    if (photoList.get(i) != null)

                        if (photoList.get(i) instanceof PhotoData) {
                            PhotoData model = (PhotoData) photoList.get(i);
                            if (model.isSelected()) {
                                boolean isPre = false, isNext = false;

                                if (i != 0) {
                                    if (photoList.get(i - 1) instanceof PhotoHeader) {
                                        isPre = true;
                                    } else {
                                        isPre = false;
                                    }
                                }

                                if (i < (photoList.size() - 2)) {
                                    if (photoList.get(i + 1) instanceof PhotoHeader) {
                                        isNext = true;
                                    } else {
                                        isNext = false;
                                    }
                                }

                                if (isPre && isNext) {
                                    //  objectList.remove(i + 1);
                                    photoList.remove(i);
                                    photoList.remove(i - 1);

                                } else if (i == (photoList.size() - 1)) {
                                    if (isPre) {
                                        photoList.remove(i);
                                        photoList.remove(i - 1);
                                    } else {
                                        photoList.remove(i);
                                    }
                                } else {
                                    photoList.remove(i);
                                }

                                if (i != 0) {
                                    i--;
                                }
                            }
                        }
                }

                runOnUiThread(() -> {
                    if (loadingDialog != null)
                        if (loadingDialog.isShowing()) {
                            loadingDialog.dismiss();
                        }


                    RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                    selected_Item = 0;
                    OnSelected(true, false, 0);
                    if (adapter != null)
                        adapter.notifyDataSetChanged();
                    if (photoList != null && photoList.size() != 0) {
                        recyclerView.setVisibility(View.VISIBLE);
                        loutNoData.setVisibility(View.GONE);
                    } else {
                        recyclerView.setVisibility(View.GONE);
                        loutNoData.setVisibility(View.VISIBLE);
                    }
                    Toast.makeText(FavoriteListActivity.this, "Delete image successfully", Toast.LENGTH_SHORT).show();
                });

            }

        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }

}