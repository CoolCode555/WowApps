package com.phone.photography.gallery.photovideo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SelectAlbumAdapter extends RecyclerView.Adapter<SelectAlbumAdapter.ViewHolder> {

    Context context;

    List<PhotoHeader> albumList = new ArrayList<>();
    private static ClickListener listener;


    public SelectAlbumAdapter(Context context, List<PhotoHeader> albumList) {
        this.context = context;
        this.albumList = albumList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_album_select, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        if (albumList.get(holder.getAdapterPosition()) != null) {
            holder.addImage.setVisibility(View.GONE);
            holder.image.setVisibility(View.VISIBLE);

            holder.txtAlbumName.setVisibility(View.VISIBLE);

            if (albumList.get(holder.getAdapterPosition()).getTitle() != null && !albumList.get(holder.getAdapterPosition()).getTitle().equalsIgnoreCase("")) {
                holder.txtAlbumName.setText(albumList.get(holder.getAdapterPosition()).getTitle());
            } else {
                holder.txtAlbumName.setText(" ");
            }
            if (albumList.get(holder.getAdapterPosition()).getPhotoList() != null && albumList.get(holder.getAdapterPosition()).getPhotoList().size() != 0) {
                Glide.with(context).load(albumList.get(holder.getAdapterPosition()).getPhotoList().get(0).getFilePath()).placeholder(R.drawable.ic_image_placeholder).error(R.drawable.ic_image_placeholder).into(holder.image);
            }

            if (albumList.get(position).isSelect()){
                holder.iv_select.setVisibility(View.VISIBLE);
            } else {
                holder.iv_select.setVisibility(View.GONE);
            }

        } else {

            holder.addImage.setVisibility(View.VISIBLE);
            holder.txtAlbumName.setText("New folder");
            holder.image.setVisibility(View.GONE);

            holder.txtAlbumName.setVisibility(View.VISIBLE);


        }
    }

    @Override
    public int getItemCount() {
        return albumList.size();
    }

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.listener = clickListener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        @BindView(R.id.image)
        AppCompatImageView image;
        @BindView(R.id.add_image)
        AppCompatImageView addImage;
        @BindView(R.id.txt_album_name)
        AppCompatTextView txtAlbumName;

        @BindView(R.id.iv_un_select)
        AppCompatImageView iv_un_select;
        @BindView(R.id.iv_select)
        AppCompatImageView iv_select;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            listener.onItemClick(getAdapterPosition(), view);
        }
    }
}
