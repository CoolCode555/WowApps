package com.phone.photography.gallery.photovideo.edit;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.edit.imagezoom.ImageViewTouch;
import com.phone.photography.gallery.photovideo.edit.imagezoom.ImageViewTouchBase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import iamutkarshtiwari.github.io.ananas.editimage.fliter.PhotoProcessing;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class BeautyActivity extends AppCompatActivity {

    private ImageView img_close;
    private ImageView img_save;
    private ImageViewTouch img_beauty_path;
    private SeekBar white_skin_value_bar;
    private SeekBar smooth_value_bar;

    private CompositeDisposable disposable = new CompositeDisposable();
    private Disposable beautyDisposable;
    private Bitmap finalBmp;

    private String imagePath;

    private int smooth = 0;
    private int whiteSkin = 0;

    private ProgressDialog loadingDialog;
    private String TAG="BeatyActivity";
    private String outputPath;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        setContentView(R.layout.activity_beauty);

        init();
        click();

    }

    private void init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getResources().getColor(R.color.black, this.getTheme()));
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.black));
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.black));
            getWindow().setStatusBarColor(getResources().getColor(R.color.black));
        }
        imagePath = getIntent().getStringExtra("imagePath");
        outputPath=getIntent().getStringExtra("outputPath");

        img_close = findViewById(R.id.img_close);
        img_save = findViewById(R.id.img_save);

        loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);
        loadingDialog.setMessage("Applying");

        img_beauty_path = findViewById(R.id.img_beauty_path);
        img_beauty_path.setDisplayType(ImageViewTouchBase.DisplayType.FIT_TO_SCREEN);
        Glide.with(this).asBitmap().load(imagePath).apply(RequestOptions.skipMemoryCacheOf(true))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE)).into(new CustomTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                img_beauty_path.setImageBitmap(bitmap);
                finalBmp = bitmap;
            }

            @Override
            public void onLoadCleared(Drawable placeholder) {
            }
        });

        white_skin_value_bar = findViewById(R.id.white_skin_value_bar);
        smooth_value_bar = findViewById(R.id.smooth_value_bar);

    }

    private void click() {
        img_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        img_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: save");
                applyBeauty();
            }
        });
        white_skin_value_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                doBeautyTask();
            }
        });

        smooth_value_bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                doBeautyTask();
            }
        });
    }

    protected void doBeautyTask() {
        if (beautyDisposable != null && !beautyDisposable.isDisposed()) {
            beautyDisposable.dispose();
        }
        smooth = smooth_value_bar.getProgress();
        whiteSkin = white_skin_value_bar.getProgress();

        if (smooth == 0 && whiteSkin == 0) {
            img_beauty_path.setImageBitmap(finalBmp);
            return;
        }
        beautyDisposable = beautify(smooth, whiteSkin)
                .subscribeOn(Schedulers.computation())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(subscriber -> loadingDialog.show())
                .doFinally(() -> loadingDialog.dismiss())
                .subscribe(bitmap -> {
                    if (bitmap == null)
                        return;
                    Log.d(TAG, "doBeautyTask: ");
                    img_beauty_path.setImageBitmap(bitmap);
                    finalBmp = bitmap;

                }, e -> {
                    // Do nothing on error
                });
        disposable.add(beautyDisposable);
    }
    public void applyBeauty() {
        if (finalBmp != null && (smooth != 0 || whiteSkin != 0)) {
            try {
//                String path = Environment.getExternalStorageDirectory().toString();
                OutputStream fOut = null;
                File file = new File(outputPath);
                if (file.exists())
                {
                    file.delete();// the File to save , append increasing numeric counter to prevent files from getting overwritten.
                }
                fOut = new FileOutputStream(file);

                Bitmap pictureBitmap = finalBmp; // obtaining the Bitmap
                pictureBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut); // saving the Bitmap to a file compressed as a JPEG with 85% compression rate
                fOut.flush(); // Not really required
                fOut.close(); // do not forget to close the stream
                Intent intent = new Intent();
                intent.putExtra("cropPath", file.getAbsolutePath());
                setResult(RESULT_OK, intent);
                finish();
            } catch (Exception e) {
            }
        }

    }
    private Single<Bitmap> beautify(int smoothVal, int whiteSkinVal) {
        return Single.fromCallable(() -> {
            try {
                Bitmap srcBitmap = Bitmap.createBitmap(
                        finalBmp.copy(
                                Bitmap.Config.ARGB_8888, true)
                );
                PhotoProcessing.handleSmoothAndWhiteSkin(srcBitmap, smoothVal, whiteSkinVal);
                return srcBitmap;
            }catch (Exception e){
                e.printStackTrace();
                return  null;
            }

        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        disposable.dispose();
    }

    @Override
    public void onPause() {
        super.onPause();
        disposable.clear();
    }
    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        finish();
    }
}
