package com.phone.photography.gallery.photovideo.model;

import java.util.ArrayList;

public class AlbumCreateEvent {
    //move file list
    ArrayList<String> deleteList = new ArrayList<>();

    // delete file list
    ArrayList<String> deleteFileList = new ArrayList<>();
    String albumName;
    public AlbumCreateEvent(ArrayList<String> deleteList, String albumName, ArrayList<String>  deleteFileList) {
        this.deleteList = deleteList;
        this.albumName = albumName;
        this.deleteFileList = deleteFileList;
    }

    public ArrayList<String> getDeleteList() {
        return deleteList;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public void setDeleteList(ArrayList<String> deleteList) {
        this.deleteList = deleteList;

    }

    public ArrayList<String> getDeleteFileList() {
        return deleteFileList;
    }

    public void setDeleteFileList(ArrayList<String> deleteFileList) {
        this.deleteFileList = deleteFileList;
    }
}
