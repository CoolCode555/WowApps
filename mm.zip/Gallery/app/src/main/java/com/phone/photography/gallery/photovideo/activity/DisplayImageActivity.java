package com.phone.photography.gallery.photovideo.activity;

import static com.phone.photography.gallery.photovideo.util.AppUtils.deleteFileOnAboveQ;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;
import androidx.viewpager.widget.ViewPager;

import com.customlibraries.adsutils.AdsUtils;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.adapter.DisplayImageAdapter;

import com.phone.photography.gallery.photovideo.edit.EditActivity;
import com.phone.photography.gallery.photovideo.model.DeleteEvent;
import com.phone.photography.gallery.photovideo.model.DisplayDeleteEvent;
import com.phone.photography.gallery.photovideo.model.DisplayUnFavoriteEvent;
import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;
import com.phone.photography.gallery.photovideo.oncliclk.ImageToolbar;
import com.phone.photography.gallery.photovideo.service.ImageDataService;
import com.phone.photography.gallery.photovideo.util.Constant;
import com.phone.photography.gallery.photovideo.util.PreferencesUtility;
import com.phone.photography.gallery.photovideo.util.RxBus;
import com.phone.photography.gallery.photovideo.util.Utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DisplayImageActivity extends AppCompatActivity implements ImageToolbar {

    @BindView(R.id.viewPager)
    ViewPager viewPager;
    @BindView(R.id.iv_back)
    ImageView ivBack;
    @BindView(R.id.txt_title)
    TextView txtTitle;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.lout_edit)
    LinearLayout loutEdit;
    @BindView(R.id.lout_share)
    LinearLayout loutShare;
    @BindView(R.id.lout_delete)
    LinearLayout loutDelete;
    @BindView(R.id.iv_fav)
    ImageView ivFav;
    @BindView(R.id.lout_fav)
    LinearLayout loutFav;
    @BindView(R.id.ll_bottom)
    LinearLayout llBottom;
    @BindView(R.id.txt_fav)
    TextView txtFav;
    @BindView(R.id.txt_edit)
    TextView txtEdit;
    @BindView(R.id.txt_share)
    TextView txtShare;
    @BindView(R.id.txt_delete)
    TextView txtDelete;
    @BindView(R.id.txt_more)
    TextView txtMore;
    @BindView(R.id.lout_more)
    LinearLayout loutMore;
    @BindView(R.id.iv_more)
    ImageView ivMore;

    int position = -1;
    int adCount = 0;
    List<PhotoData> displayImageList = new ArrayList<>();
    DisplayImageAdapter adapter;

    boolean isFavList = false;
    boolean isSlideshow = false;
    boolean isSlideshowStart = false;

    Handler handler;

    private int deletepos;
    private ArrayList<String> deleteList;

    private ActivityResultLauncher<IntentSenderRequest> deleteIntentSenderLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        setContentView(R.layout.activity_display_image);
        ButterKnife.bind(this);
        AdsUtils.loadInterstitialAds(DisplayImageActivity.this, true);

//        loadAdsOld = LoadAdsOld.getInstance(DisplayImageActivity.this);
        intView();
        setDeleteIntentLauncher();
    }

    private void setDeleteIntentLauncher() {
        this.deleteIntentSenderLauncher = registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    displayImageList.remove(viewPager.getCurrentItem());
                    adapter.notifyDataSetChanged();
                    adapter = new DisplayImageAdapter(DisplayImageActivity.this, displayImageList, DisplayImageActivity.this);
                    viewPager.setAdapter(adapter);

                    RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));

                    if (deletepos < displayImageList.size() - 1) {
                        position = deletepos;
                        viewPager.setCurrentItem(deletepos);
                        int pos = viewPager.getCurrentItem();
                        txtTitle.setText(displayImageList.get(pos).getFileName());
                    } else {
                        if (displayImageList.size() == 0) {
                            onBackPressed();
                        } else {
                            try {
                                viewPager.setCurrentItem(deletepos - 1);
                                int pos = viewPager.getCurrentItem();
                                txtTitle.setText(displayImageList.get(pos).getFileName());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    }


                } else if (result.getResultCode() == Activity.RESULT_CANCELED) {
//                    selected_Item = 0;
//                    setClose();
                }


            }
        });
    }


    private void intView() {
        displayImageList = Constant.displayImageList;
        Intent intent = getIntent();
        if (intent != null) {
            position = intent.getIntExtra("pos", 0);
            isFavList = intent.getBooleanExtra("IsFavList", false);
        }

        try {

            adapter = new DisplayImageAdapter(this, displayImageList, this);
            viewPager.setAdapter(adapter);
            viewPager.setCurrentItem(position);
            int pos = position;
            pos++;
            txtTitle.setText(pos + "/" + displayImageList.size());

            if (!isFavList) {
                if (displayImageList != null && displayImageList.size() != 0) {
                    new Thread(this::serFavoriteData).start();
                }
            } else {
                updateFavData();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int i) {
                position = i;

                adCount++;
                updateFavData();
//                txtTitle.setText(displayImageList.get(i).getFileName());
                int pos = position;
                pos++;
                txtTitle.setText(pos + "/" + displayImageList.size());
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void updateFavData() {
        if (displayImageList.get(viewPager.getCurrentItem()).isFavorite()) {

            ivFav.setImageDrawable(getResources().getDrawable(R.drawable.ic_fav_fill));
            txtFav.setTextColor(getResources().getColor(R.color.colorPrimary));

        } else {
            ivFav.setImageDrawable(getResources().getDrawable(R.drawable.ic_fav_unfill));
            txtFav.setTextColor(getResources().getColor(R.color.white));

        }
    }

    private void serFavoriteData() {

        List<String> favList = PreferencesUtility.getFavoriteList(DisplayImageActivity.this);

        for (int i = 0; i < displayImageList.size(); i++) {
            displayImageList.get(i).setFavorite(false);
        }

        if (favList != null && favList.size() != 0) {

            for (int f = 0; f < favList.size(); f++) {
                for (int i = 0; i < displayImageList.size(); i++) {

                    if (displayImageList.get(i).getFilePath() != null && !displayImageList.get(i).getFilePath().equalsIgnoreCase(""))

                        if (favList.get(f).equalsIgnoreCase(displayImageList.get(i).getFilePath())) {
                            displayImageList.get(i).setFavorite(true);

                            break;
                        }

                }

            }

        }


        runOnUiThread(() -> {
            updateFavData();
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == 101) {
//           /* if (isSlideshow) {
//                if (isSlideshowStart) {
//                    startSlideshow();
//                }
//            }*/
//        }
    }

    @OnClick({R.id.iv_back, R.id.lout_edit, R.id.lout_share, R.id.lout_delete, R.id.lout_fav, R.id.lout_more})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.lout_more:
                showMoreDialog();
                break;
            case R.id.lout_edit:
                if (isSlideshow) {
                    if (isSlideshowStart) {
                        stopSlideshow();
                    }
                }
                try {


                    File output = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath() + "/" + getString(R.string.app_name));

                    if (!output.exists()) {
                        output.mkdirs();
                    }

                    String timeStamp = new SimpleDateFormat("HHmmss_dMyy").format(new Date());
                    String fileName = "IMG_" + timeStamp + ".jpeg";

                    String strOutput = output.getPath() + "/" + fileName;

                    Intent intent = new Intent(this, EditActivity.class);
                    intent.putExtra("imagePath", displayImageList.get(viewPager.getCurrentItem()).getFilePath());
                    intent.putExtra("outputPath", strOutput);

                    startActivityForResult(intent, 101);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case R.id.lout_share:
                String extra_text = "https://play.google.com/store/apps/details?id=" + getPackageName();
                File file = new File(displayImageList.get(position).getFilePath());
                Uri uri = FileProvider.getUriForFile(getApplicationContext(), getPackageName() + ".provider", file);
                Intent shareIntent = new Intent();
                shareIntent.setAction("android.intent.action.SEND");
                shareIntent.setType(Constant.getMimeTypeFromFilePath(file.getPath()));
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));
                shareIntent.putExtra(Intent.EXTRA_TEXT, extra_text);
                shareIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                shareIntent.putExtra(Intent.EXTRA_STREAM, uri);

                startActivity(Intent.createChooser(shareIntent, "Share with..."));
                break;
            case R.id.lout_delete:
                if (isSlideshow) {
                    if (isSlideshowStart) {
                        stopSlideshow();
                    }
                }
                deleteDialog();
                break;
            case R.id.lout_fav:
                if (displayImageList.get(viewPager.getCurrentItem()).isFavorite()) {
                    ivFav.setImageDrawable(getResources().getDrawable(R.drawable.ic_fav_unfill));
                    txtFav.setTextColor(getResources().getColor(R.color.white));
                    displayImageList.get(viewPager.getCurrentItem()).setFavorite(false);

                    setUnFavorite(displayImageList.get(viewPager.getCurrentItem()).getFilePath());

                    if (isFavList) {
                        int finalI = viewPager.getCurrentItem();
                        ArrayList<String> deleteList = new ArrayList<>();
                        deleteList.add(displayImageList.get(viewPager.getCurrentItem()).getFilePath());

                        displayImageList.remove(viewPager.getCurrentItem());
                        adapter.notifyDataSetChanged();

                        adapter = new DisplayImageAdapter(DisplayImageActivity.this, displayImageList, DisplayImageActivity.this);
                        viewPager.setAdapter(adapter);

                        RxBus.getInstance().post(new DisplayUnFavoriteEvent(deleteList));

                        if (finalI < displayImageList.size() - 1) {
                            position = finalI;
                            viewPager.setCurrentItem(finalI);
                            int pos = viewPager.getCurrentItem();
                            pos++;
                            updateFavData();
                            txtTitle.setText(pos + "/" + displayImageList.size());

                        } else {
                            if (displayImageList.size() == 0) {
                                onBackPressed();
                            } else {
                                try {
                                    viewPager.setCurrentItem(finalI - 1);
                                    int pos = viewPager.getCurrentItem();
                                    pos++;
                                    updateFavData();
                                    txtTitle.setText(pos + "/" + displayImageList.size());
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }
                        }

                    }
                } else {
                    ivFav.setImageDrawable(getResources().getDrawable(R.drawable.ic_fav_fill));
                    txtFav.setTextColor(getResources().getColor(R.color.colorPrimary));
                    displayImageList.get(viewPager.getCurrentItem()).setFavorite(true);

                    setFavorite(displayImageList.get(viewPager.getCurrentItem()).getFilePath());
                }
                break;

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("DisplayScreen", "onResume");
        if (isSlideshow) {
            if (isSlideshowStart) {
                startSlideshow();
            }
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e("DisplayScreen", "onRestart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("DisplayScreen", "onPause");
        if (isSlideshow) {
            if (isSlideshowStart) {
                stopSlideshow();
            }
        }
    }

    private void startSlideshow() {
        isSlideshow = true;
        isSlideshowStart = true;
        slideShow(viewPager.getCurrentItem());
    }

    private void stopSlideshow() {
        handler.removeCallbacksAndMessages(null);
    }

    private void showMoreDialog() {
     /*   Context wrapper = new ContextThemeWrapper(getApplicationContext(),
                R.style.YourActionBarWidget);*/

        final PopupMenu popup = new PopupMenu(this, ivMore);
        // Inflate the menu from xml

        popup.getMenuInflater().inflate(R.menu.menu_more_popup, popup.getMenu());

        if (!isSlideshow) {
            popup.getMenu().findItem(R.id.menu_startslideshow).setTitle("Start slideshow");

        } else {
            popup.getMenu().findItem(R.id.menu_startslideshow).setTitle("Stop slideshow");

        }

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menu_startslideshow:

                        if (!isSlideshow) {
                            item.setTitle("Stop slideshow");
                            isSlideshow = true;
                            isSlideshowStart = true;
                            slideShow(viewPager.getCurrentItem());
                        } else {

                            item.setTitle("Start slideshow");
                            isSlideshow = false;
                            isSlideshowStart = false;
                            handler.removeCallbacksAndMessages(null);

                        }
                        return true;

                    default:
                        return false;
                }

            }
        });

        popup.show();

    }

    public void slideShow(final int count) {

        try {


            handler = new Handler();
            handler.postDelayed(new Runnable() {
                int item_count = count;

                @Override
                public void run() {
              /*  item_count = viewPager.getCurrentItem();
                item_count++;*/
                    item_count++;
                    if (item_count < displayImageList.size()) {
                        viewPager.setCurrentItem(item_count);

                        if (item_count == displayImageList.size() - 1) {
                            isSlideshow = false;
                            handler.removeCallbacksAndMessages(null);
//                    item_count = 0;
                        } else {
//                    item_count++;
                        }
                        if (isSlideshow) {
                            handler.postDelayed(this, PreferencesUtility.getSlideshowInterval(DisplayImageActivity.this) * 1000);
                        }
                    } else {
                        isSlideshow = false;
                        handler.removeCallbacksAndMessages(null);
                    }
                }
            }, PreferencesUtility.getSlideshowInterval(DisplayImageActivity.this) * 1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setUnFavorite(String filePath) {
        List<String> favList = PreferencesUtility.getFavoriteList(DisplayImageActivity.this);

        if (favList == null) {
            favList = new ArrayList<>();
        }

        for (int f = 0; f < favList.size(); f++) {

            if (favList.get(f) != null && !favList.get(f).equalsIgnoreCase("")) {

                if (favList.get(f).equalsIgnoreCase(filePath)) {
                    favList.remove(f);
                    break;
                }

            }
        }

        PreferencesUtility.setFavoriteList(DisplayImageActivity.this, favList);
    }

    private void setFavorite(String filePath) {
        List<String> favList = PreferencesUtility.getFavoriteList(DisplayImageActivity.this);

        if (favList == null) {
            favList = new ArrayList<>();
        }

        favList.add(filePath);
        PreferencesUtility.setFavoriteList(DisplayImageActivity.this, favList);
    }




    @Override
    public void OnImageToolbar(View v) {
        if (llBottom.getVisibility() == View.VISIBLE || toolbar.getVisibility() == View.VISIBLE) {
            toolbar.setVisibility(View.GONE);
            llBottom.setVisibility(View.GONE);
        } else {
            toolbar.setVisibility(View.VISIBLE);
            llBottom.setVisibility(View.VISIBLE);
        }
    }


    private void deleteDialog() {

        final int i = viewPager.getCurrentItem();

        deletepos = i;
        deleteList = new ArrayList<>();

        ArrayList<PhotoData> selectedFile = new ArrayList<>();

        if (Utils.isVersionQAbove()) {

            int currentItem = viewPager.getCurrentItem();
            deleteList.add(displayImageList.get(currentItem).getFilePath());
            if (selectedFile.contains(displayImageList.get(currentItem))) {
                selectedFile.remove(displayImageList.get(currentItem));
            } else {
                selectedFile.add(displayImageList.get(currentItem));
            }
            IntentSender deleteFileOnAboveQ = deleteFileOnAboveQ(deleteList, this);
            if (deleteFileOnAboveQ != null) {
                deleteIntentSenderLauncher.launch(new IntentSenderRequest.Builder(deleteFileOnAboveQ).build());
            }

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(DisplayImageActivity.this, R.style.AppCompatAlert);
            builder.setMessage("Are you sure do you want to delete it?");
            builder.setCancelable(false);

            int finalI = i;
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {

                    ArrayList<String> deleteList = new ArrayList<>();

                    File file1 = new File(displayImageList.get(viewPager.getCurrentItem()).getFilePath());
                    Uri deleteUrl = FileProvider.getUriForFile(DisplayImageActivity.this, getPackageName() + ".provider", file1);
                    ContentResolver contentResolver = getContentResolver();
                    contentResolver.delete(deleteUrl, null, null);
                    try {
                        FileUtils.deleteDirectory(file1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    deleteList.add(file1.getPath());
                    MediaScannerConnection.scanFile(DisplayImageActivity.this, new String[]{file1.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                        }
                    });


                    displayImageList.remove(viewPager.getCurrentItem());
                    adapter.notifyDataSetChanged();

                    adapter = new DisplayImageAdapter(DisplayImageActivity.this, displayImageList, DisplayImageActivity.this);
                    viewPager.setAdapter(adapter);

                    RxBus.getInstance().post(new DisplayDeleteEvent(deleteList));

                    if (finalI < displayImageList.size() - 1) {
                        position = finalI;
                        viewPager.setCurrentItem(finalI);
                        int pos = viewPager.getCurrentItem();
                        pos++;
                        txtTitle.setText(pos + "/" + displayImageList.size());
                        dialogInterface.dismiss();
                        if (isSlideshow) {
                            if (isSlideshowStart) {
                                startSlideshow();
                            }
                        }
                    } else {
                        if (displayImageList.size() == 0) {
                            onBackPressed();
                        } else {
                            try {
                                viewPager.setCurrentItem(finalI - 1);
                                int pos = viewPager.getCurrentItem();
                                pos++;
                                txtTitle.setText(pos + "/" + displayImageList.size());
                                dialogInterface.dismiss();
                                if (isSlideshow) {
                                    if (isSlideshowStart) {
                                        startSlideshow();
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    }


                }
            });

            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    if (isSlideshow) {
                        if (isSlideshowStart) {
                            startSlideshow();
                        }
                    }
                }
            });

            builder.show();

        }


    }


}