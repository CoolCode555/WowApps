package com.phone.photography.gallery.photovideo.util;

import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.webkit.MimeTypeMap;

import com.phone.photography.gallery.photovideo.activity.ImageSelectActivity;
import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class Constant {

//   public static boolean IS_APP_FIRST = true;
   public static int IS_APP_Count = 1;
   public static boolean HIDE_GIFT_OPEN_ADS = false;

   public static PhotoHeader folderData;
   public static List<PhotoData> displayImageList = new ArrayList<>();

   public  static  int VIDEO_PLAY_INTENT = 101 ;

   public static final String PREF_RATE_US = "pref_rate_us";
   public static final String PREF_SLIDESHOW_INTERVAL = "pref_slideshow_interval";
   public static final String PREF_FAVORITE_LIST = "pref_favorite_list";

   public static boolean isShowFirstADs = false;

   public static String getMimeTypeFromFilePath(String filePath) {
      String mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(getFilenameExtension(filePath));
      return (mimeType == null) ? null : mimeType;
   }

   public static String getFilenameExtension(String path) {
      return path.substring(path.lastIndexOf(".") + 1);
   }

   public static final int STICKER_BTN_HALF_SIZE = 30;


   public static void copyDirectoryOneLocationToAnotherLocation(Context context,File sourceLocation, File targetLocation)
           throws IOException {

      if (sourceLocation.isDirectory()) {
         if (!targetLocation.exists()) {
            targetLocation.mkdir();
         }

         String[] children = sourceLocation.list();
         for (int i = 0; i < sourceLocation.listFiles().length; i++) {

            copyDirectoryOneLocationToAnotherLocation(context,new File(sourceLocation, children[i]),
                    new File(targetLocation, children[i]));
         }
      } else {

         InputStream in = new FileInputStream(sourceLocation);

         OutputStream out = new FileOutputStream(targetLocation);

         // Copy the bits from instream to outstream
         byte[] buf = new byte[1024];
         int len;
         while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
         }
         in.close();
         out.close();

         Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);

         Uri contentUri = Uri.fromFile(targetLocation );
         mediaScanIntent.setData(contentUri);
         context.sendBroadcast(mediaScanIntent);
         MediaScannerConnection.scanFile(context, new String[]{targetLocation.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
            public void onScanCompleted(String path, Uri uri) {
               // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
            }
         });
      }

   }
}
