package com.phone.photography.gallery.photovideo.service;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;
import com.phone.photography.gallery.photovideo.util.NotificationUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.schedulers.Schedulers;

public class VideoDataService extends Service {

    public static boolean isComplete = false;

    public static List<Object> videoList = new ArrayList<>();


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification notification = new NotificationCompat.Builder(this, NotificationUtils.ANDROID_CHANNEL_ID)
                        .setContentTitle("")
                        .setContentText("").build();

                startForeground(1, notification);
                stopForeground(STOP_FOREGROUND_REMOVE);
            }
        } catch (RuntimeException e) {

        }

        videoList = new ArrayList<>();
        isComplete = false;
        Observable.fromCallable(() -> {
            getVideoList();
            return true;
        }).subscribeOn(Schedulers.io())
                .doOnError(throwable -> {
                    isComplete = true;
                    Intent intent1 = new Intent("LoardDataComplete");
                    intent1.putExtra("completed", true);
                    sendBroadcast(intent1);
                })
                .subscribe((result) -> {
                    isComplete = true;
                    Intent intent1 = new Intent("LoardDataComplete");
                    intent1.putExtra("completed", true);
                    sendBroadcast(intent1);
                });

        return super.onStartCommand(intent, flags, startId);
    }

    private void getVideoList() {

        LinkedHashMap<String, ArrayList<PhotoData>> bucketVideoMap = new LinkedHashMap<>();
        int thumbnails;
        String absolutePathOfImage = null;
        String path = null;
        int duration;


        SimpleDateFormat format = new SimpleDateFormat("MMM yyyy");

        Uri uri;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            uri = android.provider.MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else
            uri = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {MediaStore.Video.VideoColumns.DATA, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Thumbnails.DATA, MediaStore.Video.VideoColumns.DURATION,
                MediaStore.Video.VideoColumns.DATE_MODIFIED};
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);


        if (cursor != null) {

            thumbnails = cursor.getColumnIndexOrThrow(MediaStore.Video.Thumbnails.DATA);
            duration = cursor.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION);

            for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
                path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA));
                absolutePathOfImage = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME));

                long d = cursor.getLong(cursor.getColumnIndex(MediaStore.Video.VideoColumns.DATE_MODIFIED));
                d = d * 1000;
                String strDate = format.format(d);

                String dur = getDurationString(cursor.getInt(duration));

                PhotoData imagesData = new PhotoData();
                imagesData.setFilePath(path);
                imagesData.setFileName(absolutePathOfImage);
                imagesData.setThumbnails(cursor.getString(thumbnails));
                imagesData.setDuration(dur);

                if (bucketVideoMap.containsKey(strDate)) {
                    ArrayList<PhotoData> imagesData1 = bucketVideoMap.get(strDate);
                    if (imagesData1 == null)
                        imagesData1 = new ArrayList<>();

                    imagesData1.add(imagesData);
                    bucketVideoMap.put(strDate, imagesData1);

                } else {
                    ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                    imagesData1.add(imagesData);
                    bucketVideoMap.put(strDate, imagesData1);
                }

            }

            cursor.close();
        }


        Set<String> keys = bucketVideoMap.keySet();
        ArrayList<String> listkeys = new ArrayList<>();
        listkeys.addAll(keys);


        for (int i = 0; i < listkeys.size(); i++) {
            ArrayList<PhotoData> imagesData = bucketVideoMap.get(listkeys.get(i));

            if (imagesData != null && imagesData.size() != 0) {
                PhotoHeader bucketData = new PhotoHeader();

                bucketData.setTitle(listkeys.get(i));
                bucketData.setPhotoList(imagesData);

                videoList.add(bucketData);
                videoList.addAll(imagesData);
            }
        }
//        }
    }

    private String getDurationString(int duration) {

       /* long hours = TimeUnit.MILLISECONDS.toHours(duration);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(duration);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration));

        if (hours == 0) {
            return minutes + ":" + seconds;
        } else
            return hours + ":" + minutes + ":" + seconds;*/

        long hours = TimeUnit.MILLISECONDS.toHours(duration);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(duration);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration));

        String strMin = "";
        if (minutes < 10) {
            strMin = "0" + minutes;
        } else {
            strMin = String.valueOf(minutes);
        }

        String strSec = "";
        if (seconds < 10) {
            strSec = "0" + seconds;
        } else {
            strSec = String.valueOf(seconds);
        }

        String strHour = "";
        if (hours < 10) {
            strHour = "0" + hours;
        } else {
            strHour = String.valueOf(hours);
        }

        if (hours == 0) {
            return strMin + ":" + strSec;
        } else
            return strHour + ":" + strMin + ":" + strSec;
    }

}
