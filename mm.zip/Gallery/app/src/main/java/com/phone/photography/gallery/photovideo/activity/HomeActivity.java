package com.phone.photography.gallery.photovideo.activity;

import static com.customlibraries.adsutils.AdsUtils.isNetworkAvailable;
import static com.customlibraries.loadads.LoadAds.strAdaptiveBannerAdsId;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.airbnb.lottie.LottieAnimationView;
import com.customlibraries.adsutils.AdsUtils;
import com.customlibraries.loadads.ExitDialogNative;
import com.customlibraries.loadads.LoadAds;
import com.phone.photography.gallery.photovideo.R;

import com.phone.photography.gallery.photovideo.fragment.AlbumFragment;
import com.phone.photography.gallery.photovideo.fragment.PhotoFragment;
import com.phone.photography.gallery.photovideo.fragment.SettingFragment;
import com.phone.photography.gallery.photovideo.fragment.VideoFragment;
import com.phone.photography.gallery.photovideo.model.ImageCloseEvent;
import com.phone.photography.gallery.photovideo.model.ImageShareDeleteEvent;
import com.phone.photography.gallery.photovideo.oncliclk.OnSelectedHome;
import com.phone.photography.gallery.photovideo.rating.BaseRatingBar;
import com.phone.photography.gallery.photovideo.rating.RotationRatingBar;
import com.phone.photography.gallery.photovideo.util.AppUtils;
import com.phone.photography.gallery.photovideo.util.PreferencesUtility;
import com.phone.photography.gallery.photovideo.util.RxBus;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class HomeActivity extends AppCompatActivity implements OnSelectedHome {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.viewpager)
    ViewPager viewpager;
    @BindView(R.id.iv_tab_one)
    ImageView ivTabOne;
    @BindView(R.id.txt_tab_one)
    TextView txtTabOne;
    @BindView(R.id.lout_tab_one)
    LinearLayout loutTabOne;
    @BindView(R.id.iv_tab_two)
    ImageView ivTabTwo;
    @BindView(R.id.txt_tab_two)
    TextView txtTabTwo;
    @BindView(R.id.lout_tab_two)
    LinearLayout loutTabTwo;
    @BindView(R.id.iv_tab_three)
    ImageView ivTabThree;
    @BindView(R.id.txt_tab_three)
    TextView txtTabThree;
    @BindView(R.id.lout_tab_three)
    LinearLayout loutTabThree;
    @BindView(R.id.iv_tab_four)
    ImageView ivTabFour;
    @BindView(R.id.txt_tab_four)
    TextView txtTabFour;
    @BindView(R.id.lout_tab_four)
    LinearLayout loutTabFour;

    ViewPagerAdapter adapter;

    PhotoFragment photoFragment;
    AlbumFragment albumFragment;
    VideoFragment videoFragment;
    SettingFragment settingFragment;
    @BindView(R.id.txt_toolbar_title)
    TextView txtToolbarTitle;
    @BindView(R.id.lout_toolbar)
    RelativeLayout loutToolbar;
    @BindView(R.id.iv_close_select)
    ImageView ivCloseSelect;
    @BindView(R.id.txt_select)
    TextView txtSelect;
    @BindView(R.id.lout_select)
    RelativeLayout loutSelect;
    @BindView(R.id.tab_layout)
    LinearLayout tabLayout;
    @BindView(R.id.iv_share)
    ImageView ivShare;
    @BindView(R.id.iv_delete)
    ImageView ivDelete;
    @BindView(R.id.lout_select_bottom)
    LinearLayout loutSelectBottom;
    @BindView(R.id.ad_view_container)
    FrameLayout adViewContainer;
    @BindView(R.id.load_animation)
    LottieAnimationView loadAnimation;
    @BindView(R.id.load_animation_2)
    LottieAnimationView loadAnimation2;

    int tabPos = 0;
    float rating_count = 0;
    boolean isAdLoad = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        setContentView(R.layout.activity_home);
//        loadAds = LoadAds.getInstance(HomeActivity.this);
        ButterKnife.bind(this);


        AdsUtils.loadLargerThanMediumSizedNativeAdWithCard(HomeActivity.this, adViewContainer);
        AdsUtils.loadRateUSNativeAd(this, null);


        intView();

        AdsUtils.loadInterstitialAds(HomeActivity.this, false);

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!isAdLoad) {
//            loadBanner();

        }
    }

/*
    private void loadBanner() {
        try {
            loadAds.loadAdaptiveBanner(this, adViewContainer);
            loadAds.getBannerAdView().setAdListener(new ToastAdListener(this) {
                @Override
                public void onAdLoaded() {
                    super.onAdLoaded();
                    isAdLoad = true;

                }

                @Override
                public void onAdFailedToLoad(int errorCode) {
                    super.onAdFailedToLoad(errorCode);

                    isAdLoad = false;

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
*/

    private void intView() {
        txtToolbarTitle.setText(getResources().getText(R.string.app_name));
        loutToolbar.setVisibility(View.VISIBLE);
        tabLayout.setVisibility(View.VISIBLE);
        loutSelect.setVisibility(View.GONE);
        loutSelectBottom.setVisibility(View.GONE);

        adapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewpager.setAdapter(adapter);
        viewpager.setOffscreenPageLimit(adapter.getCount());

        setColorIconAndText();
        ivTabOne.setColorFilter(ContextCompat.getColor(HomeActivity.this, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
        txtTabOne.setTextColor(getResources().getColor(R.color.colorPrimary));

        viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
            }

            @Override
            public void onPageSelected(int i) {
                switch (i) {
                    case 0:
                        txtToolbarTitle.setText(getResources().getText(R.string.app_name));
                        setColorIconAndText();

                        ivTabOne.setColorFilter(ContextCompat.getColor(HomeActivity.this, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
                        txtTabOne.setTextColor(getResources().getColor(R.color.colorPrimary));
                        break;
                    case 1:
                        txtToolbarTitle.setText("Albums");
                        setColorIconAndText();
                        ivTabTwo.setColorFilter(ContextCompat.getColor(HomeActivity.this, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
                        txtTabTwo.setTextColor(getResources().getColor(R.color.colorPrimary));

                        break;
                    case 2:
                        txtToolbarTitle.setText(getResources().getText(R.string.app_name));
                        setColorIconAndText();
                        ivTabThree.setColorFilter(ContextCompat.getColor(HomeActivity.this, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
                        txtTabThree.setTextColor(getResources().getColor(R.color.colorPrimary));
                        break;
                    case 3:
                        txtToolbarTitle.setText("Settings");
                        setColorIconAndText();
                        ivTabFour.setColorFilter(ContextCompat.getColor(HomeActivity.this, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
                        txtTabFour.setTextColor(getResources().getColor(R.color.colorPrimary));
                        break;
                }

                if (loutSelect.getVisibility() == View.VISIBLE) {

                    setClose();

                }
                tabPos = i;
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

        loadAnimation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, GiftActivity.class));
            }
        });
        loadAnimation2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this, GiftActivity.class));
            }
        });


//        loadAds();
        setGiftAnimation();
    }

    boolean isFirstGift = false;

    private void setGiftAnimation() {
        loadAnimation.removeAllAnimatorListeners();
        if (isFirstGift) {
            isFirstGift = false;
            loadAnimation2.setAnimation("gift_2.json");
            setSecAnimation();

        } else {
            isFirstGift = true;
            loadAnimation.setAnimation("gift_1.json");
            setFirstAnimation();

        }
    }

    private void setColorIconAndText() {

        ivTabOne.setColorFilter(ContextCompat.getColor(HomeActivity.this, R.color.white), PorterDuff.Mode.SRC_ATOP);
        txtTabOne.setTextColor(getResources().getColor(R.color.white));

        ivTabTwo.setColorFilter(ContextCompat.getColor(HomeActivity.this, R.color.white), PorterDuff.Mode.SRC_ATOP);
        txtTabTwo.setTextColor(getResources().getColor(R.color.white));

        ivTabThree.setColorFilter(ContextCompat.getColor(HomeActivity.this, R.color.white), PorterDuff.Mode.SRC_ATOP);
        txtTabThree.setTextColor(getResources().getColor(R.color.white));

        ivTabFour.setColorFilter(ContextCompat.getColor(HomeActivity.this, R.color.white), PorterDuff.Mode.SRC_ATOP);
        txtTabFour.setTextColor(getResources().getColor(R.color.white));

    }

    @OnClick({R.id.lout_tab_one, R.id.lout_tab_two, R.id.lout_tab_three, R.id.lout_tab_four, R.id.iv_close_select, R.id.iv_share, R.id.iv_delete})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.lout_tab_one:
                viewpager.setCurrentItem(0);
                break;
            case R.id.lout_tab_two:
                viewpager.setCurrentItem(1);
                break;
            case R.id.lout_tab_three:
                viewpager.setCurrentItem(2);
                break;
            case R.id.lout_tab_four:
                viewpager.setCurrentItem(3);
                break;
            case R.id.iv_close_select:
                setClose();
                break;
            case R.id.iv_share:
                int tabPos = viewpager.getCurrentItem();
                RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos, getString(R.string.share)));
                break;
            case R.id.iv_delete:
                int tabPos1 = viewpager.getCurrentItem();
                RxBus.getInstance().post(new ImageShareDeleteEvent(tabPos1, getString(R.string.delete)));
                break;
        }
    }

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        Log.e("TAG", "onBackPressed:==== " + isNetworkAvailable(HomeActivity.this));
        if (isNetworkAvailable(HomeActivity.this) && !AdsUtils.isAppAdsFree && LoadAds.getInstance(HomeActivity.this).mNativeRateAd != null) {
            ExitDialogNative exitDialogNative = new ExitDialogNative();
            exitDialogNative.show(getSupportFragmentManager(), exitDialogNative.getTag());
        } else {

            if (loutSelect.getVisibility() == View.VISIBLE) {
                setClose();

            } else {
                if (!PreferencesUtility.getRateUS(this)) {
                    showRateUsDialog();
                } else {
                    if (doubleBackToExitPressedOnce) {
                        super.onBackPressed();
                    }
                    this.doubleBackToExitPressedOnce = true;
                    Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {

                        @Override
                        public void run() {
                            doubleBackToExitPressedOnce = false;
                        }
                    }, 2000);

                }
            }
        }
    }

    private void setSecAnimation() {
        loadAnimation2.removeAllAnimatorListeners();
        loadAnimation2.setVisibility(View.GONE);
        loadAnimation.setVisibility(View.GONE);

        loadAnimation2.playAnimation();
        loadAnimation2.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                Log.e("onAnimation", "end");
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                super.onAnimationRepeat(animation);
                Log.e("onAnimation", "Repeat");
                loadAnimation2.pauseAnimation();
                setFirstAnimation();
            }

            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
            }

            @Override
            public void onAnimationPause(Animator animation) {
                super.onAnimationPause(animation);
            }

            @Override
            public void onAnimationResume(Animator animation) {
                super.onAnimationResume(animation);
            }
        });

    }

    private void setFirstAnimation() {
        loadAnimation.removeAllAnimatorListeners();
        loadAnimation2.setVisibility(View.GONE);
        loadAnimation.setVisibility(View.GONE);
        loadAnimation.playAnimation();

        loadAnimation.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                Log.e("onAnimation", "end");
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                super.onAnimationRepeat(animation);
                Log.e("onAnimation", "Repeat");
                loadAnimation.pauseAnimation();
                setSecAnimation();
            }

            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
            }

            @Override
            public void onAnimationPause(Animator animation) {
                super.onAnimationPause(animation);
            }

            @Override
            public void onAnimationResume(Animator animation) {
                super.onAnimationResume(animation);
            }
        });
    }

    public void showRateUsDialog() {
        rating_count = 0;
        final Dialog rateUsDialog = new Dialog(this);
        rateUsDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        rateUsDialog.setContentView(R.layout.dialog_rate_us);
        rateUsDialog.setCancelable(true);
        rateUsDialog.setCanceledOnTouchOutside(true);

        TextView btn_rate = rateUsDialog.findViewById(R.id.btn_rate);
        ImageView btn_later = rateUsDialog.findViewById(R.id.btn_later);

        RotationRatingBar rotationRatingBar = rateUsDialog.findViewById(R.id.rotationratingbar_main);
        rotationRatingBar.setOnRatingChangeListener(new BaseRatingBar.OnRatingChangeListener() {
            @Override
            public void onRatingChange(BaseRatingBar ratingBar, float rating, boolean fromUser) {
                rating_count = rating;
            }
        });

        btn_later.setOnClickListener(v -> {
            rateUsDialog.dismiss();
            finish();
        });

        btn_rate.setOnClickListener(v -> {
            if (rating_count >= 4) {
                PreferencesUtility.setRateUs(this, true);
                // playStore
                String url = "https://play.google.com/store/apps/details?id=" + getPackageName();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                rateUsDialog.dismiss();
            } else if (rating_count <= 3 && rating_count > 0) {
                PreferencesUtility.setRateUs(this, true);
                // feed back
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO,
                        Uri.parse("mailto:" + Uri.encode(getResources().getString(R.string.feedback_email))));

                emailIntent.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));

                try {
                    startActivity(Intent.createChooser(emailIntent, "Send email via..."));
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(this,
                            "There are no email clients installed.", Toast.LENGTH_SHORT)
                            .show();
                }
                rateUsDialog.dismiss();
            } else {
                Toast.makeText(this, "Please click on 5 Star to give us rating on playstore.", Toast.LENGTH_SHORT)
                        .show();
            }
        });

        rateUsDialog.show();
    }


    int select_count = 0;

    @Override
    public void OnSelected(boolean isShowToolbar, boolean isShowSelected, int selected) {
        if (isShowToolbar) {
            loutToolbar.setVisibility(View.VISIBLE);
            tabLayout.setVisibility(View.VISIBLE);
        } else {
            loutToolbar.setVisibility(View.GONE);
            tabLayout.setVisibility(View.INVISIBLE);
        }

        select_count = selected;
        if (isShowSelected) {
            loutSelect.setVisibility(View.VISIBLE);
            loutSelectBottom.setVisibility(View.VISIBLE);
        } else {
            loutSelect.setVisibility(View.GONE);
            loutSelectBottom.setVisibility(View.GONE);
        }
        txtSelect.setText(selected + " Selected");

    }

    private void setClose() {

        select_count = 0;
        RxBus.getInstance().post(new ImageCloseEvent(tabPos));
        loutSelect.setVisibility(View.GONE);
        loutSelectBottom.setVisibility(View.GONE);
        loutToolbar.setVisibility(View.VISIBLE);
        tabLayout.setVisibility(View.VISIBLE);

    }

    public class ViewPagerAdapter extends FragmentStatePagerAdapter {
        public final int PAGE_COUNT = 4;
        private Context mContext;


        public ViewPagerAdapter(FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public int getItemPosition(Object object) {
            // POSITION_NONE makes it possible to reload the PagerAdapter
            return POSITION_NONE;
        }

        @Override
        public Fragment getItem(int position) {
            Fragment fragment = null;

            switch (position) {
                case 0:
                    photoFragment = new PhotoFragment(HomeActivity.this);
                    return photoFragment;

                case 1:
                    albumFragment = new AlbumFragment();
                    return albumFragment;

                case 2:
                    videoFragment = new VideoFragment(HomeActivity.this);
                    return videoFragment;

                case 3:
                    settingFragment = new SettingFragment();
                    return settingFragment;

            }

            return fragment;
        }


        @Override
        public int getCount() {
            return 4;
        }


    }
}