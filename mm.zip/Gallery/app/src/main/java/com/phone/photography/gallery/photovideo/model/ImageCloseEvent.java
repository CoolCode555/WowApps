package com.phone.photography.gallery.photovideo.model;

public class ImageCloseEvent {
    int pos;

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public ImageCloseEvent(int pos) {
        this.pos = pos;
    }
}
