package com.phone.photography.gallery.photovideo.fragment;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.customlibraries.adsutils.AdsUtils;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.activity.VideoPlayActivity;
import com.phone.photography.gallery.photovideo.adapter.VideoAdapter;
import com.phone.photography.gallery.photovideo.model.ImageCloseEvent;
import com.phone.photography.gallery.photovideo.model.ImageShareDeleteEvent;
import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;
import com.phone.photography.gallery.photovideo.oncliclk.OnSelectedHome;
import com.phone.photography.gallery.photovideo.service.ImageDataService;
import com.phone.photography.gallery.photovideo.service.VideoDataService;
import com.phone.photography.gallery.photovideo.util.AppUtils;
import com.phone.photography.gallery.photovideo.util.RxBus;
import com.phone.photography.gallery.photovideo.util.Utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

import static com.phone.photography.gallery.photovideo.util.Constant.VIDEO_PLAY_INTENT;

public class VideoFragment extends Fragment {

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @BindView(R.id.lout_no_data)
    LinearLayout loutNoData;

    VideoAdapter adapter;

    public List<Object> videoList = new ArrayList<>();

    OnSelectedHome selectedHome;

    int selected_Item = 0;
    ProgressDialog loadingDialog;

    ArrayList<String> deleteList;

    private ActivityResultLauncher<IntentSenderRequest> deleteIntentSenderLauncher;

    public VideoFragment(OnSelectedHome selectedHome) {
        this.selectedHome = selectedHome;
    }

    public VideoFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.video_fragment, container, false);
        ButterKnife.bind(this, view);
        initViews();
        setDeleteIntentLauncher();
        return view;
    }


    private void setDeleteIntentLauncher() {
        this.deleteIntentSenderLauncher = registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
//                AdvertiseHandler.getInstance().isNeedOpenAdRequest = false;
                if (result.getResultCode() == Activity.RESULT_OK) {
//                    updateDataOnDelete();
                    updateDeleteImageData(deleteList);
                } else if (result.getResultCode() == Activity.RESULT_CANCELED) {
                    selected_Item = 0;
//                    ((HomeActivity) getActivity()).longClick(true, false, 0, false);
                    setClose();
                }


            }
        });
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        closeEvent();
        shareDeleteEvent();
    }

    private void initViews() {

        progressBar.setVisibility(View.VISIBLE);
        new Thread(this::getDataList).start();


        loadingDialog = new ProgressDialog(getActivity());
        loadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        loadingDialog.setCancelable(false);
        loadingDialog.setMessage("Delete video...");
        loadingDialog.setCanceledOnTouchOutside(false);
    }

    private void getDataList() {
        try {
            while (true) {
                if (VideoDataService.isComplete) {
                    break;
                }
            }

            requireActivity().runOnUiThread(() -> {
                videoList = new ArrayList<>();
                videoList.addAll(VideoDataService.videoList);
                setAdapter();
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void setAdapter() {

        progressBar.setVisibility(View.GONE);

        if (videoList != null && videoList.size() != 0) {
            recyclerView.setVisibility(View.VISIBLE);
            loutNoData.setVisibility(View.GONE);

            GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 4, LinearLayoutManager.VERTICAL, false);
            recyclerView.setLayoutManager(gridLayoutManager);
            adapter = new VideoAdapter(getActivity(), videoList);
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(final int position) {
                    if (adapter.getItemViewType(position) == VideoAdapter.ITEM_HEADER_TYPE || adapter.getItemViewType(position) == VideoAdapter.TYPE_AD) {
                        return 4;
                    }
                    return 1;
                }
            });
            recyclerView.setAdapter(adapter);
            adapter.setOnItemClickListener(new VideoAdapter.ClickListener() {
                @Override
                public void onItemClick(int position, View v) {
                    if (videoList.get(position) instanceof PhotoData) {

                        PhotoData imageList = (PhotoData) videoList.get(position);

                        if (imageList.isCheckboxVisible()) {

                            try {
                                if (imageList.isSelected()) {
                                    imageList.setSelected(false);
                                } else
                                    imageList.setSelected(true);
                                adapter.notifyItemChanged(position);
                                setSelectedFile();

                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                        } else {
                            Intent intent = new Intent(getActivity(), VideoPlayActivity.class);
                            intent.putExtra("FilePath", imageList.getFilePath());
                            intent.putExtra("FileName", imageList.getFileName());
                            intent.putExtra("Duration", imageList.getDuration());
                            startActivityForResult(intent, VIDEO_PLAY_INTENT);

                        }
                    }
                }
            });

            adapter.setOnLongClickListener(new VideoAdapter.LongClickListener() {
                @Override
                public void onItemLongClick(int position, View v) {
                    if (videoList.get(position) instanceof PhotoData) {
                        PhotoData imageList = (PhotoData) videoList.get(position);

                        for (int i = 0; i < videoList.size(); i++) {
                            if (videoList.get(i) != null)

                                if (videoList.get(i) instanceof PhotoData) {

                                    PhotoData model = (PhotoData) videoList.get(i);
                                    model.setCheckboxVisible(true);

                                }

                        }
                        imageList.setCheckboxVisible(true);
                        imageList.setSelected(true);

                        adapter.notifyDataSetChanged();
                        setSelectedFile();

                    }
                }
            });


        } else {
            recyclerView.setVisibility(View.GONE);
            loutNoData.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e("TAG", "onActivityResult: " + requestCode + " ?? " + resultCode);
        if (requestCode == VIDEO_PLAY_INTENT) {
            AdsUtils.loadInterstitialAds(getActivity(), true);
        }
    }

    private void setSelectedFile() {
        int selected = 0;

        for (int i = 0; i < videoList.size(); i++) {

            if (videoList.get(i) != null)
                if (videoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) videoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                    }

                }
        }


        if (selected == 0) {

            selectedHome.OnSelected(true, false, selected);
            setClose();
        } else {
            selectedHome.OnSelected(false, true, selected);

        }

        selected_Item = selected;
    }

    private void setClose() {


        for (int i = 0; i < videoList.size(); i++) {

            if (videoList.get(i) != null)
                if (videoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) videoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);

                }
        }
        if (adapter != null)
            adapter.notifyDataSetChanged();
        selected_Item = 0;
    }

    private void shareDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(ImageShareDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<ImageShareDeleteEvent>() {
            @Override
            public void call(ImageShareDeleteEvent event) {
                if (event.getPos() == 2) {
                    if (selected_Item != 0) {
                        if (event.getType().equalsIgnoreCase(getString(R.string.share))) {

                            ArrayList<Uri> uris = new ArrayList<>();
                            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);

                            for (int i = 0; i < videoList.size(); i++) {

                                if (videoList.get(i) != null)
                                    if (videoList.get(i) instanceof PhotoData) {

                                        PhotoData model = (PhotoData) videoList.get(i);
                                        if (model.isSelected()) {
                                            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".provider", new File(model.getFilePath()));
                                            uris.add(uri);
                                        }

                                    }
                            }

                            intent.setType("*/*");
                            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            getContext().startActivity(Intent.createChooser(intent, "Share with..."));


                        } else if (event.getType().equalsIgnoreCase(getString(R.string.delete))) {
                            deletePhoto();


                        }
                    } else {
                        Toast.makeText(getActivity(), "Please select video", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void updateDeleteImageData(ArrayList<String> deleteList) {
        if (videoList != null && videoList.size() != 0) {

            for (int d = 0; d < deleteList.size(); d++) {

                for (int i = 0; i < videoList.size(); i++) {

                    if (videoList.get(i) instanceof PhotoData) {
                        PhotoData model = (PhotoData) videoList.get(i);

                        if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {

                            boolean isPre = false, isNext = false;

                            if (i != 0) {
                                if (videoList.get(i - 1) instanceof PhotoHeader) {
                                    isPre = true;
                                } else {
                                    isPre = false;
                                }
                            }

                            if (i < (videoList.size() - 2)) {
                                if (videoList.get(i + 1) instanceof PhotoHeader) {
                                    isNext = true;
                                } else {
                                    isNext = false;
                                }
                            }

                            if (isPre && isNext) {
                                //  objectList.remove(i + 1);
                                videoList.remove(i);
                                videoList.remove(i - 1);

                            } else if (i == (videoList.size() - 1)) {
                                if (isPre) {
                                    videoList.remove(i);
                                    videoList.remove(i - 1);
                                } else {
                                    videoList.remove(i);
                                }
                            } else {
                                videoList.remove(i);
                            }

                            if (i != 0) {
                                i--;
                            }

                            if (d == deleteList.size() - 1) {
                                break;
                            }

                        }

                    }

                }
            }

            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }

            ImageDataService.photoAlbumList = new ArrayList<>();
            ImageDataService.photoAlbumList.addAll(videoList);

            if (videoList != null && videoList.size() != 0) {
                recyclerView.setVisibility(View.VISIBLE);
                loutNoData.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                loutNoData.setVisibility(View.VISIBLE);
            }
        }
    }


    private void deletePhoto() {

        deleteList = new ArrayList<>();

        if (Utils.isVersionQAbove()) {

            Log.e("TAG1017", "deletePhoto: " + "isVersionQAbove");
            for (int i = 0; i < videoList.size(); i++) {
                if (videoList.get(i) != null) {
                    if (videoList.get(i) instanceof PhotoData) {

                        PhotoData photoData = (PhotoData) videoList.get(i);
//                        PictureData photoData = (PictureData) pictures.get(i);
                        if (photoData.isSelected()) {
                            deleteList.add(photoData.getFilePath());
                        } else {
                            photoData.setCheckboxVisible(false);
                        }
                    }
                }
            }
            Log.e("TAG1091", "deletePhoto: " + deleteList.size());
            IntentSender deleteFileOnAboveQ = AppUtils.deleteFileOnAboveQ(deleteList, getActivity());
            if (deleteFileOnAboveQ != null) {
                deleteIntentSenderLauncher.launch(new IntentSenderRequest.Builder(deleteFileOnAboveQ).build());
                return;
            }
            Toast.makeText(getActivity(), "Error...!", Toast.LENGTH_SHORT).show();

        } else {
            showDeleteDialog();
        }


    }



    private void showDeleteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlert);
        builder.setMessage("Are you sure do you want to delete it?");
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (loadingDialog != null)
                    if (!loadingDialog.isShowing()) {
                        loadingDialog.setMessage("Delete video...");
                        loadingDialog.show();
                    }

                new Thread(this::deletePhoto).start();
            }

            private void deletePhoto() {

                ArrayList<String> deleteList = new ArrayList<>();
                for (int i = 0; i < videoList.size(); i++) {

                    if (videoList.get(i) != null)
                        if (videoList.get(i) instanceof PhotoData) {

                            PhotoData model = (PhotoData) videoList.get(i);
                            if (model.isSelected()) {

                                File file = new File(model.getFilePath());
                                Uri deleteUrl = FileProvider.getUriForFile(getActivity(), getActivity().getApplicationContext().getPackageName() + ".provider", file);
                                ContentResolver contentResolver = getActivity().getContentResolver();
                                contentResolver.delete(deleteUrl, null, null);

                                try {
                                    FileUtils.deleteDirectory(file);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                MediaScannerConnection.scanFile(getActivity(), new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                    public void onScanCompleted(String path, Uri uri) {
                                        // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                                    }
                                });

                                deleteList.add(file.getPath());
                            } else {

                                model.setCheckboxVisible(false);
                            }

                        }
                }

                for (int i = 0; i < videoList.size(); i++) {
                    if (videoList.get(i) != null)

                        if (videoList.get(i) instanceof PhotoData) {
                            PhotoData model = (PhotoData) videoList.get(i);
                            if (model.isSelected()) {
                                boolean isPre = false, isNext = false;

                                if (i != 0) {
                                    if (videoList.get(i - 1) instanceof PhotoHeader) {
                                        isPre = true;
                                    } else {
                                        isPre = false;
                                    }
                                }

                                if (i < (videoList.size() - 2)) {
                                    if (videoList.get(i + 1) instanceof PhotoHeader) {
                                        isNext = true;
                                    } else {
                                        isNext = false;
                                    }
                                }

                                if (isPre && isNext) {
                                    //  objectList.remove(i + 1);
                                    videoList.remove(i);
                                    videoList.remove(i - 1);

                                } else if (i == (videoList.size() - 1)) {
                                    if (isPre) {
                                        videoList.remove(i);
                                        videoList.remove(i - 1);
                                    } else {
                                        videoList.remove(i);
                                    }
                                } else {
                                    videoList.remove(i);
                                }

                                if (i != 0) {
                                    i--;
                                }
                            }
                        }
                }

                requireActivity().runOnUiThread(() -> {
                    if (loadingDialog != null)
                        if (loadingDialog.isShowing()) {
                            loadingDialog.dismiss();
                        }

                    selected_Item = 0;
                    selectedHome.OnSelected(true, false, 0);
                    adapter.notifyDataSetChanged();
                    if (videoList != null && videoList.size() != 0) {
                        recyclerView.setVisibility(View.VISIBLE);
                        loutNoData.setVisibility(View.GONE);
                    } else {
                        recyclerView.setVisibility(View.GONE);
                        loutNoData.setVisibility(View.VISIBLE);
                    }
                    Toast.makeText(getActivity(), "Delete video successfully", Toast.LENGTH_SHORT).show();
                });

            }

        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }


    private void closeEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(ImageCloseEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<ImageCloseEvent>() {
            @Override
            public void call(ImageCloseEvent event) {
                if (event.getPos() == 2) {
                    setClose();
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }


    private String getDurationString(int duration) {

        long hours = TimeUnit.MILLISECONDS.toHours(duration);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(duration);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration));

        if (hours == 0) {
            return minutes + ":" + seconds;
        } else
            return hours + ":" + minutes + ":" + seconds;
    }
}
