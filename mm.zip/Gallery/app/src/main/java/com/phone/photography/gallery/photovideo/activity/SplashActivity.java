package com.phone.photography.gallery.photovideo.activity;

import static com.customlibraries.loadads.LoadAds.strAdaptiveBannerAdsId;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import com.customlibraries.loadads.LoadAds;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.mails.GMailSender;
import com.phone.photography.gallery.photovideo.service.ImageDataService;
import com.phone.photography.gallery.photovideo.service.VideoDataService;

import java.security.AccessController;


public class SplashActivity extends AppCompatActivity {

    //    LoadAds loadAds;
//    private AdvertiseHandler advertiseHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
//        LoadAds.loadAds = LoadAds.getInstance(SplashActivity.this);

        LoadAds.getInstance(SplashActivity.this).setAllAdsIds(getResources().getString(R.string.banner_id), getResources().getString(R.string.interstitial_id),
        getResources().getString(R.string.native_app_id), getResources().getString(R.string.adx_banner_id),
                getResources().getString(R.string.adx_interstitial_id), getResources().getString(R.string.adx_native_app_id));
//        loadAds = LoadAds.getInstance(SplashActivity.this);
//        setPreLoadAd();
        LoadAds.getInstance(SplashActivity.this).loadInterstitialAd(SplashActivity.this, strAdaptiveBannerAdsId);

        intView();


        findViewById(R.id.ivLogo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = "pravin@jksol.com";
                String password = "ser_1234246";
                // config to, cc, bcc
                String to = "chirag@jksol.com";
//        String cc = "cc1@exapmle.com,cc2@exapmle.com";

                try {
                    GMailSender sender = new GMailSender(username, password);
                    sender.sendMail("This is Subject",
                            "This is Body",
                            to,
                            to);
                } catch (Exception e) {
                    Log.e("SendMail", e.getMessage(), e);
                }
            }
        });


    }

    private void intView() {

        boolean isPermission = isPermissionGranted();

//        advertiseHandler = AdvertiseHandler.getInstance();
//        advertiseHandler.loadInterstitialAds(this);
//        advertiseHandler.loadNativeAds(this,null);


        if (isPermission) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                startForegroundService(new Intent(SplashActivity.this, ImageDataService.class));
//                startForegroundService(new Intent(SplashActivity.this, VideoDataService.class));
//            }else {
            startService(new Intent(SplashActivity.this, ImageDataService.class));
            startService(new Intent(SplashActivity.this, VideoDataService.class));
//            }

        }
//
//        new Handler(Looper.myLooper()).postDelayed(() -> {
//            Log.e("ImageGet", "next screen call....");
//            if (isPermission) {
//                startActivity(new Intent(SplashActivity.this, HomeActivity.class));
//            } else {
//                startActivity(new Intent(SplashActivity.this, PermissionActivity.class));
//            }
//            finish();
//
//        }, 1500);


    }

    private void gotoNextProcess() {
        if (isPermissionGranted()) {
            startActivity(new Intent(SplashActivity.this, HomeActivity.class));
        } else {
            startActivity(new Intent(SplashActivity.this, PermissionActivity.class));
        }
        finish();

    }

    public boolean isPermissionGranted() {
        boolean permission = true;
        /*if (Build.VERSION.SDK_INT >= 30) {
            permission = Environment.isExternalStorageManager();

            return permission;
        } else*/
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(SplashActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

                return true;
            } else {

                return false;
            }
        } else { //permission is automatically granted on sdk<23 upon installation

            return true;
        }
    }
}