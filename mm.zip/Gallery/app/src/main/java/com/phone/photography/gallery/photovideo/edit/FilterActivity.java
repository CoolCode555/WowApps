package com.phone.photography.gallery.photovideo.edit;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.phone.photography.gallery.photovideo.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import iamutkarshtiwari.github.io.ananas.editimage.fliter.PhotoProcessing;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;


public class FilterActivity extends AppCompatActivity {

    private static final String TAG = "FilterActivity";
    private CompositeDisposable compositeDisposable = new CompositeDisposable();

    private Bitmap filterBitmap;
    private Bitmap currentBitmap;
    private String imagePath;

    private ImageView img_filter;
    private ImageView img_close;
    private ImageView img_save;
    private RecyclerView filter_recycler;
    private FilterAdapter filterAdapter;
    private ProgressDialog loadingDialog;
    private String outputPath;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        setContentView(R.layout.activity_filter);

        init();
        click();

    }

    private void init() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getResources().getColor(R.color.black, this.getTheme()));
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.black));
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.black));
            getWindow().setStatusBarColor(getResources().getColor(R.color.black));
        }

        imagePath = getIntent().getStringExtra("imagePath");
        outputPath=getIntent().getStringExtra("outputPath");
        img_filter = findViewById(R.id.img_filter);
        img_close = findViewById(R.id.img_close);
        img_save = findViewById(R.id.img_save);
        filter_recycler = findViewById(R.id.filter_recycler);

        Glide.with(this).asBitmap().load(imagePath).apply(RequestOptions.skipMemoryCacheOf(true))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE)).into(new CustomTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                img_filter.setImageBitmap(bitmap);
                mainBitmap = bitmap;
            }

            @Override
            public void onLoadCleared(Drawable placeholder) {
            }
        });

        filterAdapter = new FilterAdapter(getApplicationContext());
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
        filter_recycler.setLayoutManager(layoutManager);
        filter_recycler.setAdapter(filterAdapter);
        loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);
        loadingDialog.setMessage("Filtering");
    }

    private void click() {
        img_filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        img_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
//                    String path = Environment.getExternalStorageDirectory().toString();
                    OutputStream fOut = null;
                    File file = new File(outputPath);
                    if (file.exists())
                    {
                        file.delete();// the File to save , append increasing numeric counter to prevent files from getting overwritten.
                    }
                    fOut = new FileOutputStream(file);

                    Bitmap pictureBitmap = currentBitmap; // obtaining the Bitmap
                    pictureBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut); // saving the Bitmap to a file compressed as a JPEG with 85% compression rate
                    fOut.flush(); // Not really required
                    fOut.close(); // do not forget to close the stream
                    Intent intent = new Intent();
                    intent.putExtra("cropPath", file.getAbsolutePath());
                    setResult(RESULT_OK, intent);
                    finish();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        filterAdapter.setListner(new OnItemClickListner() {
            @Override
            public void onItemClickListner(int position) {
                Log.d(TAG, "onItemClickListner: " + position);
                compositeDisposable.clear();

                Disposable applyFilterDisposable = applyFilter(position)
                        .subscribeOn(Schedulers.computation())
                        .observeOn(AndroidSchedulers.mainThread())
                        .doOnSubscribe(subscriber -> loadingDialog.show())
                        .doFinally(() -> loadingDialog.dismiss())
                        .subscribe(
                                bitmap -> {
                                    updatePreviewWithFilter(bitmap);
                                },
                                e -> showSaveErrorToast(e)
                        );

                compositeDisposable.add(applyFilterDisposable);
               /* new Handler(Looper.myLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {*/
//                        final File nativeLibraryDir = new File(getApplicationInfo().nativeLibraryDir);
//                        final String[] primaryNativeLibraries = nativeLibraryDir.list();
//                        for (int i = 0; i < primaryNativeLibraries.length; i++) {
//                            Log.d(TAG, "run: " + primaryNativeLibraries[i]);
//                        }
                   /* }
                }, 100);*/
            }
        });
        img_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private Single<Bitmap> applyFilter(int filterIndex) {
        return Single.fromCallable(() -> {

            Bitmap srcBitmap = Bitmap.createBitmap(getMainBit().copy(
                    Bitmap.Config.RGB_565, true));
            return PhotoProcessing.filterPhoto(srcBitmap, filterIndex);
        });
    }

    private void showSaveErrorToast(Throwable e) {
        Log.d(TAG, "showSaveErrorToast: " + e);
        Toast.makeText(getApplicationContext(), "Save error", Toast.LENGTH_SHORT).show();
    }

    private void updatePreviewWithFilter(Bitmap bitmapWithFilter) {
        Log.d(TAG, "updatePreviewWithFilter: ");
        if (bitmapWithFilter == null) return;

        if (filterBitmap != null && (!filterBitmap.isRecycled())) {
            filterBitmap.recycle();
        }

        filterBitmap = bitmapWithFilter;
        img_filter.setImageBitmap(filterBitmap);
        currentBitmap = filterBitmap;
    }

    private Bitmap mainBitmap;

    public Bitmap getMainBit() {
        return mainBitmap;
    }

    @Override
    public void onPause() {
        compositeDisposable.clear();
        super.onPause();
    }

    @Override
    public void onDestroy() {
        tryRecycleFilterBitmap();
        compositeDisposable.dispose();
        super.onDestroy();
    }

    private void tryRecycleFilterBitmap() {
        if (filterBitmap != null && (!filterBitmap.isRecycled())) {
            filterBitmap.recycle();
        }
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        finish();
    }
}
