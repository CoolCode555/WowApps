package com.phone.photography.gallery.photovideo.model;

import java.util.ArrayList;

public class DeleteEvent {
    ArrayList<String> deleteList = new ArrayList<>();
    int pos;

    public DeleteEvent(int pos, ArrayList<String> deleteList) {
        this.pos = pos;
        this.deleteList = deleteList;
    }

    public ArrayList<String> getDeleteList() {
        return deleteList;
    }

    public void setDeleteList(ArrayList<String> deleteList) {
        this.deleteList = deleteList;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }
}
