package com.phone.photography.gallery.photovideo.service;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;
import com.phone.photography.gallery.photovideo.util.NotificationUtils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import io.reactivex.Observable;
import io.reactivex.schedulers.Schedulers;

public class ImageDataService extends Service {

    public static boolean isComplete = false;

    public LinkedHashMap<String, ArrayList<PhotoData>> bucketimagesDataPhotoHashMap;
    public LinkedHashMap<String, ArrayList<PhotoData>> bucketimagesDataHashMap;
    public static List<Object> photoList = new ArrayList<>();
    public static List<Object> photoAlbumList = new ArrayList<>();

    public static List<PhotoHeader> folderList = new ArrayList<>();
    public static List<PhotoHeader> folderAlbumList = new ArrayList<>();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification notification = new NotificationCompat.Builder(this, NotificationUtils.ANDROID_CHANNEL_ID)
                        .setContentTitle("")
                        .setContentText("").build();


                startForeground(1, notification);
                stopForeground(STOP_FOREGROUND_REMOVE);
            }
        } catch (RuntimeException e) {

        }

        bucketimagesDataPhotoHashMap = new LinkedHashMap<>();
        bucketimagesDataHashMap = new LinkedHashMap<>();
        photoList = new ArrayList<>();
        photoAlbumList = new ArrayList<>();
        folderList = new ArrayList<>();
        folderAlbumList = new ArrayList<>();
        isComplete = false;


        Observable.fromCallable(() -> {
            Log.e("ImageGet", "service photo getting start....");

            photoList = getImagesList();
            return true;
        }).subscribeOn(Schedulers.io())
                .doOnError(throwable -> {
                    isComplete = true;
                    Intent intent1 = new Intent("LoardDataComplete");
                    intent1.putExtra("completed", true);
                    sendBroadcast(intent1);
                })
                .subscribe((result) -> {
                    isComplete = true;
                    Intent intent1 = new Intent("LoardDataComplete");
                    intent1.putExtra("completed", true);
                    Log.e("ImageGet", "service photo set list....");
                    sendBroadcast(intent1);
                });

        return super.onStartCommand(intent, flags, startId);
    }


    private List<Object> getImagesList() {
        List<PhotoHeader> folderDataList = new ArrayList<>();
        Cursor mCursor = null;

        String BUCKET_DISPLAY_NAME ;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            BUCKET_DISPLAY_NAME = android.provider.MediaStore.MediaColumns.BUCKET_DISPLAY_NAME;
        } else
            BUCKET_DISPLAY_NAME = MediaStore.Images.Media.BUCKET_DISPLAY_NAME;


        String[] projection = {MediaStore.Images.Media.DATA/*, MediaStore.Images.Media.TITLE*/
                ,BUCKET_DISPLAY_NAME
                , MediaStore.MediaColumns.DATE_MODIFIED
                , MediaStore.MediaColumns.DISPLAY_NAME
                //*MediaStore.Images.Media.BUCKET_DISPLAY_NAME
                // , MediaStore.Images.Media.LATITUDE, MediaStore.Images.Media.LONGITUDE, MediaStore.Images.Media._ID
        };

        Uri uri;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            uri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        } else
            uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        mCursor = getContentResolver().query(
                uri, // Uri
                projection, // Projection
                null,
                null,
                "LOWER(" + MediaStore.Images.Media.DATE_MODIFIED + ") DESC");

        SimpleDateFormat format = new SimpleDateFormat("MMM yyyy");
//        SimpleDateFormat format = new SimpleDateFormat("MMM yyyy", Locale.US);

        if (mCursor != null) {
            mCursor.moveToFirst();
            ArrayList<PhotoData> photoDataArrayList = new ArrayList<>();

            for (mCursor.moveToFirst(); !mCursor.isAfterLast(); mCursor.moveToNext()) { //2sec

                String path = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));
                String title = mCursor.getString(mCursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME));

                String bucketName = mCursor.getString(mCursor.getColumnIndex(BUCKET_DISPLAY_NAME));
                long d = mCursor.getLong(mCursor.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED));
                d = d * 1000;
                String strDate = format.format(d);

                PhotoData imagesData = new PhotoData();
                imagesData.setFilePath(path);
                imagesData.setFileName(title);
                imagesData.setFolderName(bucketName);
                photoDataArrayList.add(imagesData);

                if (bucketimagesDataPhotoHashMap.containsKey(strDate)) {
                    ArrayList<PhotoData> imagesData1 = bucketimagesDataPhotoHashMap.get(strDate);
                    if (imagesData1 == null)
                        imagesData1 = new ArrayList<>();

                    imagesData1.add(imagesData);
                    bucketimagesDataPhotoHashMap.put(strDate, imagesData1);

                } else {
                    ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                    imagesData1.add(imagesData);
                    bucketimagesDataPhotoHashMap.put(strDate, imagesData1);
                }

                if (bucketimagesDataHashMap.containsKey(bucketName)) {
                    ArrayList<PhotoData> imagesData1 = bucketimagesDataHashMap.get(bucketName);
                    if (imagesData1 == null)
                        imagesData1 = new ArrayList<>();
                    imagesData1.add(imagesData);
                    bucketimagesDataHashMap.put(bucketName, imagesData1);

                } else {
                    ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                    imagesData1.add(imagesData);
                    bucketimagesDataHashMap.put(bucketName, imagesData1);
                }
            }


            mCursor.close();
        }


        Set<String> folderKeys = bucketimagesDataHashMap.keySet();
        ArrayList<String> listFolderkeys = new ArrayList<>();
        listFolderkeys.addAll(folderKeys);

        for (int i = 0; i < listFolderkeys.size(); i++) {
            ArrayList<PhotoData> imagesData = bucketimagesDataHashMap.get(listFolderkeys.get(i));

            if (imagesData != null && imagesData.size() != 0) {
                PhotoHeader bucketData = new PhotoHeader();

                bucketData.setTitle(listFolderkeys.get(i));
                bucketData.setPhotoList(imagesData);
                File file = new File(imagesData.get(0).getFilePath());
//                String folderPath =imagesData.get(0).getFilePath();
                String folderPath = file.getParentFile().getPath();
                bucketData.setFolderPath(folderPath);

                Log.e("serviceData","name: "+listFolderkeys.get(i) +" folderPath: " +folderPath);
                folderList.add(bucketData);
                folderAlbumList.add(bucketData);

            }
        }


        Set<String> keys = bucketimagesDataPhotoHashMap.keySet();
        ArrayList<String> listkeys = new ArrayList<>();
        listkeys.addAll(keys);


        for (int i = 0; i < listkeys.size(); i++) {
            ArrayList<PhotoData> imagesData = bucketimagesDataPhotoHashMap.get(listkeys.get(i));

            if (imagesData != null && imagesData.size() != 0) {
                PhotoHeader bucketData = new PhotoHeader();

                bucketData.setTitle(listkeys.get(i));
                bucketData.setPhotoList(imagesData);

                folderDataList.add(bucketData);

                photoList.add(bucketData);
                photoList.addAll(imagesData);
                photoAlbumList.add(bucketData);
                photoAlbumList.addAll(imagesData);
            }
        }

        return photoList;

    }

}
