package com.phone.photography.gallery.photovideo.fragment;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.activity.AboutUsActivity;
import com.phone.photography.gallery.photovideo.activity.FavoriteListActivity;
import com.phone.photography.gallery.photovideo.activity.PrivacyPolicyActivity;
import com.phone.photography.gallery.photovideo.util.PreferencesUtility;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SettingFragment extends Fragment {

    @BindView(R.id.txt_slideshow_interval)
    TextView txtSlideshowInterval;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.setting_fragment, container, false);
        ButterKnife.bind(this, view);

        int interval = PreferencesUtility.getSlideshowInterval(getActivity());
        txtSlideshowInterval.setText(/*getActivity().getResources().getString(R.string.setting_slideshow_interval) +*/ interval +" " + getActivity().getResources().getString(R.string.second));
        return view;
    }

    public SettingFragment() {

    }

    @OnClick({R.id.lout_privacy_policy, R.id.lout_rate_us, R.id.lout_share_us, R.id.lout_more_app, R.id.lout_about_us, R.id.lout_favorite, R.id.lout_slideshow})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.lout_favorite:
                startActivity(new Intent(getActivity(), FavoriteListActivity.class));
                break;
            case R.id.lout_privacy_policy:
                startActivity(new Intent(getActivity(), PrivacyPolicyActivity.class));
                break;
            case R.id.lout_rate_us:
                String url = "https://play.google.com/store/apps/details?id=" + getActivity().getPackageName();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                break;
            case R.id.lout_share_us:
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                String shareUrl = "https://play.google.com/store/apps/details?id=" + getActivity().getPackageName() + "";
                share.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));
                share.putExtra(Intent.EXTRA_TEXT, "Click on below link to download " + getResources().getString(R.string.app_name) + "\n" + shareUrl);

                startActivity(Intent.createChooser(share, "Share Using!"));
                break;
            case R.id.lout_more_app:
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=pub:" + getResources().getString(R.string.publisher))));
                } catch (ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/developer?id=" + getResources().getString(R.string.publisher))));
                }
                break;
            case R.id.lout_about_us:
                startActivity(new Intent(getActivity(), AboutUsActivity.class));
                break;

            case R.id.lout_slideshow:
                showSlideshowDialog();
                break;
        }
    }

    private void showSlideshowDialog() {

        final Dialog dialog = new Dialog(getActivity(), R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_slideshow_interval);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        EditText edt_number = dialog.findViewById(R.id.edt_number);
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_ok = dialog.findViewById(R.id.btn_ok);


        int interval = PreferencesUtility.getSlideshowInterval(getActivity());

        edt_number.setText(String.valueOf(interval));
        edt_number.requestFocus();
        edt_number.setSelection(edt_number.length());

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strnumber = edt_number.getText().toString().trim();
                if (strnumber == null || strnumber.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter slideshow interval", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        int number = Integer.parseInt(strnumber);
                        if (number <= 60 && number != 00 && number >= 2) {
                            PreferencesUtility.setSlideshowInterval(getActivity(), number);
                            txtSlideshowInterval.setText(/*getActivity().getResources().getString(R.string.setting_slideshow_interval) +*/ number + " " +getActivity().getResources().getString(R.string.second));
                            dialog.dismiss();
                        } else {

                            Toast.makeText(getActivity(), "Please enter the 2-60 second", Toast.LENGTH_SHORT).show();
                            
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();

    }
}
