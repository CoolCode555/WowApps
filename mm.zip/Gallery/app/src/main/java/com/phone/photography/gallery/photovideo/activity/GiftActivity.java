package com.phone.photography.gallery.photovideo.activity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.bumptech.glide.Glide;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.util.Constant;

import butterknife.BindView;
import butterknife.ButterKnife;

public class GiftActivity extends AppCompatActivity {


    @BindView(R.id.iv_bg)
    ImageView ivBg;
    @BindView(R.id.ic_back)
    ImageView icBack;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.animation_running)
    LottieAnimationView animationRunning;
    @BindView(R.id.animation_crown)
    LottieAnimationView animationCrown;
    @BindView(R.id.animation_app_1)
    LottieAnimationView animationApp1;
    @BindView(R.id.animation_app_2)
    LottieAnimationView animationApp2;
    @BindView(R.id.ll_app_animation)
    RelativeLayout llAppAnimation;
    @BindView(R.id.txt_app_name)
    TextView txtAppName;
    @BindView(R.id.txt_app_des)
    TextView txtAppDes;
    @BindView(R.id.txt_dow)
    TextView txt_dow;
    @BindView(R.id.iv_gif)
    ImageView ivGif;
    @BindView(R.id.animation_download)
    LottieAnimationView animationDownload;
    @BindView(R.id.lout_app)
    RelativeLayout loutApp;

    int appCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gift);
        ButterKnife.bind(this);

        intView();


    }

    private void intView() {
        loutApp.setVisibility(View.GONE);
//        ivBg.setVisibility(View.GONE);
        animationRunning.setVisibility(View.GONE);
        animationCrown.setVisibility(View.GONE);
        animationApp1.setVisibility(View.GONE);
        animationApp2.setVisibility(View.GONE);

        animationCrown.pauseAnimation();

        String strDesAPP1 = "VidMaker - Music Video Maker with Effects will have you creating music videos without complex animation and gimmicks in no time.";
        String strDesAPP2 = "Edit in PDF Convert and create PDF from various types of files like Word, DOC, Excel, XLS.. PDF Viewing is the best free PDF reader & viewer.";
        String strDesAPP3 = "Screen Mirroring App will assist you to scan and mirror your android phone or tab's screen on your TV. This app does not need extra dongle or cable.";

        appCount = Constant.IS_APP_Count;
        if (Constant.IS_APP_Count == 1) {
            // video maker
            animationApp1.setAnimation("video_play_1.json");
            animationApp2.setAnimation("video_play_2.json");
            txtAppDes.setText(strDesAPP1);

            Constant.IS_APP_Count++;
        } else if (Constant.IS_APP_Count == 2) {
            // pdf manager
            animationApp1.setAnimation("pdf_11.json");
            animationApp2.setAnimation("pdf_22.json");
           /* try {
                animationApp1.setAnimation("pdf_1.json");
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("ExceptionGIFT","pdf_1: " + e.getMessage());
            }

            try {
                animationApp2.setAnimation("sec_call.json");
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("ExceptionGIFT","sec_call: " + e.getMessage());
            }
*/

//            animationApp2.setAnimation("pdf_2.json");
            txtAppDes.setText(strDesAPP2);
            Constant.IS_APP_Count++;
        } else if (Constant.IS_APP_Count == 3) {
            // screen mirroring
            animationApp1.setAnimation("cast_1.json");
            animationApp2.setAnimation("cast_2.json");
            txtAppDes.setText(strDesAPP3);

            Constant.IS_APP_Count = 1;
        }

//        animationApp1.pauseAnimation();
//        animationApp2.pauseAnimation();

//        new Handler().postDelayed(() -> {
//            animationRunning.setVisibility(View.GONE);
//            animationRunning.pauseAnimation();
//            animationCrown.setVisibility(View.VISIBLE);
//            animationCrown.playAnimation();
//
//            setCrownListener();
//        }, 2000);

        animationRunning.setVisibility(View.GONE);
        animationRunning.pauseAnimation();
        animationCrown.setVisibility(View.VISIBLE);
        animationCrown.playAnimation();

        setCrownListener();

        icBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        Glide.with(this).asGif().load(R.drawable.animation_google_play).into(ivGif);

        animationDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String url = "";
                if (appCount == 1) {
                    // video maker
                    url = "https://play.google.com/store/apps/details?id=com.videostar.videoeditor.videomaker";
                } else if (appCount == 2) {
                    // pdf manager
                    url = "https://play.google.com/store/apps/details?id=com.amazing.messangerlock";
                } else if (appCount == 3) {
                    // screen mirroring
                    url = "https://play.google.com/store/apps/details?id=com.tv.casting.screenmirroring";
                }

                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                Constant.HIDE_GIFT_OPEN_ADS = true;
                startActivityForResult(i, 30);
            }
        });


        if (appCount == 1) {
            // video maker
            txtAppName.setText("VidMaker - Music Video Maker with Effects");
        } else if (appCount == 2) {
            // pdf manager
            txtAppName.setText("Edit in PDF");
        } else if (appCount == 3) {
            // screen mirroring
            txtAppName.setText("Screen Mirroring");
        }

        int widthPixels = Resources.getSystem().getDisplayMetrics().widthPixels;
        if (widthPixels < 720) {
//            txt_dow.getLayoutParams().set
            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(0,18,0,0);
            /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                params.setLayoutDirection(Gravity.CENTER_HORIZONTAL);
            }*/

            txt_dow.setLayoutParams(params);
            txt_dow.setGravity(Gravity.CENTER_HORIZONTAL);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 30) {
//            Log.e("onActivityResult","play close");

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Constant.HIDE_GIFT_OPEN_ADS = false;
    }

    private void setCrownListener() {
        animationCrown.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                Log.e("onAnimation", "end");
                animationCrown.pauseAnimation();
                setAppAnimation();
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                super.onAnimationRepeat(animation);
                Log.e("onAnimation", "Repeat");
                animationCrown.pauseAnimation();
                setAppAnimation();
            }

            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
            }

            @Override
            public void onAnimationPause(Animator animation) {
                super.onAnimationPause(animation);
            }

            @Override
            public void onAnimationResume(Animator animation) {
                super.onAnimationResume(animation);
            }
        });
    }

    private void setAppAnimation() {

        loutApp.setVisibility(View.VISIBLE);
        animationRunning.setVisibility(View.GONE);
        animationCrown.setVisibility(View.GONE);
        ivBg.setVisibility(View.VISIBLE);

        setFirstAppAnimation();
    }

    private void setFirstAppAnimation() {
        animationApp1.removeAllAnimatorListeners();
        animationApp1.setVisibility(View.VISIBLE);
        animationApp2.setVisibility(View.GONE);


        animationApp1.playAnimation();

//        animationApp1.setRepeatMode(LottieDrawable.RESTART);


        animationApp1.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                Log.e("onAnimation first", "end");
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                super.onAnimationRepeat(animation);
                Log.e("onAnimation first", "Repeat");
                animationApp1.pauseAnimation();
                setSecAppAnimation();
            }

            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
            }

            @Override
            public void onAnimationPause(Animator animation) {
                super.onAnimationPause(animation);
            }

            @Override
            public void onAnimationResume(Animator animation) {
                super.onAnimationResume(animation);
            }
        });


    }

    private void setSecAppAnimation() {

        animationApp2.removeAllAnimatorListeners();
        animationApp2.setVisibility(View.VISIBLE);
        animationApp1.setVisibility(View.GONE);

        animationApp2.playAnimation();


        animationApp2.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                Log.e("onAnimation sec", "end");
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                super.onAnimationRepeat(animation);
                Log.e("onAnimation sec", "Repeat");
                animationApp2.pauseAnimation();
                setFirstAppAnimation();
            }

            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
            }

            @Override
            public void onAnimationPause(Animator animation) {
                super.onAnimationPause(animation);
            }

            @Override
            public void onAnimationResume(Animator animation) {
                super.onAnimationResume(animation);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
      /*  try {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                getWindow().setStatusBarColor(ContextCompat.getColor(GiftActivity.this, R.color.white));// set status background white

                getWindow().setNavigationBarColor(ContextCompat.getColor(GiftActivity.this, R.color.white));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }*/

    }
}