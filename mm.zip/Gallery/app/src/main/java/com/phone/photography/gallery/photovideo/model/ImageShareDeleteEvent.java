package com.phone.photography.gallery.photovideo.model;

public class ImageShareDeleteEvent {

    String type;
    int pos;

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ImageShareDeleteEvent(int pos, String type) {
        this.type = type;
        this.pos = pos;
    }
}
