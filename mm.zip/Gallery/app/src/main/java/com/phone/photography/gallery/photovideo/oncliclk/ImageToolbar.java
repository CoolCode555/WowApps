package com.phone.photography.gallery.photovideo.oncliclk;

import android.view.View;

public interface ImageToolbar {
    public void OnImageToolbar(View v);
}
