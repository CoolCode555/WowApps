package com.phone.photography.gallery.photovideo.util;

import static com.phone.photography.gallery.photovideo.util.Utils.getExt;
import static com.phone.photography.gallery.photovideo.util.Utils.getImageUriFromFile;
import static com.phone.photography.gallery.photovideo.util.Utils.getVideoUriFromFile;
import static com.phone.photography.gallery.photovideo.util.Utils.isImage;

import android.app.Activity;
import android.app.ProgressDialog;
import android.app.RecoverableSecurityException;
import android.content.Context;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class AppUtils {
    private static final String TAG = AppUtils.class.getSimpleName();
    private static ProgressDialog progressDialog;

    public static void showProgressDialog(Context context, int resID) {
        try {
            if (context != null) {
                if (progressDialog == null) {
                    progressDialog = new ProgressDialog(context);
                    progressDialog.setMessage(context.getString(resID));
                    progressDialog.setCancelable(false);
                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    progressDialog.setIndeterminate(false);
                    progressDialog.show();
                } else {
                    progressDialog.setMessage(context.getString(resID));
                    progressDialog.setCancelable(false);
                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    progressDialog.setIndeterminate(false);

                    if (!progressDialog.isShowing()) {
                        progressDialog.show();
                    }
                }
            }
        } catch (Throwable throwable) {
            Log.i(TAG, "showProgressBar: throwable :- " + throwable.getMessage());
        }
    }

    public static void hideProgressDialog() {
        try {
            if (progressDialog != null) {
                progressDialog.dismiss();
            }
        } catch (Exception e) {
            Log.i(TAG, "hideProgressDialog: error :- " + e.getMessage());
        }
        progressDialog = null;
    }

    public static boolean isActivityActive(Activity activity) {
        if (null != activity)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
                return !activity.isFinishing() && !activity.isDestroyed();
            else return !activity.isFinishing();
        return false;
    }

    public static boolean isContextActive(Context context) {
        if (null != context)
            if (context instanceof Activity) {
                return isActivityActive((Activity) context);
            } else {
                return true;
            }
        return false;
    }

    public static void showKeyboard(Context context, EditText editText) {

        if (editText != null) {
            editText.requestFocus();
        }

        InputMethodManager imm =
                (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }

    public static void hideKeyboard(@NonNull Activity activity, EditText editText) {
        InputMethodManager imm =
                (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);

        if (editText != null) {
            editText.clearFocus();
            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        } else {
            View view = activity.getCurrentFocus();
            if (view == null) {
                view = new View(activity);
            }
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @RequiresApi(api = 30)
    public static IntentSender deleteFileOnAboveQ(ArrayList<String> arrayList, Context context) {
        List<Uri> arrayList2 = new ArrayList();
        for (int i = 0; i < arrayList.size(); i++) {

            Log.e("TAG121", "deleteFileOnAboveQ: " + getExt(new File(arrayList.get(i)).getName()));
            if (isImage(getExt(new File(arrayList.get(i)).getName()))) {
                arrayList2.add(getImageUriFromFile(arrayList.get(i), context));
            } else {
                arrayList2.add(getVideoUriFromFile(arrayList.get(i), context));
            }

            // arrayList2.add(getImageUriFromFile(arrayList.get(i), context));

        }
        try {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                return MediaStore.createDeleteRequest(context.getContentResolver(), arrayList2).getIntentSender();
//            }
        } catch (SecurityException e) {
            e.printStackTrace();
            RecoverableSecurityException recoverableSecurityException = (RecoverableSecurityException) e;
            if (Build.VERSION.SDK_INT >= 26) {
                return recoverableSecurityException.getUserAction().getActionIntent().getIntentSender();
            }
            return null;
        }
//        return  null;
    }
}