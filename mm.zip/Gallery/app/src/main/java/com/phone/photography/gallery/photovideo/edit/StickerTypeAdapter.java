package com.phone.photography.gallery.photovideo.edit;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;


import com.phone.photography.gallery.photovideo.R;


import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;

public class StickerTypeAdapter extends RecyclerView.Adapter<ViewHolder> {
    private ArrayList<String> stickerPath = new ArrayList<>();
    private int[] stickerCount;
    private StickerActivity stickerActivity;
    private ImageClick imageClick = new ImageClick();

    public StickerTypeAdapter(StickerActivity fragment) {
        super();
        this.stickerActivity = fragment;
        listAssetFiles("sticker");
    }

    private boolean listAssetFiles(String path) {

        String[] list;

        try {
            list = stickerActivity.getAssets().list(path);
            if (list.length > 0) {
                // This is a folder
                if (stickerCount == null) {
                    stickerCount = new int[list.length + 1];
                }
                for (int i = 0; i < list.length; i++) {
                    String file = list[i];
                    if (!listAssetFiles(path + "/" + file)) {
                        return false;
                    } else {
                        if (!file.contains(".")) {
                            stickerPath.add(path + "/" + file);
                            Log.d("TAG", "listAssetFiles: " + i);
                            stickerCount[i] = list.length;
                            System.out.println("This is a folder = " + path + "/" + file);
                        }
                    }

                }
            }
        } catch (IOException e) {
            return false;
        }

        return true;

    }

    public class ImageHolder extends ViewHolder {
        public ImageView icon;
        public TextView text;
        LinearLayout lout_item;

        ImageHolder(View itemView) {
            super(itemView);
            this.icon = itemView.findViewById(R.id.icon);
            this.text = itemView.findViewById(R.id.text);
            this.lout_item = itemView.findViewById(R.id.lout_item);
        }
    }

    @Override
    public int getItemCount() {
        return stickerPath.size();
    }

    @Override
    public int getItemViewType(int position) {
        return 1;
    }

    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int viewtype) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.view_sticker_type_item, parent, false);
        return new ImageHolder(view);
    }

    @Override
    public void onBindViewHolder(@NotNull ViewHolder holder, int position) {
        ImageHolder imageHolder = (ImageHolder) holder;
        String name = stickerPath.get(position);
        Log.d("TAG", "onBindViewHolder: " + name);
        String text = String.valueOf(name.split("/")[1].charAt(0)).toUpperCase() + name.split("/")[1].subSequence(1, name.split("/")[1].length());
        if (text.equalsIgnoreCase("animal")) {
            imageHolder.icon.setImageDrawable(stickerActivity.getResources().getDrawable(R.drawable.ic_animal_unselect));
        } else if (text.equalsIgnoreCase("emoji")) {
            imageHolder.icon.setImageDrawable(stickerActivity.getResources().getDrawable(R.drawable.ic_emoji_unselect));
        } else if (text.equalsIgnoreCase("Face")) {
            imageHolder.icon.setImageDrawable(stickerActivity.getResources().getDrawable(R.drawable.ic_face_unselect));
        } else if (text.equalsIgnoreCase("Gesture")) {
            imageHolder.icon.setImageDrawable(stickerActivity.getResources().getDrawable(R.drawable.ic_gesture_unselect));
        } else if (text.equalsIgnoreCase("Group")) {
            imageHolder.icon.setImageDrawable(stickerActivity.getResources().getDrawable(R.drawable.ic_group_unselect));
        } else if (text.equalsIgnoreCase("Heart")) {
            imageHolder.icon.setImageDrawable(stickerActivity.getResources().getDrawable(R.drawable.ic_heart_unselect));
        } else if (text.equalsIgnoreCase("Symbol")) {
            imageHolder.icon.setImageDrawable(stickerActivity.getResources().getDrawable(R.drawable.ic_symbol_unselect));
        }
        imageHolder.text.setText(text);
        imageHolder.lout_item.setTag(R.id.TAG_STICKERS_PATH, stickerPath.get(position));
        imageHolder.lout_item.setTag(R.id.TAG_STICKERS_COUNT, stickerCount[position]);
        imageHolder.lout_item.setOnClickListener(imageClick);

   /*imageHolder.text.setTag(R.id.TAG_STICKERS_PATH, stickerPath.get(position));
        imageHolder.text.setTag(R.id.TAG_STICKERS_COUNT, stickerCount[position]);
        imageHolder.text.setOnClickListener(imageClick);*/
    }

    private final class ImageClick implements OnClickListener {
        @Override
        public void onClick(View v) {
            String data = (String) v.getTag(R.id.TAG_STICKERS_PATH);
            int count = (int) v.getTag(R.id.TAG_STICKERS_COUNT);
            stickerActivity.swipToStickerDetails(data, count);
        }
    }
}
