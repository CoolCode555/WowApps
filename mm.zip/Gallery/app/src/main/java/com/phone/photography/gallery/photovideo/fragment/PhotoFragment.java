package com.phone.photography.gallery.photovideo.fragment;

import static com.phone.photography.gallery.photovideo.util.Utils.getExt;
import static com.phone.photography.gallery.photovideo.util.Utils.getImageUriFromFile;
import static com.phone.photography.gallery.photovideo.util.Utils.getVideoUriFromFile;
import static com.phone.photography.gallery.photovideo.util.Utils.isImage;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.app.RecoverableSecurityException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.customlibraries.adsutils.AdsUtils;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.activity.DisplayImageActivity;
import com.phone.photography.gallery.photovideo.activity.HomeActivity;
import com.phone.photography.gallery.photovideo.adapter.PhotoAdapter;

import com.phone.photography.gallery.photovideo.model.AlbumCreateEvent;
import com.phone.photography.gallery.photovideo.model.CopyMoveEvent;
import com.phone.photography.gallery.photovideo.model.DeleteEvent;
import com.phone.photography.gallery.photovideo.model.DisplayDeleteEvent;
import com.phone.photography.gallery.photovideo.model.EditImageEvent;
import com.phone.photography.gallery.photovideo.model.ImageCloseEvent;
import com.phone.photography.gallery.photovideo.model.ImageShareDeleteEvent;
import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;
import com.phone.photography.gallery.photovideo.oncliclk.OnSelectedHome;
import com.phone.photography.gallery.photovideo.service.ImageDataService;
import com.phone.photography.gallery.photovideo.util.AppUtils;
import com.phone.photography.gallery.photovideo.util.Constant;
import com.phone.photography.gallery.photovideo.util.RxBus;
import com.phone.photography.gallery.photovideo.util.Utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class PhotoFragment extends Fragment {


    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @BindView(R.id.lout_no_data)
    LinearLayout loutNoData;

    ProgressDialog loadingDialog;

    public LinkedHashMap<String, ArrayList<PhotoData>> bucketimagesDataPhotoHashMap;
    List<Object> photoList = new ArrayList<>();
    PhotoAdapter adapter;
    OnSelectedHome selectedHome;

    int selected_Item = 0;
    ArrayList<String> deleteList;

    private ActivityResultLauncher<IntentSenderRequest> deleteIntentSenderLauncher;
    public PhotoFragment(OnSelectedHome selectedHome) {
        this.selectedHome = selectedHome;
    }

    public PhotoFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.photo_fragment, container, false);
        ButterKnife.bind(this, view);
        initViews();

        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        displayDeleteEvent();
        deleteEvent();
        closeEvent();
        shareDeleteEvent();
        newAlbumEvent();
        copyMoveEvent();
        editPhotoEvent();
        setDeleteIntentLauncher();
    }


    private void setDeleteIntentLauncher() {
        this.deleteIntentSenderLauncher = registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
//                AdvertiseHandler.getInstance().isNeedOpenAdRequest = false;
                if (result.getResultCode() == Activity.RESULT_OK) {
//                    updateDataOnDelete();
                    updateDeleteImageData(deleteList);
                } else if (result.getResultCode() == Activity.RESULT_CANCELED) {
                    selected_Item = 0;
//                    ((HomeActivity) getActivity()).longClick(true, false, 0, false);
                    setClose();
                }


            }
        });
    }




    private void initViews() {
        bucketimagesDataPhotoHashMap = new LinkedHashMap<>();
        //    photoList = new ArrayList<>();

        progressBar.setVisibility(View.VISIBLE);
        new Thread(this::getData).start();

        loadingDialog = new ProgressDialog(getActivity());
        loadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        loadingDialog.setCancelable(false);
        loadingDialog.setMessage("Delete image...");
        loadingDialog.setCanceledOnTouchOutside(false);
    }


    private void displayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DisplayDeleteEvent>() {
            @Override
            public void call(DisplayDeleteEvent event) {

                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> deleteList = new ArrayList<>();
                    deleteList = event.getDeleteList();

                    updateDeleteImageData(deleteList);


                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void updateDeleteImageData(ArrayList<String> deleteList) {
        if (photoList != null && photoList.size() != 0) {

            for (int d = 0; d < deleteList.size(); d++) {

                for (int i = 0; i < photoList.size(); i++) {

                    if (photoList.get(i) instanceof PhotoData) {
                        PhotoData model = (PhotoData) photoList.get(i);

                        if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {

                            boolean isPre = false, isNext = false;

                            if (i != 0) {
                                if (photoList.get(i - 1) instanceof PhotoHeader) {
                                    isPre = true;
                                } else {
                                    isPre = false;
                                }
                            }

                            if (i < (photoList.size() - 2)) {
                                if (photoList.get(i + 1) instanceof PhotoHeader) {
                                    isNext = true;
                                } else {
                                    isNext = false;
                                }
                            }

                            if (isPre && isNext) {
                                //  objectList.remove(i + 1);
                                photoList.remove(i);
                                photoList.remove(i - 1);

                            } else if (i == (photoList.size() - 1)) {
                                if (isPre) {
                                    photoList.remove(i);
                                    photoList.remove(i - 1);
                                } else {
                                    photoList.remove(i);
                                }
                            } else {
                                photoList.remove(i);
                            }

                            if (i != 0) {
                                i--;
                            }

                            if (d == deleteList.size() - 1) {
                                break;
                            }

                        }

                    }

                }
            }

            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }

            ImageDataService.photoAlbumList = new ArrayList<>();
            ImageDataService.photoAlbumList.addAll(photoList);

            if (photoList != null && photoList.size() != 0) {
                recyclerView.setVisibility(View.VISIBLE);
                loutNoData.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                loutNoData.setVisibility(View.VISIBLE);
            }
        }
    }

    private void copyMoveEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(CopyMoveEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<CopyMoveEvent>() {
            @Override
            public void call(CopyMoveEvent event) {
                if (event.getCopyMoveList() != null && event.getCopyMoveList().size() != 0) {
                    ArrayList<String> imageList = new ArrayList<>();
                    imageList = event.getCopyMoveList();

                    if (imageList == null) {
                        imageList = new ArrayList<>();
                    }
                    File file = new File(event.getAlbumPath());

                    SimpleDateFormat format = new SimpleDateFormat("MMM yyyy");
                    String strDate = "";

                    if (file.exists()) {
                        ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                        for (int i = 0; i < imageList.size(); i++) {

                            File file1 = new File(imageList.get(i));

                            if (file1.exists()) {
                                PhotoData imagesData = new PhotoData();
                                strDate = format.format(file1.lastModified());
                                imagesData.setFilePath(file1.getPath());
                                imagesData.setFileName(file1.getName());
                                imagesData.setFolderName(file.getName());
                                imagesData1.add(imagesData);
                            }
                        }

                        if (imagesData1 != null && imagesData1.size() != 0) {
                            Collections.sort(imagesData1, new Comparator<PhotoData>() {
                                @Override
                                public int compare(PhotoData photoData, PhotoData t1) {
                                    File file1 = new File(photoData.getFilePath());
                                    File file2 = new File(t1.getFilePath());

                                    SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm");
                                    String strDate1 = format.format(file1.lastModified());
                                    String strDate2 = format.format(file2.lastModified());

                                    int compareResult = 0;

                                    Date date1 = null;
                                    Date date2 = null;
                                    try {
                                        date1 = format.parse(strDate1);
                                        date2 = format.parse(strDate2);
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }


                                    compareResult = date2.compareTo(date1);

                                    return compareResult;
                                }
                            });

                            PhotoHeader bucketData = new PhotoHeader();

                            bucketData.setTitle(strDate);
                            bucketData.setPhotoList(imagesData1);

                            boolean isAdd = false;
                            if (photoList != null && photoList.size() != 0) {
                                try {
                                    if (photoList.get(0) instanceof PhotoHeader) {
                                        PhotoHeader model = (PhotoHeader) photoList.get(0);
                                        if (model.getTitle().equalsIgnoreCase(strDate)) {
                                            isAdd = true;
                                            for (int i = 0; i < imagesData1.size(); i++) {
                                                photoList.add(1, imagesData1.get(i));
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            } else {
                                photoList = new ArrayList<>();
                            }

                            if (!isAdd) {
                                photoList.add(0, bucketData);
                                for (int i = 0; i < imagesData1.size(); i++) {
                                    photoList.add(1, imagesData1.get(i));
                                }
                            }


//                        folderList.add(0, bucketData);

                            for (int i = 0; i < photoList.size(); i++) {

                                if (photoList.get(i) != null)
                                    if (photoList.get(i) instanceof PhotoData) {

                                        PhotoData model = (PhotoData) photoList.get(i);
                                        model.setCheckboxVisible(false);
                                        model.setSelected(false);

                                    }

                            }

                            if (adapter != null) {
                                adapter.notifyDataSetChanged();
                            } else {
                                setAdapter();
                            }

                            if (photoList != null && photoList.size() != 0) {
                                recyclerView.setVisibility(View.VISIBLE);
                                loutNoData.setVisibility(View.GONE);
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                loutNoData.setVisibility(View.VISIBLE);
                            }

                            ImageDataService.photoAlbumList = new ArrayList<>();
                            ImageDataService.photoAlbumList.addAll(photoList);

                        }
                    }

                }

                ArrayList<String> deleteList = new ArrayList<>();
                deleteList = event.getDeleteList();
                if (deleteList != null && deleteList.size() != 0)
                    updateDeleteImageData(deleteList);

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void newAlbumEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(AlbumCreateEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<AlbumCreateEvent>() {
            @Override
            public void call(AlbumCreateEvent event) {
                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> imageList = new ArrayList<>();
                    imageList = event.getDeleteList();

                    if (imageList == null) {
                        imageList = new ArrayList<>();
                    }
                    File file = new File(event.getAlbumName());

                    SimpleDateFormat format = new SimpleDateFormat("MMM yyyy");
                    String strDate = "";

                    if (file.exists()) {
                        ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                        for (int i = 0; i < imageList.size(); i++) {

                            File file1 = new File(imageList.get(i));

                            if (file1.exists()) {
                                PhotoData imagesData = new PhotoData();
                                strDate = format.format(file1.lastModified());
                                imagesData.setFilePath(file1.getPath());
                                imagesData.setFileName(file1.getName());
                                imagesData.setFolderName(file.getName());
                                imagesData1.add(imagesData);
                            }
                        }

                        if (imagesData1 != null && imagesData1.size() != 0) {
                            Collections.sort(imagesData1, new Comparator<PhotoData>() {
                                @Override
                                public int compare(PhotoData photoData, PhotoData t1) {
                                    File file1 = new File(photoData.getFilePath());
                                    File file2 = new File(t1.getFilePath());

                                    SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm");
                                    String strDate1 = format.format(file1.lastModified());
                                    String strDate2 = format.format(file2.lastModified());

                                    int compareResult = 0;

                                    Date date1 = null;
                                    Date date2 = null;
                                    try {
                                        date1 = format.parse(strDate1);
                                        date2 = format.parse(strDate2);
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }


                                    compareResult = date2.compareTo(date1);

                                    return compareResult;
                                }
                            });

                            PhotoHeader bucketData = new PhotoHeader();

                            bucketData.setTitle(strDate);
                            bucketData.setPhotoList(imagesData1);

                            boolean isAdd = false;
                            if (photoList != null && photoList.size() != 0) {
                                try {
                                    if (photoList.get(0) instanceof PhotoHeader) {
                                        PhotoHeader model = (PhotoHeader) photoList.get(0);
                                        if (model.getTitle().equalsIgnoreCase(strDate)) {
                                            isAdd = true;
                                            for (int i = 0; i < imagesData1.size(); i++) {
                                                photoList.add(1, imagesData1.get(i));
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            } else {
                                photoList = new ArrayList<>();
                            }

                            if (!isAdd) {
                                photoList.add(0, bucketData);
                                for (int i = 0; i < imagesData1.size(); i++) {
                                    photoList.add(1, imagesData1.get(i));
                                }
                            }


//                        folderList.add(0, bucketData);

                            for (int i = 0; i < photoList.size(); i++) {

                                if (photoList.get(i) != null)
                                    if (photoList.get(i) instanceof PhotoData) {

                                        PhotoData model = (PhotoData) photoList.get(i);
                                        model.setCheckboxVisible(false);
                                        model.setSelected(false);

                                    }

                            }

                            if (adapter != null) {
                                adapter.notifyDataSetChanged();
                            } else {
                                setAdapter();
                            }

                            if (photoList != null && photoList.size() != 0) {
                                recyclerView.setVisibility(View.VISIBLE);
                                loutNoData.setVisibility(View.GONE);
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                loutNoData.setVisibility(View.VISIBLE);
                            }

                            ImageDataService.photoAlbumList = new ArrayList<>();
                            ImageDataService.photoAlbumList.addAll(photoList);


                            ArrayList<String> deleteList = new ArrayList<>();
                            deleteList = event.getDeleteFileList();
                            if (deleteList != null && deleteList.size() != 0)
                                updateDeleteImageData(deleteList);
                        }
                    }

                } else {
                    for (int i = 0; i < photoList.size(); i++) {

                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PhotoData) {

                                PhotoData model = (PhotoData) photoList.get(i);
                                model.setCheckboxVisible(false);
                                model.setSelected(false);

                            }

                    }
                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }


    private void editPhotoEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(EditImageEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<EditImageEvent>() {
            @Override
            public void call(EditImageEvent event) {
                if (event.getImagePath() != null && !event.getImagePath().equalsIgnoreCase("")) {

                    File file = new File(event.getImagePath());

                    SimpleDateFormat format = new SimpleDateFormat("MMM yyyy");
                    String strDate = "";

                    if (file.exists()) {
                        ArrayList<PhotoData> imagesData1 = new ArrayList<>();

                        PhotoData imagesData = new PhotoData();
                        strDate = format.format(file.lastModified());
                        imagesData.setFilePath(file.getPath());
                        imagesData.setFileName(file.getName());
                        imagesData.setFolderName(event.getFolderName());
                        imagesData1.add(imagesData);

                        if (imagesData1 != null && imagesData1.size() != 0) {

                            PhotoHeader bucketData = new PhotoHeader();

                            bucketData.setTitle(strDate);
                            bucketData.setPhotoList(imagesData1);

                            boolean isAdd = false;
                            if (photoList != null && photoList.size() != 0) {
                                try {
                                    if (photoList.get(0) instanceof PhotoHeader) {
                                        PhotoHeader model = (PhotoHeader) photoList.get(0);
                                        if (model.getTitle().equalsIgnoreCase(strDate)) {
                                            isAdd = true;
                                            for (int i = 0; i < imagesData1.size(); i++) {
                                                photoList.add(1, imagesData1.get(i));
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            } else {
                                photoList = new ArrayList<>();
                            }

                            if (!isAdd) {
                                photoList.add(0, bucketData);
                                for (int i = 0; i < imagesData1.size(); i++) {
                                    photoList.add(1, imagesData1.get(i));
                                }
                            }


//                        folderList.add(0, bucketData);

                            for (int i = 0; i < photoList.size(); i++) {

                                if (photoList.get(i) != null)
                                    if (photoList.get(i) instanceof PhotoData) {

                                        PhotoData model = (PhotoData) photoList.get(i);
                                        model.setCheckboxVisible(false);
                                        model.setSelected(false);

                                    }

                            }

                            if (adapter != null) {
                                adapter.notifyDataSetChanged();
                            } else {
                                setAdapter();
                            }

                            if (photoList != null && photoList.size() != 0) {
                                recyclerView.setVisibility(View.VISIBLE);
                                loutNoData.setVisibility(View.GONE);
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                loutNoData.setVisibility(View.VISIBLE);
                            }

                            ImageDataService.photoAlbumList = new ArrayList<>();
                            ImageDataService.photoAlbumList.addAll(photoList);
                        }
                    }

                } else {
                    for (int i = 0; i < photoList.size(); i++) {

                        if (photoList.get(i) != null)
                            if (photoList.get(i) instanceof PhotoData) {

                                PhotoData model = (PhotoData) photoList.get(i);
                                model.setCheckboxVisible(false);
                                model.setSelected(false);

                            }

                    }
                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }


    private void deleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DeleteEvent>() {
            @Override
            public void call(DeleteEvent event) {

                if (event.getPos() != 0) {
                    if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                        ArrayList<String> deleteList = new ArrayList<>();
                        deleteList = event.getDeleteList();


                        if (photoList != null && photoList.size() != 0) {

                            for (int d = 0; d < deleteList.size(); d++) {

                                for (int i = 0; i < photoList.size(); i++) {

                                    if (photoList.get(i) instanceof PhotoData) {
                                        PhotoData model = (PhotoData) photoList.get(i);

                                        if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {

                                            boolean isPre = false, isNext = false;

                                            if (i != 0) {
                                                if (photoList.get(i - 1) instanceof PhotoHeader) {
                                                    isPre = true;
                                                } else {
                                                    isPre = false;
                                                }
                                            }

                                            if (i < (photoList.size() - 2)) {
                                                if (photoList.get(i + 1) instanceof PhotoHeader) {
                                                    isNext = true;
                                                } else {
                                                    isNext = false;
                                                }
                                            }

                                            if (isPre && isNext) {
                                                //  objectList.remove(i + 1);
                                                photoList.remove(i);
                                                photoList.remove(i - 1);

                                            } else if (i == (photoList.size() - 1)) {
                                                if (isPre) {
                                                    photoList.remove(i);
                                                    photoList.remove(i - 1);
                                                } else {
                                                    photoList.remove(i);
                                                }
                                            } else {
                                                photoList.remove(i);
                                            }

                                            if (i != 0) {
                                                i--;
                                            }

                                            if (d == deleteList.size() - 1) {
                                                break;
                                            }

                                        }

                                    }

                                }
                            }

                            if (adapter != null) {
                                adapter.notifyDataSetChanged();
                            }
                            if (photoList != null && photoList.size() != 0) {
                                recyclerView.setVisibility(View.VISIBLE);
                                loutNoData.setVisibility(View.GONE);
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                loutNoData.setVisibility(View.VISIBLE);
                            }

                            ImageDataService.photoAlbumList = new ArrayList<>();
                            ImageDataService.photoAlbumList.addAll(photoList);
                        }

                    }
                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }


    private void getData() {

        try {
            while (true) {
                if (ImageDataService.isComplete) {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        requireActivity().runOnUiThread(() -> {
            Log.e("ImageGet", "photo set list....");
            photoList = new ArrayList<>();
            photoList.addAll(ImageDataService.photoList);
            setAdapter();
        });
    }


    private void setAdapter() {
        Log.e("ImageGet", "photo set list....");
        progressBar.setVisibility(View.GONE);

        if (photoList != null && photoList.size() != 0) {
            recyclerView.setVisibility(View.VISIBLE);
            loutNoData.setVisibility(View.GONE);

            GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 4, LinearLayoutManager.VERTICAL, false);
            recyclerView.setLayoutManager(gridLayoutManager);
            adapter = new PhotoAdapter(getActivity(), photoList);
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(final int position) {
                    if (adapter.getItemViewType(position) == PhotoAdapter.ITEM_HEADER_TYPE || adapter.getItemViewType(position) == PhotoAdapter.TYPE_AD) {
                        return 4;
                    }
                    return 1;
                }
            });
            recyclerView.setAdapter(adapter);

            adapter.setOnItemClickListener(new PhotoAdapter.ClickListener() {
                @Override
                public void onItemClick(int position, View v) {
                    try {


                        if (photoList.get(position) instanceof PhotoData) {

                            PhotoData imageList = (PhotoData) photoList.get(position);
                            if (imageList.isCheckboxVisible()) {

                                if (imageList.isSelected()) {
                                    imageList.setSelected(false);
                                } else
                                    imageList.setSelected(true);
                                adapter.notifyItemChanged(position);
                                setSelectedFile();

                            } else {
                                int pos = -1;
                                List<PhotoData> dataList = new ArrayList<>();

                                for (int i = 0; i < photoList.size(); i++) {
                                    if (photoList.get(i) instanceof PhotoData) {
                                        dataList.add((PhotoData) photoList.get(i));
                                        if (position == i) {
                                            pos = dataList.size() - 1;
                                        }
                                    }
                                }

                                Constant.displayImageList = new ArrayList<>();
                                Constant.displayImageList.addAll(dataList);
                                Intent intent = new Intent(getActivity(), DisplayImageActivity.class);
                                intent.putExtra("pos", pos);
                                intent.putExtra("IsFavList", false);
                                startActivity(intent);

                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            });

            adapter.setOnLongClickListener(new PhotoAdapter.LongClickListener() {
                @Override
                public void onItemLongClick(int position, View v) {
                    try {

                        if (photoList.get(position) instanceof PhotoData) {
                            PhotoData imageList = (PhotoData) photoList.get(position);

                            for (int i = 0; i < photoList.size(); i++) {
                                if (photoList.get(i) != null)

                                    if (photoList.get(i) instanceof PhotoData) {

                                        PhotoData model = (PhotoData) photoList.get(i);
                                        model.setCheckboxVisible(true);

                                    }

                            }
                            imageList.setCheckboxVisible(true);
                            imageList.setSelected(true);

                            adapter.notifyDataSetChanged();
                            setSelectedFile();

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


            });

        } else {
            recyclerView.setVisibility(View.GONE);
            loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void setSelectedFile() {
        int selected = 0;

        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                    }

                }
        }


        if (selected == 0) {

            selectedHome.OnSelected(true, false, selected);
            setClose();
        } else {
            selectedHome.OnSelected(false, true, selected);

        }

        selected_Item = selected;
    }

    private void setClose() {
        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);

                }

        }

        if (adapter != null)
            adapter.notifyDataSetChanged();
        selected_Item = 0;

    }

    private void shareDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(ImageShareDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<ImageShareDeleteEvent>() {
            @Override
            public void call(ImageShareDeleteEvent event) {
                if (event.getPos() == 0) {
                    if (selected_Item != 0) {
                        if (event.getType().equalsIgnoreCase(getString(R.string.share))) {

                            ArrayList<Uri> uris = new ArrayList<>();
                            Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);

                            for (int i = 0; i < photoList.size(); i++) {

                                if (photoList.get(i) != null)
                                    if (photoList.get(i) instanceof PhotoData) {

                                        PhotoData model = (PhotoData) photoList.get(i);
                                        if (model.isSelected()) {
                                            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".provider", new File(model.getFilePath()));
                                            uris.add(uri);
                                        }

                                    }
                            }

                            intent.setType("*/*");
                            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            getContext().startActivity(Intent.createChooser(intent, "Share with..."));


                        } else if (event.getType().equalsIgnoreCase(getString(R.string.delete))) {
//                            showDeleteDialog();

deletePhoto();
                        }
                    } else {
                        Toast.makeText(getActivity(), "Please select image", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void deletePhoto() {

        deleteList = new ArrayList<>();

        if (Utils.isVersionQAbove()) {

            Log.e("TAG1017", "deletePhoto: " + "isVersionQAbove");
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null) {
                    if (photoList.get(i) instanceof PhotoData) {

                        PhotoData photoData = (PhotoData) photoList.get(i);
//                        PictureData photoData = (PictureData) pictures.get(i);
                        if (photoData.isSelected()) {
                            deleteList.add(photoData.getFilePath());
                        } else {
                            photoData.setCheckboxVisible(false);
                        }
                    }
                }
            }
            Log.e("TAG1091", "deletePhoto: " + deleteList.size());
            IntentSender deleteFileOnAboveQ = AppUtils.deleteFileOnAboveQ(deleteList, getActivity());
            if (deleteFileOnAboveQ != null) {
                deleteIntentSenderLauncher.launch(new IntentSenderRequest.Builder(deleteFileOnAboveQ).build());
                return;
            }
            Toast.makeText(getActivity(), "Error...!", Toast.LENGTH_SHORT).show();

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("Are you sure want to delete it?");
            builder.setCancelable(false);
            builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
//                    if (loadingDialog != null)
//                        if (!loadingDialog.isShowing()) {
//                            loadingDialog.setMessage("Delete image...");
//                            loadingDialog.show();
//                        }

//                    new Thread(this::deletePhoto).start();
                    deletePhoto1();

                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.show();
        }


    }




    public void deletePhoto1() {

        ArrayList<String> deleteList = new ArrayList<>();
        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    if (model.isSelected()) {

                        File file = new File(model.getFilePath());
                        Uri deleteUrl = FileProvider.getUriForFile(getActivity(), getActivity().getApplicationContext().getPackageName() + ".provider", file);
                        ContentResolver contentResolver = getActivity().getContentResolver();
                        contentResolver.delete(deleteUrl, null, null);

                        try {
                            file.delete();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        try {
                            FileUtils.deleteDirectory(file);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        MediaScannerConnection.scanFile(getActivity(), new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                                // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                            }
                        });


                        deleteList.add(file.getPath());
                    } else {

                        model.setCheckboxVisible(false);
                    }

                }
        }

        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)

                if (photoList.get(i) instanceof PhotoData) {
                    PhotoData model = (PhotoData) photoList.get(i);
                    if (model.isSelected()) {
                        boolean isPre = false, isNext = false;

                        if (i != 0) {
                            if (photoList.get(i - 1) instanceof PhotoHeader) {
                                isPre = true;
                            } else {
                                isPre = false;
                            }
                        }

                        if (i < (photoList.size() - 2)) {
                            if (photoList.get(i + 1) instanceof PhotoHeader) {
                                isNext = true;
                            } else {
                                isNext = false;
                            }
                        }

                        if (isPre && isNext) {
                            //  objectList.remove(i + 1);
                            photoList.remove(i);
                            photoList.remove(i - 1);

                        } else if (i == (photoList.size() - 1)) {
                            if (isPre) {
                                photoList.remove(i);
                                photoList.remove(i - 1);
                            } else {
                                photoList.remove(i);
                            }
                        } else {
                            photoList.remove(i);
                        }

                        if (i != 0) {
                            i--;
                        }
                    }
                }
        }

        requireActivity().runOnUiThread(() -> {
            RxBus.getInstance().post(new DeleteEvent(0, deleteList));
            if (loadingDialog != null)
                if (loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }

            selected_Item = 0;
            selectedHome.OnSelected(true, false, 0);
            adapter.notifyDataSetChanged();
            Toast.makeText(getActivity(), "Delete image successfully", Toast.LENGTH_SHORT).show();
        });

    }


    private void showDeleteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlert);
        builder.setMessage("Are you sure do you want to delete it?");
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (loadingDialog != null)
                    if (!loadingDialog.isShowing()) {
                        loadingDialog.setMessage("Delete image...");
                        loadingDialog.show();
                    }

//                new Thread(this::deletePhoto).start();
            }


        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }


    private void closeEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(ImageCloseEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<ImageCloseEvent>() {
            @Override
            public void call(ImageCloseEvent event) {
                if (event.getPos() == 0) {

                    setClose();
                }
            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }


    public void getImagesList() {
        List<PhotoHeader> folderDataList = new ArrayList<>();
        Cursor mCursor = null;

        String[] projection = {MediaStore.Images.Media.DATA, MediaStore.Images.Media.TITLE, MediaStore.Images.Media.DATE_MODIFIED
                , MediaStore.Images.Media.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.ORIENTATION
                , MediaStore.Images.Media.LATITUDE
                , MediaStore.Images.Media.LONGITUDE, MediaStore.Images.Media._ID};

        mCursor = getContext().getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, // Uri
                projection, // Projection
                null,
                null,
                "LOWER(" + MediaStore.Images.Media.DATE_MODIFIED + ") DESC");

        if (mCursor != null) {
            File file = null;
            if (mCursor.moveToFirst()) {
                do {
                    String path = mCursor.getString(mCursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));
                    @SuppressLint("Range") String title = mCursor.getString(mCursor.getColumnIndex(projection[1]));
                    if (title != null) {
                    } else {
                        title = "";
                    }
                    @SuppressLint("Range") String date = mCursor.getString(mCursor.getColumnIndex(projection[2]));
                    @SuppressLint("Range") String bucketName = mCursor.getString(mCursor.getColumnIndex(projection[3]));
                    @SuppressLint("Range") int orientation = mCursor.getInt(mCursor.getColumnIndex(projection[4]));
                    // long size = mCursor.getLong(7);
                    String id = mCursor.getString(7);
                    try {
                        file = new File(path);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                    if (file != null && file.exists()) {

                        SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy");
                        String strDate = format.format(file.lastModified());

                        PhotoData imagesData = new PhotoData();
                        imagesData.setFilePath(path);
                        imagesData.setFileName(title);
                        imagesData.setFolderName(bucketName);

                        Log.d("TAG", "getAllImagesAndVideoData: " + id);

                        if (bucketimagesDataPhotoHashMap.containsKey(strDate)) {
                            ArrayList<PhotoData> imagesData1 = bucketimagesDataPhotoHashMap.get(strDate);
                            if (imagesData1 == null)
                                imagesData1 = new ArrayList<>();

                            imagesData1.add(imagesData);
                            bucketimagesDataPhotoHashMap.put(strDate, imagesData1);

                        } else {
                            ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                            imagesData1.add(imagesData);
                            bucketimagesDataPhotoHashMap.put(strDate, imagesData1);
                        }
                    }
                } while (mCursor.moveToNext());
            }
            mCursor.close();
        }

        Set<String> keys = bucketimagesDataPhotoHashMap.keySet();
        ArrayList<String> listkeys = new ArrayList<>();
        listkeys.addAll(keys);


        for (int i = 0; i < listkeys.size(); i++) {
            ArrayList<PhotoData> imagesData = bucketimagesDataPhotoHashMap.get(listkeys.get(i));

            if (imagesData != null && imagesData.size() != 0) {
                PhotoHeader bucketData = new PhotoHeader();

                bucketData.setTitle(listkeys.get(i));
                bucketData.setPhotoList(imagesData);

                folderDataList.add(bucketData);

                photoList.add(bucketData);
                photoList.addAll(imagesData);
            }
        }

        requireActivity().runOnUiThread(() -> {
            setAdapter();
        });

    }


}
