package com.phone.photography.gallery.photovideo.edit.imagezoom.utils;

public interface IDisposable {
	void dispose();
}
