package com.phone.photography.gallery.photovideo.edit;


public interface OnItemClickListner {
    void onItemClickListner(int position);
}
