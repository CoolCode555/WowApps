package com.phone.photography.gallery.photovideo.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PreferencesUtility {

    public static void setRateUs(Context context, boolean rateus) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        sp.edit().putBoolean(Constant.PREF_RATE_US, rateus).apply();
    }

    public static boolean getRateUS(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getBoolean(Constant.PREF_RATE_US, false);
    }

    public static void setSlideshowInterval(Context context, int interval) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        sp.edit().putInt(Constant.PREF_SLIDESHOW_INTERVAL, interval).apply();
    }

    public static int getSlideshowInterval(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getInt(Constant.PREF_SLIDESHOW_INTERVAL, 3);
    }

    public static List<String> getFavoriteList(Context context) {
        List<String> list = new ArrayList<>();
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);

        try {
            String response = preferences.getString(Constant.PREF_FAVORITE_LIST, "");

            Gson gson = new Gson();
            Type type = new TypeToken<List<String>>() {
            }.getType();
            list = gson.fromJson(response, type);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static void setFavoriteList(Context context, List<String> list) {

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);

        editor.putString(Constant.PREF_FAVORITE_LIST, json);
        editor.apply();

    }

}
