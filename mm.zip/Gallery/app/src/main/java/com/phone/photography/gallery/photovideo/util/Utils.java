package com.phone.photography.gallery.photovideo.util;

import android.annotation.SuppressLint;
import android.app.RecoverableSecurityException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.IntentSender;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;

import android.provider.MediaStore;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import java.io.File;
import java.util.ArrayList;

public class Utils {

    public static String setDuration(long timeMs) {
        String hourString = "";
        String minuteString = "00";
        String secondString = "00";
        int hours = (int) (timeMs / 3600000);
        int minutes = ((int) (timeMs % 3600000)) / 60000;
        int seconds = (int) (((timeMs % 3600000) % 60000) / 1000);

        if (hours < 10 && hours != 0) {
            hourString = "0" + hours + ":";
        } else if (hours >= 10) {
            hourString = hours + ":";
        }

        if (minutes < 10) {
            minuteString = "0" + minutes;
        } else {
            minuteString = minutes + "";
        }

        if (seconds < 10) {
            secondString = "0" + seconds;
        } else {
            secondString = seconds + "";
        }

        return hourString + minuteString + ":" + secondString;
    }

    public static boolean isVersionQAbove() {
        return Build.VERSION.SDK_INT > 29;
    }



/*
    @RequiresApi(api = 30)
    public static IntentSender deleteFileOnAboveQ(ArrayList<String> arrayList, Context context) {
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < arrayList.size(); i++) {

            Log.e("TAG121", "deleteFileOnAboveQ: " + getExt(new File(arrayList.get(i)).getName()));
            if (isImage(getExt(new File(arrayList.get(i)).getName()))) {
                arrayList2.add(getImageUriFromFile(arrayList.get(i), context));
            } else {
                arrayList2.add(getVideoUriFromFile(arrayList.get(i), context));
            }

            // arrayList2.add(getImageUriFromFile(arrayList.get(i), context));

        }
        try {
            return MediaStore.createDeleteRequest(context.getContentResolver(), arrayList2).getIntentSender();
        } catch (SecurityException e) {
            e.printStackTrace();
            RecoverableSecurityException recoverableSecurityException = (RecoverableSecurityException) e;
            if (Build.VERSION.SDK_INT >= 26) {
                return recoverableSecurityException.getUserAction().getActionIntent().getIntentSender();
            }
            return null;
        }
    }
*/

    public static Uri getImageUriFromFile(String str, Context context) {
        ContentResolver contentResolver = context.getContentResolver();

        Cursor query = contentResolver.query(MediaStore.Images.Media.getContentUri("external"), new String[]{"_id"}, "_data = ?", new String[]{str}, "date_added desc");
        query.moveToFirst();
        if (query.isAfterLast()) {
            query.close();
            ContentValues contentValues = new ContentValues();
            contentValues.put("_data", str);
            return contentResolver.insert(MediaStore.Images.Media.getContentUri("external"), contentValues);
        }
        @SuppressLint("Range") Uri build = MediaStore.Images.Media.getContentUri("external").buildUpon().appendPath(Integer.toString(query.getInt(query.getColumnIndex("_id")))).build();
        query.close();
        return build;
    }

    public static Uri getVideoUriFromFile(String str, Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        ContentResolver contentResolver2 = contentResolver;
        Cursor query = contentResolver2.query(MediaStore.Video.Media.getContentUri("external"), new String[]{"_id"}, "_data = ?", new String[]{str}, "date_added desc");
        query.moveToFirst();
        if (query.isAfterLast()) {
            query.close();
            ContentValues contentValues = new ContentValues();
            contentValues.put("_data", str);
            return contentResolver.insert(MediaStore.Video.Media.getContentUri("external"), contentValues);
        }
        @SuppressLint("Range") Uri build = MediaStore.Video.Media.getContentUri("external").buildUpon().appendPath(Integer.toString(query.getInt(query.getColumnIndex("_id")))).build();
        query.close();
        return build;
    }


    public static String getExt(String filePath) {
        int strLength = filePath.lastIndexOf(".");
        if (strLength > 0)
            return filePath.substring(strLength + 1).toLowerCase();
        return null;
    }

    public static boolean isImage(String str) {
        if (str != null) {
            return str.equals("jpg") || str.equals("gif") || str.equals("png") || str.equals("jpeg") || str.equals("bmp") || str.equals("wbmp") || str.equals("ico") || str.equals("jpe");
        }
        return false;
    }


    public static boolean deleteFile(File file, Context context) {
        if (file == null) {
            return true;
        }
        boolean deleteFilesInFolder = deleteFilesInFolder(file);
        if (file.delete() || deleteFilesInFolder) {
            return true;
        }
        try {
            Log.e("TAG189", "deleteFile: "+getUriFromFile(file.getAbsolutePath(),context) );
            context.getContentResolver().delete(getUriFromFile(file.getAbsolutePath(), context), (String) null, (String[]) null);
            return !file.exists();
        } catch (Exception e) {
            Log.e("FileUtils", "Error when deleting manager " + file.getAbsolutePath(), e);
            return false;
        }
    }
    public static boolean deleteFilesInFolder(File file) {
        if (file == null) {
            return false;
        }
        if (file.isDirectory()) {
            for (File deleteFilesInFolder : file.listFiles()) {
                deleteFilesInFolder(deleteFilesInFolder);
            }
            if (!file.delete()) {
                return false;
            }
        } else if (!file.delete()) {
            return false;
        }
        return true;
    }

    public static Uri getUriFromFile(String str, Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        ContentResolver contentResolver2 = contentResolver;
        Cursor query = contentResolver2.query(MediaStore.Files.getContentUri("external"), new String[]{"_id"}, "_data = ?", new String[]{str}, "date_added desc");
        query.moveToFirst();
        if (query.isAfterLast()) {
            query.close();
            ContentValues contentValues = new ContentValues();
            contentValues.put("_data", str);
            return contentResolver.insert(MediaStore.Files.getContentUri("external"), contentValues);
        }
        Uri build = MediaStore.Files.getContentUri("external").buildUpon().appendPath(Integer.toString(query.getInt(query.getColumnIndex("_id")))).build();
        query.close();
        return build;
    }


}
