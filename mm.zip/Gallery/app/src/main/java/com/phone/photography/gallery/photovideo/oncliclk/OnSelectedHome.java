package com.phone.photography.gallery.photovideo.oncliclk;

public interface OnSelectedHome {
    public void OnSelected(boolean isShowToolbar, boolean isShowSelected, int selected);
}
