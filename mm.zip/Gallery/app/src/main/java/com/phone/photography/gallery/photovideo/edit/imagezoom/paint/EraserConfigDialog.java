package com.phone.photography.gallery.photovideo.edit.imagezoom.paint;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.phone.photography.gallery.photovideo.R;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class EraserConfigDialog extends BottomSheetDialogFragment implements SeekBar.OnSeekBarChangeListener {

    public EraserConfigDialog() {
        // Required empty public constructor
    }

    private Properties mProperties;

    public interface Properties {
        void onBrushSizeChanged(int brushSize);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public Properties getmProperties() {
        return mProperties;
    }

    public void setmProperties(Properties mProperties) {
        this.mProperties = mProperties;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_eraser_config, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SeekBar eraserSizeSb = view.findViewById(R.id.sbSize);
        eraserSizeSb.setOnSeekBarChangeListener(this);
    }

    public void setPropertiesChangeListener(Properties properties) {
        mProperties = properties;
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        int id = seekBar.getId();
        if (id == R.id.sbSize) {
            if (mProperties != null) {
                mProperties.onBrushSizeChanged(i);
            }
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
