package com.phone.photography.gallery.photovideo.edit;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;


import com.phone.photography.gallery.photovideo.R;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class StickerAdapter extends RecyclerView.Adapter<ViewHolder> {
    private ImageClick imageClick = new ImageClick();
    private List<String> pathList = new ArrayList<>();
    private StickerActivity context;

    public StickerAdapter(StickerActivity context) {
        super();
        this.context = context;
        pathList = new ArrayList<>();

    }

    @Override
    public int getItemCount() {
        return pathList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return 1;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewtype) {
        View view;
        view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.view_sticker_item, parent, false);
        return new StickerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        StickerViewHolder stickerViewHolder = (StickerViewHolder) viewHolder;
        String path = pathList.get(position);

        InputStream ims = null;
        try {
            Log.d("TAG", "onBindViewHolder: " + path);
            ims = context.getAssets().open(path);
            Drawable d = Drawable.createFromStream(ims, null);
            stickerViewHolder.img.setImageDrawable(d);
            stickerViewHolder.img.setTag(path);
            stickerViewHolder.img.setOnClickListener(imageClick);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private boolean listAssetFiles(String path) {

        String[] list;
        try {
            list = context.getAssets().list(path);
            if (list.length > 0) {
                // This is a folder
                for (String file : list) {
                    if (!listAssetFiles(path + "/" + file)) {
                        return false;
                    } else {
                        if (file.contains(".")) { // <<-- check if filename has a . then it is a file - hopefully directory names dont have .

                            pathList.add(path + "/" + file);
                            System.out.println("This is a file = " + path + "/" + file);
                        } else {
                            System.out.println("This is a folder = " + path + "/" + file);
                        }
//                        // This is a file
//                        // TODO: add file name to an array list
                    }

                }
            }
        } catch (IOException e) {
            return false;
        }

        return true;

    }

    public void addStickerImages(String folderPath, int stickerCount) {
        pathList.clear();
        listAssetFiles(folderPath);
        this.notifyDataSetChanged();
    }

    private final class ImageClick implements OnClickListener {
        @Override
        public void onClick(View v) {
            String data = (String) v.getTag();
            context.selectedStickerItem(data);
        }
    }

    public class StickerViewHolder extends ViewHolder {
        public ImageView img;

        public StickerViewHolder(View view) {
            super(view);
            img = view.findViewById(R.id.img);

        }
    }
}
