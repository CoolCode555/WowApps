package com.phone.photography.gallery.photovideo.activity;

import static com.customlibraries.loadads.LoadAds.strAdaptiveBannerAdsId;

import androidx.appcompat.app.AppCompatActivity;

import com.customlibraries.adsutils.AdsUtils;
import com.customlibraries.loadads.LoadAds;

public class BaseActivity  extends AppCompatActivity {

    public void  setPreLoadAd(){
        LoadAds.getInstance(BaseActivity.this).loadInterstitialAd(BaseActivity.this,strAdaptiveBannerAdsId);

    }
    public void loadAds(){
        AdsUtils.loadInterstitialAds(BaseActivity.this,false);
//        AdsUtils.showFirstScreenAd(BaseActivity.this);
    }
}
