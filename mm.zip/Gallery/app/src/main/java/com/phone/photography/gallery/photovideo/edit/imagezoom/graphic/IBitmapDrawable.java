package com.phone.photography.gallery.photovideo.edit.imagezoom.graphic;

import android.graphics.Bitmap;

public interface IBitmapDrawable {

	Bitmap getBitmap();
}
