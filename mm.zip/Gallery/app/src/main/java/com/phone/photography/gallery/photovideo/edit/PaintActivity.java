package com.phone.photography.gallery.photovideo.edit;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.customViews.CustomPaintView;
import com.phone.photography.gallery.photovideo.edit.imagezoom.ImageViewTouch;
import com.phone.photography.gallery.photovideo.edit.imagezoom.ImageViewTouchBase;
import com.phone.photography.gallery.photovideo.edit.imagezoom.paint.BrushConfigDialog;
import com.phone.photography.gallery.photovideo.edit.imagezoom.paint.EraserConfigDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class PaintActivity extends AppCompatActivity implements BrushConfigDialog.Properties, EraserConfigDialog.Properties {

    private ImageView img_close;
    private ImageView img_save;
    private ImageView settings;
    private LinearLayout eraserView;
    private LinearLayout brushView;
    private boolean isEraser = false;

    private CustomPaintView custom_paint_view;
    private ImageViewTouch img_set_sticker;

    private BrushConfigDialog brushConfigDialog;
    private EraserConfigDialog eraserConfigDialog;
    private ProgressDialog loadingDialog;

    private static final float MAX_PERCENT = 100;
    private static final float MAX_ALPHA = 255;
    private static final float INITIAL_WIDTH = 50;

    private float brushSize = INITIAL_WIDTH;
    private float eraserSize = INITIAL_WIDTH;
    private float brushAlpha = MAX_ALPHA;
    private int brushColor = Color.WHITE;

    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private String imagePath;
    private Bitmap originalBitmap;
    private String TAG = "PaintActiviy";
    private String outputPath;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        setContentView(R.layout.activity_paint);

        init();
        click();

    }

    private void init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getResources().getColor(R.color.black, this.getTheme()));
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.black));
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.black));
            getWindow().setStatusBarColor(getResources().getColor(R.color.black));
        }
        imagePath = getIntent().getStringExtra("imagePath");
        outputPath=getIntent().getStringExtra("outputPath");

        brushConfigDialog = new BrushConfigDialog();
        brushConfigDialog.setPropertiesChangeListener(this);

        eraserConfigDialog = new EraserConfigDialog();
        eraserConfigDialog.setPropertiesChangeListener(this);

        img_close = findViewById(R.id.img_close);
        img_save = findViewById(R.id.img_save);
        settings = findViewById(R.id.settings);

        img_set_sticker = findViewById(R.id.img_set_sticker);
        custom_paint_view = findViewById(R.id.custom_paint_view);
        img_set_sticker.setDisplayType(ImageViewTouchBase.DisplayType.FIT_TO_SCREEN);
        Glide.with(this).asBitmap().load(imagePath).apply(RequestOptions.skipMemoryCacheOf(true))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE)).into(new CustomTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                img_set_sticker.setImageBitmap(bitmap);
                originalBitmap = bitmap;
            }

            @Override
            public void onLoadCleared(Drawable placeholder) {
            }
        });

        eraserView = findViewById(R.id.eraser_btn);
        brushView = findViewById(R.id.brush_btn);
        custom_paint_view.setWidth(INITIAL_WIDTH);
        custom_paint_view.setColor(Color.WHITE);
        custom_paint_view.setStrokeAlpha(MAX_ALPHA);
        custom_paint_view.setEraserStrokeWidth(INITIAL_WIDTH);
        ((TextView) brushView.findViewById(R.id.txt_brush)).setTextColor(Color.WHITE);

        ((ImageView) eraserView.findViewById(R.id.eraser_icon)).setImageResource(isEraser ?R.drawable.ic_eraser_enabled   :  R.drawable.ic_eraser_disabled);
        ((ImageView) brushView.findViewById(R.id.brush_icon)).setImageResource(isEraser ? R.drawable.ic_brush_white_24dp:  R.drawable.ic_brush_grey_24dp );
        ((TextView) eraserView.findViewById(R.id.txt_eraser)).setTextColor(isEraser ?ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary) :Color.WHITE  );
        ((TextView) brushView.findViewById(R.id.txt_brush)).setTextColor(isEraser ?Color.WHITE  : ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));

        loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);
        loadingDialog.setMessage("Saving");
    }

    private void click() {
        img_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        img_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: save");
                savePaintImage();
            }
        });
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(isEraser ? eraserConfigDialog : brushConfigDialog);
            }
        });
        brushView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEraser) {
                    toggleButtons();
                }
            }
        });
        eraserView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isEraser) {
                    toggleButtons();
                }
            }
        });
    }

    private void toggleButtons() {
        isEraser = !isEraser;
        Log.d(TAG, "toggleButtons: " + isEraser);
        custom_paint_view.setEraser(isEraser);
        ((ImageView) eraserView.findViewById(R.id.eraser_icon)).setImageResource(isEraser ?R.drawable.ic_eraser_enabled   :  R.drawable.ic_eraser_disabled);
        ((ImageView) brushView.findViewById(R.id.brush_icon)).setImageResource(isEraser ? R.drawable.ic_brush_white_24dp:  R.drawable.ic_brush_grey_24dp );
        ((TextView) eraserView.findViewById(R.id.txt_eraser)).setTextColor(isEraser ?ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary) :Color.WHITE  );
        ((TextView) brushView.findViewById(R.id.txt_brush)).setTextColor(isEraser ?Color.WHITE  : ContextCompat.getColor(getApplicationContext(), R.color.colorPrimary));
    }

    private void showDialog(BottomSheetDialogFragment dialogFragment) {
        String tag = dialogFragment.getTag();

        // Avoid IllegalStateException "Fragment already added"
        if (dialogFragment.isAdded()) return;

        dialogFragment.show(getSupportFragmentManager(), tag);

        if (isEraser) {
            updateEraserSize();
        } else {
            updateBrushParams();
        }

    }

    private void updateBrushParams() {
        custom_paint_view.setColor(brushColor);
        custom_paint_view.setWidth(brushSize);
        custom_paint_view.setStrokeAlpha(brushAlpha);
    }

    private void updateEraserSize() {
        custom_paint_view.setEraserStrokeWidth(eraserSize);
    }

    @Override
    public void onColorChanged(int colorCode) {
        brushColor = colorCode;
        updateBrushParams();
    }

    @Override
    public void onOpacityChanged(int opacity) {
        brushAlpha = (opacity / MAX_PERCENT) * MAX_ALPHA;
        updateBrushParams();
    }

    @Override
    public void onBrushSizeChanged(int brushSize) {
        if (isEraser) {
            this.eraserSize = brushSize;
            updateEraserSize();
        } else {
            this.brushSize = brushSize;
            updateBrushParams();
        }
    }

    public void savePaintImage() {
        compositeDisposable.clear();

        Disposable applyPaintDisposable = applyPaint(originalBitmap)
                .flatMap(bitmap -> {
                    if (bitmap == null) {
                        return Single.error(new Throwable("Error occurred while applying paint"));
                    } else {
                        return Single.just(bitmap);
                    }
                })
                .subscribeOn(Schedulers.computation())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(subscriber -> loadingDialog.show())
                .doFinally(() -> loadingDialog.dismiss())
                .subscribe(bitmap -> {
                    custom_paint_view.reset();
                    try {
                        OutputStream fOut = null;
                        File file = new File(outputPath);
                        if (file.exists())
                        {
                            file.delete();// the File to save , append increasing numeric counter to prevent files from getting overwritten.
                        }
                        fOut = new FileOutputStream(file);

                        Bitmap pictureBitmap = bitmap; // obtaining the Bitmap
                        pictureBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut); // saving the Bitmap to a file compressed as a JPEG with 85% compression rate
                        fOut.flush(); // Not really required
                        fOut.close(); // do not forget to close the stream
                        Intent intent = new Intent();
                        intent.putExtra("cropPath", file.getAbsolutePath());
                        setResult(RESULT_OK, intent);
                        finish();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
//                    changeMainBitmap(bitmap, true);
//                    backToMain();
                }, e -> {
                    // Do nothing on error
                });

        compositeDisposable.add(applyPaintDisposable);
    }

    @Override
    public void onDestroy() {
        compositeDisposable.dispose();
        super.onDestroy();
    }

    private Single<Bitmap> applyPaint(Bitmap mainBitmap) {
        return Single.fromCallable(() -> {
            Matrix touchMatrix = img_set_sticker.getImageViewMatrix();

            Bitmap resultBit = Bitmap.createBitmap(mainBitmap).copy(
                    Bitmap.Config.ARGB_8888, true);
            Canvas canvas = new Canvas(resultBit);

            float[] data = new float[9];
            touchMatrix.getValues(data);
            Matrix3 cal = new Matrix3(data);
            Matrix3 inverseMatrix = cal.inverseMatrix();
            Matrix matrix = new Matrix();
            matrix.setValues(inverseMatrix.getValues());

            handleImage(canvas, matrix);

            return resultBit;
        });
    }

    private void handleImage(Canvas canvas, Matrix matrix) {
        float[] f = new float[9];
        matrix.getValues(f);

        int dx = (int) f[Matrix.MTRANS_X];
        int dy = (int) f[Matrix.MTRANS_Y];

        float scale_x = f[Matrix.MSCALE_X];
        float scale_y = f[Matrix.MSCALE_Y];

        canvas.save();
        canvas.translate(dx, dy);
        canvas.scale(scale_x, scale_y);

        if (custom_paint_view.getPaintBit() != null) {
            canvas.drawBitmap(custom_paint_view.getPaintBit(), 0, 0, null);
        }
        canvas.restore();
    }
    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        finish();
    }
}
