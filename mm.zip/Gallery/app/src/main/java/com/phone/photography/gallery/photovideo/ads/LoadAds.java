package com.phone.photography.gallery.photovideo.ads;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.util.Constant;

import java.util.Random;


public class LoadAds {

    private static final String TAG = "LoadAds";
    private static LoadAds loadAds;
    private static boolean isShowAdOnLoad = false;
    private InterstitialAd interstitialAds;
    private Context context;
    AdView adMobAdView;

    public static Boolean isLoadAdMob = false;

    private LoadAds(Context context) {
        this.context = context;
        loadAdMobAd();
    }

    public void loadAdMobAd() {
        if (!isLoadAdMob) {
            // Log.e(TAG,"loadAdMobAd fun call");
            AdRequest adRequest = new AdRequest.Builder().build();

            InterstitialAd.load(context,
                    context.getResources().getString(R.string.interstitial_id),
                    adRequest,
                    new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(@NonNull InterstitialAd mInterstitialAd) {
                            // The mInterstitialAd reference will be null until
                            // an ad is loaded.
                            interstitialAds = mInterstitialAd;
                           Log.e(TAG, "AdMob Loaded");


                            interstitialAds.setFullScreenContentCallback(new FullScreenContentCallback() {
                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    // Called when fullscreen content is dismissed.
                                    Log.d("TAG", "The ad was dismissed.");
                                    isLoadAdMob = false;
                                    // SHOW_OPEN_ADS = true;
                                    loadAdMobAd();
                                }

                                @Override
                                public void onAdShowedFullScreenContent() {
                                    // Called when fullscreen content is shown.
                                    // Make sure to set your reference to null so you don't
                                    // show it a second time.

//                                    Log.d("TAG", "The ad was shown.");
                                }
                            });
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            // Handle the error
                            Log.e(TAG,  "fail--->>>> " + loadAdError.getCode() + " " + loadAdError.getMessage());
                            interstitialAds = null;
                        }
                    });
        }
    }


    public static LoadAds getInstance(Context context) {

        if (loadAds == null) {
            loadAds = new LoadAds(context);
        }
        return loadAds;
    }

    public static LoadAds getInstance(Context context, boolean isShowAdOnLoad) {

        LoadAds.isShowAdOnLoad = isShowAdOnLoad;
        if (loadAds == null) {
            loadAds = new LoadAds(context);
        }
        return loadAds;
    }

    public InterstitialAd getIntersialAd() {
        return interstitialAds;
    }


    public void showFullAd(final int Adfrequency, Activity activity) {
        Random random = new Random();
        int num = random.nextInt(Adfrequency);
        Log.d("Advert random", "Ads num :- " + num);

        if (Adfrequency == 1) {
            if (interstitialAds != null) {
//                            SHOW_OPEN_ADS = false;
                Log.e(TAG, "ads show");
                //  Log.e("ads", "full screen show: " + SHOW_OPEN_ADS);
                interstitialAds.show(activity);

            } else {
//                    Log.e(TAG, "still ads loading");
                loadAdMobAd();
            }
        } else if (num == 1) {
            if (interstitialAds != null) {

//                            SHOW_OPEN_ADS = false;
                Log.e(TAG, "ads show");
                interstitialAds.show(activity);

            } else {
                Log.e(TAG, "still ads loading");

                loadAdMobAd();
            }
        }

    }

    public void showFullAd(Activity activity) {

        if (interstitialAds != null) {
//                        SHOW_OPEN_ADS = false;
//                        Log.e(TAG, "ads show");
            Constant.isShowFirstADs = true;
            interstitialAds.show(activity);

        } else {
            Log.e(TAG, "still ads loading");

            loadAdMobAd();

        }
    }

    public AdView getBannerAdView() {
        return adMobAdView;
    }

    public void loadAdaptiveBanner(Context context, FrameLayout adContainerView) {

        MobileAds.initialize(context, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        adMobAdView = new AdView(context);
        adMobAdView.setAdUnitId(context.getResources().getString(R.string.banner_id));

        adContainerView.removeAllViews();
        adContainerView.addView(adMobAdView);

        AdSize adSize = getAdSize(context, adContainerView);
        adMobAdView.setAdSize(adSize);

        AdRequest adRequest = new AdRequest.Builder().build();
        adMobAdView.loadAd(adRequest);
    }

    public AdSize getAdSize(Context context, FrameLayout adContainerView) {
        // Determine the screen width (less decorations) to use for the ad width.
        Display display = ((Activity) context).getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float density = outMetrics.density;

        float adWidthPixels = adContainerView.getWidth();

        // If the ad hasn't been laid out, default to the full screen width.
        if (adWidthPixels == 0) {
            adWidthPixels = outMetrics.widthPixels;
        }

        int adWidth = (int) (adWidthPixels / density);

        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, adWidth);
    }


}
