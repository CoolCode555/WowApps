package com.phone.photography.gallery.photovideo.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PhotoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    List<Object> photoList = new ArrayList<>();

    private static ClickListener listener;
    private static LongClickListener longClickListener;

    private static final int ITEM_PHOTOS_TYPE = 2;
    public static final int ITEM_HEADER_TYPE = 1;
    public static final int TYPE_AD = 3;

    public PhotoAdapter(Context context1, List<Object> photoList) {
        this.context = context1;
        this.photoList = photoList;
    }

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.listener = clickListener;
    }

    public interface LongClickListener {
        void onItemLongClick(int position, View v);
    }

    public void setOnLongClickListener(LongClickListener longClickListener) {
        this.longClickListener = longClickListener;
    }

    @Override
    public int getItemViewType(int position) {
        try {

            if (photoList.get(position) == null) {
                return TYPE_AD;
            } else if (photoList.get(position) instanceof PhotoData) {
                return ITEM_PHOTOS_TYPE;
            } else {
                return ITEM_HEADER_TYPE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ITEM_PHOTOS_TYPE;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        switch (viewType) {
            case ITEM_HEADER_TYPE:
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_image_header, parent, false);
                viewHolder = new HeaderViewHolder(v);
                break;
            case ITEM_PHOTOS_TYPE:
                View v1 = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_image_grid, parent, false);
                viewHolder = new ImageViewHolder(v1);
                break;

        }
        return Objects.requireNonNull(viewHolder);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        switch (getItemViewType(position)) {

            case ITEM_HEADER_TYPE:
                final HeaderViewHolder viewHolder = (HeaderViewHolder) holder;

                viewHolder.txtPhotoCounter.setVisibility(View.VISIBLE);
                viewHolder.iv_select_all.setVisibility(View.GONE);


                PhotoHeader imageHeader = (PhotoHeader) photoList.get(position);

                SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy");
                Date c = Calendar.getInstance().getTime();
                String formattedDate = format.format(c);

                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DATE, -1);
                cal.getTime();

                Date d2 = cal.getTime();
                String s2 = format.format(d2);

                cal.add(Calendar.DATE, -1);
                Date d3 = cal.getTime();
                String s3 = format.format(d3);

                if (formattedDate.equalsIgnoreCase(imageHeader.getTitle())) {
                    viewHolder.txtDate.setText("Today");

                } else if (s2.equalsIgnoreCase(imageHeader.getTitle())) {
                    viewHolder.txtDate.setText("Yesterday");

                } else if (s3.equalsIgnoreCase(imageHeader.getTitle())) {
                    viewHolder.txtDate.setText("3 days ago");
                } else {
                    viewHolder.txtDate.setText(imageHeader.getTitle());
                }

                viewHolder.ll_select.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
//                        allSelectedImage.OnAllSelectedImage(view, position);
                    }
                });

                break;

            case ITEM_PHOTOS_TYPE:
                final ImageViewHolder imageViewHolder = (ImageViewHolder) holder;
                PhotoData imageList = (PhotoData) photoList.get(position);

                File file = new File(imageList.getFilePath());

                Uri imageUri = Uri.fromFile(file);

                Glide.with(context).load(imageUri).placeholder(R.drawable.ic_image_placeholder).apply(new RequestOptions().diskCacheStrategy(DiskCacheStrategy.ALL)).into(imageViewHolder.ivImg);


                if (imageList.isCheckboxVisible()) {
                    imageViewHolder.iv_un_select.setVisibility(View.VISIBLE);
                    if (imageList.isSelected()) {
                        imageViewHolder.iv_select.setVisibility(View.VISIBLE);


                    } else {
                        imageViewHolder.iv_select.setVisibility(View.GONE);
                    }
                } else {
                    imageViewHolder.iv_select.setVisibility(View.GONE);
                    imageViewHolder.iv_un_select.setVisibility(View.GONE);

                }

                break;
            case TYPE_AD:
                break;

        }
    }

    @Override
    public int getItemCount() {
        return photoList.size();
    }

    public class HeaderViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.txt_date)
        AppCompatTextView txtDate;
        @BindView(R.id.txt_photo_counter)
        AppCompatTextView txtPhotoCounter;
        @BindView(R.id.iv_select_all)
        AppCompatImageView iv_select_all;
        @BindView(R.id.ll_select)
        LinearLayout ll_select;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);

        }


    }

    public class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {

        @BindView(R.id.ivimg)
        AppCompatImageView ivImg;
        @BindView(R.id.iv_select)
        AppCompatImageView iv_select;
        @BindView(R.id.iv_un_select)
        AppCompatImageView iv_un_select;
        @BindView(R.id.ll_main)
        RelativeLayout ll_main;
        @BindView(R.id.ll_select)
        RelativeLayout ll_select;


        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            itemView.setOnClickListener(this);
            itemView.setOnLongClickListener(this);
        }

        @Override
        public void onClick(View view) {

            listener.onItemClick(getAdapterPosition(), view);
        }

        @Override
        public boolean onLongClick(View view) {
            longClickListener.onItemLongClick(getAdapterPosition(), view);
            return true;
        }
    }
}
