package com.phone.photography.gallery.photovideo.fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.activity.AlbumImageActivity;
import com.phone.photography.gallery.photovideo.activity.ImageSelectActivity;
import com.phone.photography.gallery.photovideo.adapter.AlbumAdapter;

import com.phone.photography.gallery.photovideo.model.AlbumCreateEvent;
import com.phone.photography.gallery.photovideo.model.CopyMoveEvent;
import com.phone.photography.gallery.photovideo.model.DeleteEvent;
import com.phone.photography.gallery.photovideo.model.DisplayDeleteEvent;
import com.phone.photography.gallery.photovideo.model.EditImageEvent;
import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;
import com.phone.photography.gallery.photovideo.util.Constant;
import com.phone.photography.gallery.photovideo.service.ImageDataService;
import com.phone.photography.gallery.photovideo.util.RxBus;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class AlbumFragment extends Fragment {

    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @BindView(R.id.lout_no_data)
    LinearLayout loutNoData;

    List<PhotoHeader> folderList = new ArrayList<>();
    AlbumAdapter albumAdapter;



    public AlbumFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.album_fragment, container, false);
        ButterKnife.bind(this, view);

        initViews();

        return view;
    }

    private void initViews() {
        progressBar.setVisibility(View.VISIBLE);
        new Thread(this::getData).start();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        displayDeleteEvent();
        deleteEvent();
        newAlbumEvent();
        copyMoveEvent();
        editPhotoEvent();
    }


    private void getData() {

        try {

            while (true) {
                if (ImageDataService.isComplete) {
                    break;
                }
            }

            Objects.requireNonNull(getActivity()).runOnUiThread(() -> {
                folderList = new ArrayList<>();
                folderList.addAll(ImageDataService.folderList);
                folderList.add(0, null);

                ImageDataService.folderAlbumList = new ArrayList<>();
                ImageDataService.folderAlbumList.addAll(folderList);
                setAdapter();
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setAdapter() {
        progressBar.setVisibility(View.GONE);
        if (folderList != null && folderList.size() != 0) {
            recyclerView.setVisibility(View.VISIBLE);
            loutNoData.setVisibility(View.GONE);

            albumAdapter = new AlbumAdapter(getActivity(), folderList);
            recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 3, RecyclerView.VERTICAL, false));
            recyclerView.setAdapter(albumAdapter);

//            recyclerView.setItemViewCacheSize(folderList.size());

            albumAdapter.setOnItemClickListener(new AlbumAdapter.ClickListener() {
                @Override
                public void onItemClick(int position, View v) {
                    if (folderList.get(position) != null) {
                        Constant.folderData = null;
                        Constant.folderData = folderList.get(position);
                        startActivity(new Intent(getActivity(), AlbumImageActivity.class));

                    } else {

                        try {
                            showCreteAlbumDialog();
                        }catch (Exception e){
                            e.printStackTrace();
                        }


                    }
                }
            });

        } else {
            recyclerView.setVisibility(View.GONE);
            loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void showCreteAlbumDialog() {

        final Dialog dialog = new Dialog(getActivity(), R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_album_create);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);

        EditText edt_name = dialog.findViewById(R.id.edt_name);
        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_ok = dialog.findViewById(R.id.btn_ok);

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = edt_name.getText().toString().trim();
                if (name == null || name.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter album name", Toast.LENGTH_SHORT).show();
                } else {

//                    File file = new File(Environment.getExternalStorageDirectory().getPath() + "/" + getString(R.string.app_name));
                    File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath() + "/" + getString(R.string.app_name));

                    if (!file.exists()) {
                        file.mkdir();
                    }

                    File file1 = new File(file.getPath() + "/" + edt_name.getText().toString());
                    if (!file1.exists()) {
                        file1.mkdir();

                        MediaScannerConnection.scanFile(getActivity(), new String[]{file1.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                                // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                            }
                        });

                        Toast.makeText(getActivity(), "Album created", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(getActivity(), ImageSelectActivity.class);
                        intent.putExtra("Folder", file1.getPath());
                        dialog.dismiss();
                        startActivity(intent);

                    } else {

                        Toast.makeText(getActivity(), "Album name exists, failed to create", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }

                }
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void copyMoveEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(CopyMoveEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<CopyMoveEvent>() {
            @Override
            public void call(CopyMoveEvent event) {
                if (event.getCopyMoveList() != null && event.getCopyMoveList().size() != 0) {
                    ArrayList<String> imageList = new ArrayList<>();
                    imageList = event.getCopyMoveList();

                    if (imageList == null) {
                        imageList = new ArrayList<>();
                    }
                    File file = new File(event.getAlbumPath());

                    if (file.exists()) {
                        ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                        for (int i = 0; i < imageList.size(); i++) {

                            File file1 = new File(imageList.get(i));

                            if (file1.exists()) {
                                PhotoData imagesData = new PhotoData();
                                imagesData.setFilePath(file1.getPath());
                                imagesData.setFileName(file1.getName());
                                imagesData.setFolderName(file.getName());
                                imagesData1.add(imagesData);
                            }
                        }


                        if (imagesData1 != null && imagesData1.size() != 0) {
                            Collections.sort(imagesData1, new Comparator<PhotoData>() {
                                @Override
                                public int compare(PhotoData photoData, PhotoData t1) {
                                    File file1 = new File(photoData.getFilePath());
                                    File file2 = new File(t1.getFilePath());

                                    SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm");
                                    String strDate1 = format.format(file1.lastModified());
                                    String strDate2 = format.format(file2.lastModified());

                                    int compareResult = 0;

                                    Date date1 = null;
                                    Date date2 = null;
                                    try {
                                        date1 = format.parse(strDate1);
                                        date2 = format.parse(strDate2);
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }


                                    compareResult = date2.compareTo(date1);

                                    return compareResult;
                                }
                            });

                            PhotoHeader bucketData = new PhotoHeader();

                            bucketData.setTitle(event.getAlbumName());
                            bucketData.setPhotoList(imagesData1);
                            bucketData.setFolderPath(file.getPath());

//                            folderList.add(1, bucketData);

                            if (folderList != null && folderList.size() != 0) {

                                String albumName = event.getAlbumName();
                                boolean isAdd = false;

                                if (albumName != null && !albumName.equalsIgnoreCase(""))
                                    for (int f = 0; f < folderList.size(); f++) {

                                        if (folderList.get(f) != null)
                                            if (folderList.get(f).getTitle() != null && !folderList.get(f).getTitle().equalsIgnoreCase("")) {
                                                if (folderList.get(f).getTitle().equalsIgnoreCase(albumName)) {
                                                    ArrayList<PhotoData> list = new ArrayList<>();
                                                    list = folderList.get(f).getPhotoList();

                                                    if (imagesData1 == null)
                                                        imagesData1 = new ArrayList<>();

                                                    imagesData1.addAll(list);
                                                    folderList.get(f).setPhotoList(imagesData1);
                                                    isAdd = true;
                                                }
                                            }

                                    }


                                if (!isAdd) {

                                    try {
                                        folderList.add(1, bucketData);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        folderList.add(0, bucketData);
                                    }

                                }

                            } else {
                                assert folderList != null;
                                folderList.add(1, bucketData);
                            }
                            if (albumAdapter != null) {
                                albumAdapter.notifyDataSetChanged();
                            } else {
                                setAdapter();
                            }

                            if (folderList != null && folderList.size() != 0) {
                                recyclerView.setVisibility(View.VISIBLE);
                                loutNoData.setVisibility(View.GONE);
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                loutNoData.setVisibility(View.VISIBLE);
                            }

                            ImageDataService.folderAlbumList = new ArrayList<>();
                            ImageDataService.folderAlbumList.addAll(folderList);

                        }
                    }

                }

                ArrayList<String> deleteList = new ArrayList<>();
                deleteList = event.getDeleteList();
                if (deleteList != null && deleteList.size() != 0)
                    updateDeleteImageData(deleteList);

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void newAlbumEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(AlbumCreateEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<AlbumCreateEvent>() {
            @Override
            public void call(AlbumCreateEvent event) {
                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> imageList = new ArrayList<>();
                    imageList = event.getDeleteList();

                    if (imageList == null) {
                        imageList = new ArrayList<>();
                    }
                    File file = new File(event.getAlbumName());

                    if (file.exists()) {
                        ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                        for (int i = 0; i < imageList.size(); i++) {

                            File file1 = new File(imageList.get(i));

                            if (file1.exists()) {
                                PhotoData imagesData = new PhotoData();
                                imagesData.setFilePath(file1.getPath());
                                imagesData.setFileName(file1.getName());
                                imagesData.setFolderName(file.getName());
                                imagesData1.add(imagesData);
                            }
                        }


                        if (imagesData1 != null && imagesData1.size() != 0) {
                            Collections.sort(imagesData1, new Comparator<PhotoData>() {
                                @Override
                                public int compare(PhotoData photoData, PhotoData t1) {
                                    File file1 = new File(photoData.getFilePath());
                                    File file2 = new File(t1.getFilePath());

                                    SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy HH:mm");
                                    String strDate1 = format.format(file1.lastModified());
                                    String strDate2 = format.format(file2.lastModified());

                                    int compareResult = 0;

                                    Date date1 = null;
                                    Date date2 = null;
                                    try {
                                        date1 = format.parse(strDate1);
                                        date2 = format.parse(strDate2);
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                    }


                                    compareResult = date2.compareTo(date1);

                                    return compareResult;
                                }
                            });

                            PhotoHeader bucketData = new PhotoHeader();

                            bucketData.setTitle(file.getName());
                            bucketData.setPhotoList(imagesData1);
                            bucketData.setFolderPath(file.getPath());

                            folderList.add(1, bucketData);
                            if (albumAdapter != null) {
                                albumAdapter.notifyDataSetChanged();
                            } else {
                                setAdapter();
                            }

                            if (folderList != null && folderList.size() != 0) {
                                recyclerView.setVisibility(View.VISIBLE);
                                loutNoData.setVisibility(View.GONE);
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                loutNoData.setVisibility(View.VISIBLE);
                            }

                            ImageDataService.folderAlbumList = new ArrayList<>();
                            ImageDataService.folderAlbumList.addAll(folderList);

                            ArrayList<String> deleteList = new ArrayList<>();
                            deleteList = event.getDeleteFileList();
                            if (deleteList != null && deleteList.size() != 0)
                                updateDeleteImageData(deleteList);

                        }
                    }

                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void editPhotoEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(EditImageEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<EditImageEvent>() {
            @Override
            public void call(EditImageEvent event) {
                if (event.getImagePath() != null && !event.getImagePath().equalsIgnoreCase("")) {

                    File file = new File(event.getImagePath());

                    SimpleDateFormat format = new SimpleDateFormat("MMM yyyy");
                    String strDate = "";

                    if (file.exists()) {
                        ArrayList<PhotoData> imagesData1 = new ArrayList<>();

                        PhotoData imagesData = new PhotoData();
                        strDate = format.format(file.lastModified());
                        imagesData.setFilePath(file.getPath());
                        imagesData.setFileName(file.getName());
                        imagesData.setFolderName(event.getFolderName());

                        boolean isAdd = false;

                        if (folderList != null && folderList.size() != 0) {

                            for (int f = 0; f < folderList.size(); f++) {

                                if (folderList.get(f) != null)
                                    try {
                                        if (folderList.get(f).getTitle() != null && event.getFolderName() != null)
                                            if (folderList.get(f).getTitle().equalsIgnoreCase(event.getFolderName())) {

                                                ArrayList<PhotoData> photoList = new ArrayList<>();
                                                photoList.addAll(folderList.get(f).getPhotoList());

                                                if (photoList == null) {
                                                    photoList = new ArrayList<>();
                                                }

                                                photoList.add(0, imagesData);

                                                folderList.get(f).setPhotoList(photoList);

                                                isAdd = true;
                                                break;
                                            }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                            }

                        } else {
                            folderList = new ArrayList<>();
                        }

                        if (!isAdd) {
                            PhotoHeader bucketData = new PhotoHeader();

//                            File file1 = new File(Environment.getExternalStorageDirectory().getPath() + "/" + getString(R.string.app_name));
                            File file1 = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath() + "/" + getString(R.string.app_name));

                            imagesData1.add(imagesData);
                            bucketData.setTitle(event.getFolderName());
                            bucketData.setPhotoList(imagesData1);
                            bucketData.setFolderPath(file1.getPath());

                            folderList.add(1, bucketData);

                        }

                        if (albumAdapter != null) {
                            albumAdapter.notifyDataSetChanged();
                        } else {
                            setAdapter();
                        }

                        if (folderList != null && folderList.size() != 0) {
                            recyclerView.setVisibility(View.VISIBLE);
                            loutNoData.setVisibility(View.GONE);
                        } else {
                            recyclerView.setVisibility(View.GONE);
                            loutNoData.setVisibility(View.VISIBLE);
                        }

                        ImageDataService.folderAlbumList = new ArrayList<>();
                        ImageDataService.folderAlbumList.addAll(folderList);
                    }

                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void deleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DeleteEvent>() {
            @Override
            public void call(DeleteEvent event) {

                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> deleteList = new ArrayList<>();
                    deleteList = event.getDeleteList();


                    if (folderList != null && folderList.size() != 0) {


                        for (int d = 0; d < deleteList.size(); d++) {

                            for (int i = 0; i < folderList.size(); i++) {
                                if (folderList.get(i) != null) {
                                    PhotoHeader photoHeader = folderList.get(i);
                                    ArrayList<PhotoData> photoList = new ArrayList<>();
                                    photoList = photoHeader.getPhotoList();

                                    if (photoList != null && photoList.size() != 0) {

                                        for (int p = 0; p < photoList.size(); p++) {

                                            if (deleteList.get(d).equalsIgnoreCase(photoList.get(p).getFilePath())) {

                                                photoList.remove(p);

                                                if (photoList.size() == 0) {

                                                    folderList.remove(i);
                                                    if (i != 0) {
                                                        i--;
                                                    }

                                                } else {
                                                    photoHeader.setPhotoList(photoList);
//                                                folderList.get(i).setPhotoList(photoList);
                                                    folderList.set(i, photoHeader);
                                                }

                                                break;

                                            }

                                        }

                                    }

                                }
                            }
                        }

                        if (albumAdapter != null) {
                            albumAdapter.notifyDataSetChanged();
                        }
                        if (folderList != null && folderList.size() != 0) {
                            recyclerView.setVisibility(View.VISIBLE);
                            loutNoData.setVisibility(View.GONE);
                        } else {
                            recyclerView.setVisibility(View.GONE);
                            loutNoData.setVisibility(View.VISIBLE);
                        }

                        ImageDataService.folderAlbumList = new ArrayList<>();
                        ImageDataService.folderAlbumList.addAll(folderList);
                    }

                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);

    }

    private void displayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DisplayDeleteEvent>() {
            @Override
            public void call(DisplayDeleteEvent event) {

                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> deleteList = new ArrayList<>();
                    deleteList = event.getDeleteList();

                    updateDeleteImageData(deleteList);

                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void updateDeleteImageData(ArrayList<String> deleteList) {
        if (folderList != null && folderList.size() != 0) {

            for (int d = 0; d < deleteList.size(); d++) {

                for (int i = 0; i < folderList.size(); i++) {
                    if (folderList.get(i) != null) {
                        PhotoHeader photoHeader = folderList.get(i);
                        ArrayList<PhotoData> photoList = new ArrayList<>();
                        photoList = photoHeader.getPhotoList();

                        if (photoList != null && photoList.size() != 0) {

                            for (int p = 0; p < photoList.size(); p++) {

                                if (deleteList.get(d).equalsIgnoreCase(photoList.get(p).getFilePath())) {

                                    photoList.remove(p);

                                    if (photoList.size() == 0) {

                                        folderList.remove(i);
                                        if (i != 0) {
                                            i--;
                                        }

                                    } else {
                                        photoHeader.setPhotoList(photoList);
//                                                folderList.get(i).setPhotoList(photoList);
                                        folderList.set(i, photoHeader);
                                    }

                                    break;

                                }

                            }

                        }

                    }
                }
            }

            if (albumAdapter != null) {
                albumAdapter.notifyDataSetChanged();
            }
            if (folderList != null && folderList.size() != 0) {
                recyclerView.setVisibility(View.VISIBLE);
                loutNoData.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                loutNoData.setVisibility(View.VISIBLE);
            }

            ImageDataService.folderAlbumList = new ArrayList<>();
            ImageDataService.folderAlbumList.addAll(folderList);
        }
    }

}
