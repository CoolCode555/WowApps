package com.phone.photography.gallery.photovideo.edit;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.edit.imagezoom.ImageViewTouch;
import com.phone.photography.gallery.photovideo.edit.imagezoom.ImageViewTouchBase;
import com.phone.photography.gallery.photovideo.edit.imagezoom.utils.StickerView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedHashMap;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class StickerActivity extends AppCompatActivity {

    private ImageView img_close;
    private ImageView img_save;
    private TextView txt_theme_name;
    private RecyclerView stickers_list;
    private RecyclerView stickers_type_list;
    private StickerAdapter stickerAdapter;
    private ImageViewTouch img_set_sticker;
    private CompositeDisposable compositeDisposable = new CompositeDisposable();
    private StickerView stickerView;

    private String imagePath;
    private Bitmap mainBitmap;
    private ProgressDialog loadingDialog;
    private String outputPath;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        setContentView(R.layout.activity_sticker);

        init();
        click();

    }

    private void init() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().setStatusBarColor(getResources().getColor(R.color.black, this.getTheme()));
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.black));
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(ContextCompat.getColor(this, R.color.black));
            getWindow().setStatusBarColor(getResources().getColor(R.color.black));
        }
        imagePath = getIntent().getStringExtra("imagePath");
        outputPath = getIntent().getStringExtra("outputPath");
        txt_theme_name = findViewById(R.id.txt_theme_name);

        img_close = findViewById(R.id.img_close);
        img_save = findViewById(R.id.img_save);
        loadingDialog = new ProgressDialog(this);
        loadingDialog.setCancelable(false);
        loadingDialog.setMessage("Saving");
        img_set_sticker = findViewById(R.id.img_set_sticker);
        img_set_sticker.setDisplayType(ImageViewTouchBase.DisplayType.FIT_TO_SCREEN);
        img_set_sticker.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });
        Glide.with(this).asBitmap().load(imagePath).into(new CustomTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                mainBitmap = bitmap;
                img_set_sticker.setImageBitmap(bitmap);
            }

            @Override
            public void onLoadCleared(Drawable placeholder) {
            }
        });
//        Glide.with(this).load(imagePath).apply(RequestOptions.skipMemoryCacheOf(true))
//                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.NONE)).into(img_set_sticker);
        stickerView = findViewById(R.id.sticker_panel);

        stickers_list = findViewById(R.id.stickers_list);
        stickers_list.setHasFixedSize(true);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        stickers_list.setLayoutManager(mLayoutManager);
        stickers_list.setAdapter(new StickerTypeAdapter(this));

        stickers_type_list = findViewById(R.id.stickers_type_list);
        stickers_type_list.setHasFixedSize(true);
        LinearLayoutManager stickerListLayoutManager = new LinearLayoutManager(getApplicationContext());
        stickerListLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        stickers_type_list.setLayoutManager(stickerListLayoutManager);
        stickerAdapter = new StickerAdapter(this);
        stickers_type_list.setAdapter(stickerAdapter);

    }

    private void click() {
        img_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (stickers_type_list.getVisibility() == View.VISIBLE) {
                    stickers_list.setVisibility(View.VISIBLE);
                    stickers_type_list.setVisibility(View.GONE);
                    txt_theme_name.setText("Sticker");
                } else {
                    onBackPressed();
                }
            }
        });
        img_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Disposable saveStickerDisposable = applyStickerToImage(mainBitmap)
                        .subscribeOn(Schedulers.computation())
                        .observeOn(AndroidSchedulers.mainThread())
                        .doOnSubscribe(subscriber -> loadingDialog.show())
                        .doFinally(() -> loadingDialog.dismiss())
                        .subscribe(bitmap -> {
                            if (bitmap == null) {
                                return;
                            }

                            stickerView.clear();
                            try {
//                                String path = Environment.getExternalStorageDirectory().toString();
                                OutputStream fOut = null;
                                File file = new File(outputPath);
                                if (file.exists()) {
                                    file.delete();// the File to save , append increasing numeric counter to prevent files from getting overwritten.
                                }
                                fOut = new FileOutputStream(file);

                                Bitmap pictureBitmap = bitmap; // obtaining the Bitmap
                                pictureBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut); // saving the Bitmap to a file compressed as a JPEG with 85% compression rate
                                fOut.flush(); // Not really required
                                fOut.close(); // do not forget to close the stream
                                Intent intent = new Intent();
                                intent.putExtra("cropPath", file.getAbsolutePath());
                                setResult(RESULT_OK, intent);
                                finish();
                            } catch (Exception e) {
                            }
//                            activity.changeMainBitmap(bitmap, true);
//                            backToMain();
                        }, e -> {
                            Toast.makeText(getApplicationContext(), "save eror", Toast.LENGTH_SHORT).show();
                        });

                compositeDisposable.add(saveStickerDisposable);

            }
        });
    }

    @Override
    public void onPause() {
        compositeDisposable.clear();
        super.onPause();
    }

    @Override
    public void onDestroy() {
//        tryRecycleFilterBitmap();
        compositeDisposable.dispose();
        super.onDestroy();
    }

    private void tryRecycleFilterBitmap() {
        if (mainBitmap != null && (!mainBitmap.isRecycled())) {
            mainBitmap.recycle();
        }
    }

    private Single<Bitmap> applyStickerToImage(Bitmap mainBitmap) {
        return Single.fromCallable(() -> {
            Matrix touchMatrix = img_set_sticker.getImageViewMatrix();

            Bitmap resultBitmap = Bitmap.createBitmap(mainBitmap).copy(
                    Bitmap.Config.ARGB_8888, true);
            Canvas canvas = new Canvas(resultBitmap);

            float[] data = new float[9];
            touchMatrix.getValues(data);
            Matrix3 cal = new Matrix3(data);
            Matrix3 inverseMatrix = cal.inverseMatrix();
            Matrix m = new Matrix();
            m.setValues(inverseMatrix.getValues());
            handleImage(canvas, m);
            return resultBitmap;
        });
    }

    private void handleImage(Canvas canvas, Matrix m) {
        LinkedHashMap<Integer, StickerItem> addItems = stickerView.getBank();
        for (Integer id : addItems.keySet()) {
            StickerItem item = addItems.get(id);
            item.matrix.postConcat(m);
            canvas.drawBitmap(item.bitmap, item.matrix, null);
        }
    }

    public void swipToStickerDetails(String path, int stickerCount) {
        String[] list;
        try {
            list = getAssets().list(path);
            if (list.length > 0) {
                stickerCount = list.length;
            }
        } catch (Exception e) {
        }
//        listAssetFiles("sticker/gesture");
        stickers_list.setVisibility(View.GONE);
        stickers_type_list.setVisibility(View.VISIBLE);
        String text = String.valueOf(path.split("/")[1].charAt(0)).toUpperCase() + path.split("/")[1].subSequence(1, path.split("/")[1].length());
        txt_theme_name.setText(text);
        stickerAdapter.addStickerImages(path, stickerCount);
//        flipper.showNext();
    }

    public void selectedStickerItem(String path) {
        InputStream ims = null;
        try {
            Log.d("TAG", "onBindViewHolder: " + path);
            ims = getAssets().open(path);
            Drawable d = Drawable.createFromStream(ims, null);
            stickerView.addBitImage(((BitmapDrawable) d).getBitmap());
        } catch (Exception e) {
        }
//        int imageKey = getResources().getIdentifier(path, "drawable", getContext().getPackageName());
//        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), imageKey);
//        stickerView.addBitImage(bitmap);
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        finish();
    }
}
