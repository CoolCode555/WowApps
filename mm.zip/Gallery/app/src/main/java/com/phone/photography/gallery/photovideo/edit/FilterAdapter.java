package com.phone.photography.gallery.photovideo.edit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.phone.photography.gallery.photovideo.R;


public class FilterAdapter extends RecyclerView.Adapter<FilterAdapter.MyViewHolder> {
    private static final int DEFAULT_TYPE = 1;

    private String[] filters;
    private String[] filterImages;
    private Context context;
    private OnItemClickListner onItemClickListner;

    public void setListner(OnItemClickListner listner){
        onItemClickListner=listner;
    }

    public FilterAdapter( Context context) {
        super();
        this.context = context;
        filters = context.getResources().getStringArray(R.array.iamutkarshtiwari_github_io_ananas_filters);
        filterImages = context.getResources().getStringArray(R.array.iamutkarshtiwari_github_io_ananas_filter_drawable_list);
    }

    @Override
    public int getItemCount() {
        return filterImages.length;
    }

    @Override
    public int getItemViewType(int position) {
        return DEFAULT_TYPE;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.item_filter, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int pos) {
        String name = filters[pos];
        holder.filter_name.setText(name);

        String imageUrl = "drawable/" + filterImages[pos];
        int imageKey = context.getResources().getIdentifier(imageUrl, "drawable", context.getPackageName());
        holder.filter_image.setImageDrawable(context.getResources().getDrawable(imageKey));

        holder.filter_image.setTag(pos);
        holder.filter_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onItemClickListner!=null){
                    onItemClickListner.onItemClickListner(pos);
                }
            }
        });
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView filter_image;
        public TextView filter_name;

        public MyViewHolder(View view) {
            super(view);
            filter_image = view.findViewById(R.id.filter_image);
            filter_name = view.findViewById(R.id.filter_name);

        }
    }
}
