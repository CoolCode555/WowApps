package com.phone.photography.gallery.photovideo.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;


import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.service.ImageDataService;
import com.phone.photography.gallery.photovideo.service.VideoDataService;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class PermissionActivity extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.txt_dec)
    AppCompatTextView txtDec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (android.os.Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        setContentView(R.layout.activity_permission);
        ButterKnife.bind(this);

        intView();
    }


    private void intView() {

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("   " + getResources().getString(R.string.app_name));

        if (isPermissionGranted()) {
            showHomeScreen();
        }
        txtDec.setText(getResources().getString(R.string.permission_txt1) + " " + getResources().getString(R.string.app_name) + " " + getResources().getString(R.string.permission_txt2));
    }

    private void showHomeScreen() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            startForegroundService(new Intent(PermissionActivity.this, ImageDataService.class));
//            startForegroundService(new Intent(PermissionActivity.this, VideoDataService.class));
//        }else {
            startService(new Intent(PermissionActivity.this, ImageDataService.class));
            startService(new Intent(PermissionActivity.this, VideoDataService.class));
//        }

//        Utils.getImageData(PermissionActivity.this);
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
        finish();
    }

    @OnClick(R.id.btn_allow)
    public void onViewClicked() {

       /* if (Build.VERSION.SDK_INT >= 30) {

            boolean permission = false;
            permission = Environment.isExternalStorageManager();

            if (!permission) {
                String packageName = getPackageName();
                Uri uri = Uri.parse("package:" + packageName);
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri), 30);
            } else {
                showHomeScreen();
            }

        } else {*/
        if (isStoragePermissionGranted()) {
            showHomeScreen();
        }
//        }
    }


    public boolean isPermissionGranted() {
        boolean permission = true;
      /*  if (Build.VERSION.SDK_INT >= 30) {
            permission = Environment.isExternalStorageManager();

            return permission;
        } else */
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(PermissionActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

                return true;
            } else {

                return false;
            }
        } else { //permission is automatically granted on sdk<23 upon installation

            return true;
        }
    }

    public boolean isStoragePermissionGranted() {
        boolean permission = true;
        if (Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(PermissionActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

                return true;
            } else {
                GetStorage_Permission();
                return false;
            }
        } else { //permission is automatically granted on sdk<23 upon installation

            return true;
        }


    }


    private void GetStorage_Permission() {

        List<String> permissionsNeeded = new ArrayList<String>();
        final List<String> permissionsList = new ArrayList<String>();

        if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            permissionsNeeded.add("Read Storage");

        if (!addPermission(permissionsList, Manifest.permission.READ_EXTERNAL_STORAGE))
            permissionsNeeded.add("Read Storage");

        if (permissionsList.size() > 0) {
            if (permissionsNeeded.size() > 0) {
                // Need Rationale
                for (int i = 0; i < 1; i++)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), 1);
                    }

                return;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), 1);
            }
            return;
        }
    }

    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsList.add(permission);
                // Check for Rationale Option
                if (!shouldShowRequestPermissionRationale(permission))
                    return false;
            }
        }

        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 30) {
            if (Build.VERSION.SDK_INT >= 30) {

               /* boolean permission = false;
                permission = Environment.isExternalStorageManager();
                if (permission) {
                    showHomeScreen();
                }*/
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (permissions.length >= 1)
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    showHomeScreen();
                }
        }
        return;
    }
}
