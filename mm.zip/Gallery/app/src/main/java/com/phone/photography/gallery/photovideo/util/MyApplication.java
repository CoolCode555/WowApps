package com.phone.photography.gallery.photovideo.util;

import android.content.Context;
import android.util.Log;

import androidx.multidex.MultiDexApplication;

import com.customlibraries.loadads.AppOpenManager;
import com.onesignal.OSInAppMessage;
import com.onesignal.OSInAppMessageLifecycleHandler;
import com.onesignal.OSNotification;
import com.onesignal.OneSignal;
import com.phone.photography.gallery.photovideo.R;

import com.yandex.metrica.YandexMetrica;
import com.yandex.metrica.YandexMetricaConfig;

import org.json.JSONObject;
import org.w3c.dom.Text;

public class MyApplication extends MultiDexApplication {

    static Context context;
    private String appMetricakey = "d06ecfa6-8e79-4fc1-bd95-8afb6c03cfd1";
    private String OneSignalkey = "23bb186c-e49b-4e0a-ada9-0e5c06cbde6a";

    public static Context getContext() {
        return context;
    }
    @Override
    public void onCreate() {
        super.onCreate();

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationUtils notiUtils = new NotificationUtils(this);
        }
        new AppOpenManager(this).setAppOpenAdsId(getResources().getString(R.string.app_open_id),getResources().getString(R.string.adx_app_open_id));

//        AdvertiseHandler.getInstance(this);

        YandexMetricaConfig config = YandexMetricaConfig.newConfigBuilder(appMetricakey).build();
        YandexMetrica.activate(getApplicationContext(), config);
        YandexMetrica.enableActivityAutoTracking(this);

//        OneSignal.startInit(this)
//                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
//                .unsubscribeWhenNotificationsAreDisabled(true)
//                .init();


        OSInAppMessageLifecycleHandler handler = new OSInAppMessageLifecycleHandler() {
            @Override
            public void onWillDisplayInAppMessage(OSInAppMessage message) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "MainApplication onWillDisplayInAppMessage");
            }
            @Override
            public void onDidDisplayInAppMessage(OSInAppMessage message) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "MainApplication onDidDisplayInAppMessage");
            }
            @Override
            public void onWillDismissInAppMessage(OSInAppMessage message) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "MainApplication onWillDismissInAppMessage");
            }
            @Override
            public void onDidDismissInAppMessage(OSInAppMessage message) {
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "MainApplication onDidDismissInAppMessage");
            }
        };

        OneSignal.setInAppMessageLifecycleHandler(handler);

        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);

        // OneSignal Initialization
//        String appId = "8d7099a0-7f74-4cbd-bc8e-28820f938c0a";
//        // If cached app id is null use the default, otherwise use cached.
//        if (appId == null) {
//            appId = getString(R.string.onesignal_app_id);
//            SharedPreferenceUtil.cacheOneSignalAppId(this, appId);
//        }
        OneSignal.setAppId(OneSignalkey);
        OneSignal.initWithContext(this);

        OneSignal.setNotificationOpenedHandler(result ->
                OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "OSNotificationOpenedResult result: " + result.toString()));

        OneSignal.setNotificationWillShowInForegroundHandler(notificationReceivedEvent -> {
            OneSignal.onesignalLog(OneSignal.LOG_LEVEL.VERBOSE, "NotificationWillShowInForegroundHandler fired!" +
                    " with notification event: " + notificationReceivedEvent.toString());

            OSNotification notification = notificationReceivedEvent.getNotification();
            JSONObject data = notification.getAdditionalData();

            notificationReceivedEvent.complete(notification);
        });

        OneSignal.unsubscribeWhenNotificationsAreDisabled(true);
        OneSignal.pauseInAppMessages(true);
        OneSignal.setLocationShared(false);

    }

}
