package com.phone.photography.gallery.photovideo.model;

import java.util.ArrayList;

public class PhotoHeader {
    String title,folderPath;

    ArrayList<PhotoData> photoList = new ArrayList<>();

    boolean isSelect = false;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList<PhotoData> getPhotoList() {
        return photoList;
    }

    public void setPhotoList(ArrayList<PhotoData> photoList) {
        this.photoList = photoList;
    }

    public String getFolderPath() {
        return folderPath;
    }

    public void setFolderPath(String folderPath) {
        this.folderPath = folderPath;
    }

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }
}
