package com.phone.photography.gallery.photovideo.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;

import com.alexvasilkov.gestures.views.GestureImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.oncliclk.ImageToolbar;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class DisplayImageAdapter extends PagerAdapter {

    List<PhotoData> imageList = new ArrayList<>();
    Context context;
    LayoutInflater layoutInflater;
    boolean isFirst = false;
    ImageToolbar imageToolbar;

    public DisplayImageAdapter(Context context, List<PhotoData> imageList, ImageToolbar imageToolbar) {
        this.context = context;
        this.imageList = imageList;
        this.imageToolbar = imageToolbar;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return imageList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == (object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        View itemView = layoutInflater.inflate(R.layout.item_full_screen_image, container, false);

        GestureImageView imageView = itemView.findViewById(R.id.iv_display);

        final RequestOptions options = new RequestOptions()
                .diskCacheStrategy(DiskCacheStrategy.ALL).override(900, 900).dontTransform();
        imageView.getController().getSettings()
                .setMaxZoom(6f)
                .setMinZoom(0)
                .setDoubleTapZoom(3f);

        Glide.with(context).setDefaultRequestOptions(options)
                .load(imageList.get(position).getFilePath()).placeholder(ContextCompat.getDrawable(context, R.drawable.ic_image_placeholder))
                .into(imageView);


        imageView.setOnClickListener(v -> imageToolbar.OnImageToolbar(v));

        container.addView(itemView);
        return itemView;
    }

    public Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(),
                matrix, true);
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((RelativeLayout) object);
    }
}
