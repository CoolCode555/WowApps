package com.phone.photography.gallery.photovideo.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class GetImagesUpdate {

    LinkedHashMap<String, ArrayList<PhotoData>> imagesDataPhotoHashMap = new LinkedHashMap<>();
    LinkedHashMap<String, ArrayList<PhotoData>> bucketimagesDataHashMap = new LinkedHashMap<>();

    public GetImagesUpdate(LinkedHashMap<String, ArrayList<PhotoData>> imagesDataPhotoHashMap, LinkedHashMap<String, ArrayList<PhotoData>> bucketimagesDataHashMap) {
        this.imagesDataPhotoHashMap = imagesDataPhotoHashMap;
        this.bucketimagesDataHashMap = bucketimagesDataHashMap;
    }

    public LinkedHashMap<String, ArrayList<PhotoData>> getImagesDataPhotoHashMap() {
        return imagesDataPhotoHashMap;
    }

    public void setImagesDataPhotoHashMap(LinkedHashMap<String, ArrayList<PhotoData>> imagesDataPhotoHashMap) {
        this.imagesDataPhotoHashMap = imagesDataPhotoHashMap;
    }

    public LinkedHashMap<String, ArrayList<PhotoData>> getBucketimagesDataHashMap() {
        return bucketimagesDataHashMap;
    }

    public void setBucketimagesDataHashMap(LinkedHashMap<String, ArrayList<PhotoData>> bucketimagesDataHashMap) {
        this.bucketimagesDataHashMap = bucketimagesDataHashMap;
    }
}
