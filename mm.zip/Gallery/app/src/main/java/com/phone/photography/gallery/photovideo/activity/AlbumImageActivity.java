package com.phone.photography.gallery.photovideo.activity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.customlibraries.adsutils.AdsUtils;
import com.phone.photography.gallery.photovideo.R;
import com.phone.photography.gallery.photovideo.adapter.PhotoAdapter;
import com.phone.photography.gallery.photovideo.adapter.PhotoAlbumAdapter;
import com.phone.photography.gallery.photovideo.adapter.SelectAlbumAdapter;

import com.phone.photography.gallery.photovideo.model.CopyMoveEvent;
import com.phone.photography.gallery.photovideo.model.DeleteEvent;
import com.phone.photography.gallery.photovideo.model.DisplayDeleteEvent;
import com.phone.photography.gallery.photovideo.model.PhotoData;
import com.phone.photography.gallery.photovideo.model.PhotoHeader;
import com.phone.photography.gallery.photovideo.service.ImageDataService;
import com.phone.photography.gallery.photovideo.util.AppUtils;
import com.phone.photography.gallery.photovideo.util.Constant;
import com.phone.photography.gallery.photovideo.util.RxBus;
import com.phone.photography.gallery.photovideo.util.Utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class AlbumImageActivity extends AppCompatActivity {

    @BindView(R.id.iv_back)
    ImageView ivBack;
    @BindView(R.id.txt_title)
    TextView txtTitle;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.progress_bar)
    ProgressBar progressBar;
    @BindView(R.id.lout_no_data)
    LinearLayout loutNoData;

    PhotoHeader folderData;

    List<Object> photoList = new ArrayList<>();
    PhotoAlbumAdapter adapter;
    @BindView(R.id.lout_toolbar)
    RelativeLayout loutToolbar;
    @BindView(R.id.iv_close_select)
    ImageView ivCloseSelect;
    @BindView(R.id.txt_select)
    TextView txtSelect;
    @BindView(R.id.lout_select)
    RelativeLayout loutSelect;
    @BindView(R.id.iv_share)
    ImageView ivShare;
    @BindView(R.id.iv_delete)
    ImageView ivDelete;
    @BindView(R.id.lout_select_bottom)
    LinearLayout loutSelectBottom;
    @BindView(R.id.iv_copy)
    ImageView ivCopy;
    @BindView(R.id.lout_copy)
    LinearLayout loutCopy;
    @BindView(R.id.iv_move)
    ImageView ivMove;
    @BindView(R.id.lout_move)
    LinearLayout loutMove;


    int selected_Item = 0;
    ProgressDialog loadingDialog;


    List<PhotoHeader> folderList = new ArrayList<>();


    ArrayList<String> deleteList;

    private ActivityResultLauncher<IntentSenderRequest> deleteIntentSenderLauncher;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }

        setContentView(R.layout.activity_album_image);

        ButterKnife.bind(this);
        AdsUtils.loadInterstitialAds(AlbumImageActivity.this, true);
        intView();

        loadingDialog = new ProgressDialog(AlbumImageActivity.this);
        loadingDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        loadingDialog.setCancelable(false);
        loadingDialog.setMessage("Delete image...");
        loadingDialog.setCanceledOnTouchOutside(false);


        displayDeleteEvent();
        deleteEvent();
        setDeleteIntentLauncher();
    }

    private void setDeleteIntentLauncher() {
        this.deleteIntentSenderLauncher = registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
//                AdvertiseHandler.getInstance().isNeedOpenAdRequest = false;
                if (result.getResultCode() == Activity.RESULT_OK) {
//                    updateDataOnDelete();
                    updateDeleteImageData(deleteList);
                } else if (result.getResultCode() == Activity.RESULT_CANCELED) {
                    selected_Item = 0;
//                    ((HomeActivity) getActivity()).longClick(true, false, 0, false);
                    setClose();
                }


            }
        });
    }


    private void intView() {
        this.folderData = Constant.folderData;


        if (folderData != null) {
            txtTitle.setText(folderData.getTitle());
            progressBar.setVisibility(View.VISIBLE);
            new Thread(this::getData).start();
        }

        loutCopy.setVisibility(View.VISIBLE);
        loutMove.setVisibility(View.VISIBLE);

        setDialogList();
    }

    private void setDialogList() {
        folderList = new ArrayList<>();
        String currentFolderName = "";
        if (folderData != null) {
            currentFolderName = folderData.getTitle();
        }
        if (ImageDataService.folderAlbumList != null && ImageDataService.folderAlbumList.size() != 0) {
            List<PhotoHeader> list = new ArrayList<>();
            list.addAll(ImageDataService.folderAlbumList);

            for (int i = 0; i < list.size(); i++) {

                if (list.get(i) != null) {
                    if (currentFolderName != null && !currentFolderName.equalsIgnoreCase("") &&
                            list.get(i).getTitle() != null && !list.get(i).getTitle().equalsIgnoreCase("") &&
                            !list.get(i).getTitle().equalsIgnoreCase(currentFolderName)
                            && (list.get(i).getFolderPath().startsWith("/storage/emulated/0/DCIM/") || list.get(i).getFolderPath().startsWith("/storage/emulated/0/Pictures/"))) {

                        PhotoHeader photoHeader = list.get(i);
                        photoHeader.setSelect(false);
                        folderList.add(photoHeader);
                    }
                }

            }

        }

    }


    private void setAdapter() {
        progressBar.setVisibility(View.GONE);

        if (photoList != null && photoList.size() != 0) {
            recyclerView.setVisibility(View.VISIBLE);
            loutNoData.setVisibility(View.GONE);

            GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 4, LinearLayoutManager.VERTICAL, false);
            recyclerView.setLayoutManager(gridLayoutManager);
            photoList.add(0, null);
            adapter = new PhotoAlbumAdapter(AlbumImageActivity.this, photoList);
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(final int position) {
                    if (adapter.getItemViewType(position) == PhotoAdapter.ITEM_HEADER_TYPE || adapter.getItemViewType(position) == PhotoAdapter.TYPE_AD) {
                        return 4;
                    }
                    return 1;
                }
            });
            recyclerView.setAdapter(adapter);

            adapter.setOnItemClickListener(new PhotoAlbumAdapter.ClickListener() {
                @Override
                public void onItemClick(int position, View v) {
                    try {


                        if (photoList.get(position) instanceof PhotoData) {
                            PhotoData imageList = (PhotoData) photoList.get(position);
                            if (imageList.isCheckboxVisible()) {

                                if (imageList.isSelected()) {
                                    imageList.setSelected(false);
                                } else
                                    imageList.setSelected(true);
                                adapter.notifyItemChanged(position);
                                setSelectedFile();

                            } else {
                                int pos = -1;
                                List<PhotoData> dataList = new ArrayList<>();

                                for (int i = 0; i < photoList.size(); i++) {
                                    if (photoList.get(i) instanceof PhotoData) {
                                        dataList.add((PhotoData) photoList.get(i));
                                        if (position == i) {
                                            pos = dataList.size() - 1;
                                        }
                                    }
                                }

                                Constant.displayImageList = new ArrayList<>();
                                Constant.displayImageList.addAll(dataList);
                                Intent intent = new Intent(AlbumImageActivity.this, DisplayImageActivity.class);
                                intent.putExtra("pos", pos);
                                intent.putExtra("IsFavList", false);
                                startActivity(intent);
                                if (!Constant.isShowFirstADs) {
//                                    loadAdsOld.showFullAd(AlbumImageActivity.this);
                                }

                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            adapter.setOnLongClickListener(new PhotoAlbumAdapter.LongClickListener() {
                @Override
                public void onItemLongClick(int position, View v) {
                    try {


                        if (photoList.get(position) instanceof PhotoData) {
                            PhotoData imageList = (PhotoData) photoList.get(position);

                            for (int i = 0; i < photoList.size(); i++) {
                                if (photoList.get(i) != null)

                                    if (photoList.get(i) instanceof PhotoData) {

                                        PhotoData model = (PhotoData) photoList.get(i);
                                        model.setCheckboxVisible(true);

                                    } /*else {
                                    ImageHeader header = (ImageHeader) photoList.get(i);
                                    header.setCheckShow(true);
                                }*/

                            }
                            imageList.setCheckboxVisible(true);
                            imageList.setSelected(true);

                            adapter.notifyDataSetChanged();
                            setSelectedFile();

                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

        } else {
            recyclerView.setVisibility(View.GONE);
            loutNoData.setVisibility(View.VISIBLE);
        }
    }

    @OnClick({R.id.iv_close_select, R.id.iv_share, R.id.iv_delete, R.id.iv_back, R.id.iv_copy, R.id.iv_move})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.iv_close_select:
                setClose();
                break;
            case R.id.iv_share:
                if (selected_Item != 0) {

                    shareImage();
                } else {
                    Toast.makeText(this, "Please select image", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.iv_delete:
                if (selected_Item != 0) {
                    deletePhoto();
                } else {
                    Toast.makeText(this, "Please select image", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.iv_copy:
                showAlbumDialog(view.getId());
                break;
            case R.id.iv_move:
                showAlbumDialog(view.getId());
                break;
        }
    }

    int selectedPos = -1;

    private void showAlbumDialog(int id) {
        if (folderList != null && folderList.size() != 0) {
            selectedPos = 0;
            folderList.get(0).setSelect(true);
        } else {
            selectedPos = -1;
        }

        final Dialog dialog = new Dialog(AlbumImageActivity.this, R.style.WideDialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialog_album_select);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.CENTER);

        TextView btn_cancel = dialog.findViewById(R.id.btn_cancel);
        TextView btn_ok = dialog.findViewById(R.id.btn_ok);
        TextView txt_title = dialog.findViewById(R.id.txt_title);
        RecyclerView albumRecyclerView = dialog.findViewById(R.id.albumRecyclerView);
        LinearLayout lout_no_data = dialog.findViewById(R.id.lout_no_data);

        if (id == R.id.iv_copy) {
            txt_title.setText("Copy to");
        } else
            txt_title.setText("Move to");

        if (folderList != null && folderList.size() != 0) {
            albumRecyclerView.setVisibility(View.VISIBLE);
            lout_no_data.setVisibility(View.GONE);

            SelectAlbumAdapter albumAdapter = new SelectAlbumAdapter(AlbumImageActivity.this, folderList);
            albumRecyclerView.setLayoutManager(new LinearLayoutManager(AlbumImageActivity.this));
            albumRecyclerView.setAdapter(albumAdapter);

            albumAdapter.setOnItemClickListener(new SelectAlbumAdapter.ClickListener() {
                @Override
                public void onItemClick(int position, View v) {
                    if (folderList.get(position) != null) {

                        if (selectedPos != position) {
                            if (selectedPos != -1) {
                                folderList.get(selectedPos).setSelect(false);
                                albumAdapter.notifyItemChanged(selectedPos);
                            }

                            if (folderList.get(position).isSelect()) {
                                folderList.get(position).setSelect(false);
                                albumAdapter.notifyItemChanged(position);
                            } else {
                                folderList.get(position).setSelect(true);
                                albumAdapter.notifyItemChanged(position);
                            }
//                            albumAdapter.notifyDataSetChanged();
                            selectedPos = position;
                        } else {
                            if (folderList.get(position).isSelect()) {
                                folderList.get(position).setSelect(false);
                                albumAdapter.notifyItemChanged(position);
                                selectedPos = -1;
                            } else {
                                folderList.get(position).setSelect(true);
                                selectedPos = position;
                                albumAdapter.notifyItemChanged(position);
                            }
//                            adapter.notifyDataSetChanged();
                        }


                    }
                }
            });

        } else {

            albumRecyclerView.setVisibility(View.GONE);
            lout_no_data.setVisibility(View.VISIBLE);
        }

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedPos == -1) {
                    Toast.makeText(AlbumImageActivity.this, "Please select album", Toast.LENGTH_SHORT).show();
                } else {
                    String folderName = folderList.get(selectedPos).getTitle();
                    String folderpath = folderList.get(selectedPos).getFolderPath();
                    dialog.dismiss();

                    if (id == R.id.iv_copy) {
                        setCopyImage(folderName, folderpath);
                    } else
                        setMoveImage(folderName, folderpath);


                }
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                setDialogList();
            }
        });

        dialog.show();
    }

    String selectFolderPath = "";
    String selectFolderName = "";

    private void setMoveImage(String folderName, String folderPath) {
        selectFolderPath = folderPath;
        selectFolderName = folderName;
        if (loadingDialog != null)
            if (!loadingDialog.isShowing()) {
                loadingDialog.setMessage("Move image...");
                loadingDialog.show();
            }

        new Thread(this::moveImage).start();
    }

    private void setCopyImage(String folderName, String folderPath) {
        selectFolderPath = folderPath;
        selectFolderName = folderName;
        if (loadingDialog != null)
            if (!loadingDialog.isShowing()) {
                loadingDialog.setMessage("Copy image...");
                loadingDialog.show();
            }

        new Thread(this::copyImage).start();


    }

    private void copyImage() {
        ArrayList<String> deleteFileList = new ArrayList<>();
        ArrayList<String> newImageList = new ArrayList<>();

        File file = new File(selectFolderPath);

        if (photoList != null && photoList.size() != 0)
            for (int i = 0; i < photoList.size(); i++) {

                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PhotoData) {

                        PhotoData model = (PhotoData) photoList.get(i);
                        if (model.isSelected()) {
                            model.setSelected(false);
                            File file1 = new File(model.getFilePath());
                            String newPath = file.getPath() + "/" + file1.getName();
                            File fileee = new File(newPath);

                            if (fileee.exists()) {

                                String[] separated = file1.getName().split("\\.");
                                String name = separated[0];
                                String type = separated[1];

                                String newPath2 = file.getPath() + "/" + name + "_" + System.currentTimeMillis() + "." + type;
                                File file2 = new File(newPath2);
                                try {

                                    Constant.copyDirectoryOneLocationToAnotherLocation(AlbumImageActivity.this, file1, file2);
//                                    deleteFileList.add(file1.getPath());
                                    newImageList.add(file2.getPath());

                                } catch (IOException e) {
                                    e.printStackTrace();

                                }
                            } else {
                                try {

                                    Constant.copyDirectoryOneLocationToAnotherLocation(AlbumImageActivity.this, file1, fileee);
//                                    deleteFileList.add(file1.getPath());
                                    newImageList.add(fileee.getPath());
                                } catch (IOException e) {
                                    e.printStackTrace();

                                }
                            }
                        }

                    }
            }

        runOnUiThread(() -> {

            RxBus.getInstance().post(new CopyMoveEvent(newImageList, selectFolderName, selectFolderPath, deleteFileList));

            setClose();
            if (loadingDialog != null)
                if (loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }
            Toast.makeText(this, "Copy image successfully", Toast.LENGTH_SHORT).show();
            setDialogList();
        });
    }

    private void moveImage() {
        ArrayList<String> deleteFileList = new ArrayList<>();
        ArrayList<String> newImageList = new ArrayList<>();

        File from = new File(selectFolderPath);

        if (photoList != null && photoList.size() != 0) {
            for (int i = 0; i < photoList.size(); i++) {

                if (photoList.get(i) != null)
                    if (photoList.get(i) instanceof PhotoData) {

                        PhotoData model = (PhotoData) photoList.get(i);
                        if (model.isSelected()) {
                            File to = new File(model.getFilePath());

                            try {
                                File moveFile = moveFile(to, from);
                                if (moveFile.exists()) {
                                    newImageList.add(moveFile.getPath());
                                    deleteFileList.add(to.getPath());
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            model.setCheckboxVisible(false);
                        }

                    }
            }

            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null)

                    if (photoList.get(i) instanceof PhotoData) {
                        PhotoData model = (PhotoData) photoList.get(i);
                        if (model.isSelected()) {
                            boolean isPre = false, isNext = false;

                            if (i != 0) {
                                if (photoList.get(i - 1) instanceof PhotoHeader) {
                                    isPre = true;
                                } else {
                                    isPre = false;
                                }
                            }

                            if (i < (photoList.size() - 2)) {
                                if (photoList.get(i + 1) instanceof PhotoHeader) {
                                    isNext = true;
                                } else {
                                    isNext = false;
                                }
                            }

                            if (isPre && isNext) {
                                //  objectList.remove(i + 1);
                                photoList.remove(i);
                                photoList.remove(i - 1);

                            } else if (i == (photoList.size() - 1)) {
                                if (isPre) {
                                    photoList.remove(i);
                                    photoList.remove(i - 1);
                                } else {
                                    photoList.remove(i);
                                }
                            } else {
                                photoList.remove(i);
                            }

                            if (i != 0) {
                                i--;
                            }
                        }
                    }
            }

        }


        runOnUiThread(() -> {
            RxBus.getInstance().post(new CopyMoveEvent(newImageList, selectFolderName, selectFolderPath, deleteFileList));

            if (loadingDialog != null)
                if (loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }

            Toast.makeText(this, "Move image successfully", Toast.LENGTH_SHORT).show();

            selected_Item = 0;
            OnSelected(true, false, 0);
            if (adapter != null)
                adapter.notifyDataSetChanged();

            if (photoList != null && photoList.size() != 0) {
                recyclerView.setVisibility(View.VISIBLE);
                loutNoData.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                loutNoData.setVisibility(View.VISIBLE);
            }
            setDialogList();
        });
    }


    private File moveFile(File file, File dir) throws IOException {
        File newFile = new File(dir, file.getName());
        FileChannel outputChannel = null;
        FileChannel inputChannel = null;
        try {
            outputChannel = new FileOutputStream(newFile).getChannel();
            inputChannel = new FileInputStream(file).getChannel();
            inputChannel.transferTo(0, inputChannel.size(), outputChannel);
            inputChannel.close();
            file.delete();
            try {
                FileUtils.deleteDirectory(file);
            } catch (Exception e) {
                e.printStackTrace();
            }

            MediaScannerConnection.scanFile(AlbumImageActivity.this, new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {
                    // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
            });

            MediaScannerConnection.scanFile(AlbumImageActivity.this, new String[]{newFile.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String path, Uri uri) {
                    // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                }
            });

        } finally {
            if (inputChannel != null) inputChannel.close();
            if (outputChannel != null) outputChannel.close();
        }

        return newFile;
    }

    @Override
    public void onBackPressed() {
        if (loutSelect.getVisibility() == View.VISIBLE) {

            setClose();

        } else
            super.onBackPressed();
    }

    private void shareImage() {
        ArrayList<Uri> uris = new ArrayList<>();
        Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);

        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    if (model.isSelected()) {
                        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(model.getFilePath()));
                        uris.add(uri);
                    }

                }
        }

        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(Intent.createChooser(intent, "Share with..."));
    }

    private void setSelectedFile() {
        int selected = 0;

        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    if (model.isSelected()) {
                        selected++;
                    }

                }
        }



        /*if (selected == 0) {

            selectedHome.OnSelected(true, false, selected);
            llBottomOption.setVisibility(View.GONE);
            setClose();
        } else {
            selectedHome.OnSelected(false, true, selected);
            llBottomOption.setVisibility(View.VISIBLE);

        }*/
        if (selected == 0) {

            OnSelected(true, false, selected);
            setClose();
        } else {
            OnSelected(false, true, selected);

        }


//        OnSelected(false, true, selected);

        selected_Item = selected;
    }

    private void getData() {
        LinkedHashMap<String, ArrayList<PhotoData>> bucketimagesDataPhotoHashMap = new LinkedHashMap<>();
        ArrayList<PhotoData> list = new ArrayList<>();
        list = folderData.getPhotoList();

        if (list != null && list.size() != 0) {

            for (int i = 0; i < list.size(); i++) {

                if (list.get(i).getFilePath() != null && !list.get(i).getFilePath().equalsIgnoreCase("")) {

                    File file = new File(list.get(i).getFilePath());
                    if (file.exists()) {
//                    SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy");
                        SimpleDateFormat format = new SimpleDateFormat("MMM yyyy");
                        String strDate = format.format(file.lastModified());

                        PhotoData imagesData = list.get(i);
                        if (bucketimagesDataPhotoHashMap.containsKey(strDate)) {
                            ArrayList<PhotoData> imagesData1 = bucketimagesDataPhotoHashMap.get(strDate);
                            if (imagesData1 == null)
                                imagesData1 = new ArrayList<>();

                            imagesData1.add(imagesData);
                            bucketimagesDataPhotoHashMap.put(strDate, imagesData1);

                        } else {
                            ArrayList<PhotoData> imagesData1 = new ArrayList<>();
                            imagesData1.add(imagesData);
                            bucketimagesDataPhotoHashMap.put(strDate, imagesData1);
                        }
                    }
                }
            }


            Set<String> keys = bucketimagesDataPhotoHashMap.keySet();
            ArrayList<String> listkeys = new ArrayList<>();
            listkeys.addAll(keys);


            for (int i = 0; i < listkeys.size(); i++) {
                ArrayList<PhotoData> imagesData = bucketimagesDataPhotoHashMap.get(listkeys.get(i));

                if (imagesData != null && imagesData.size() != 0) {
                    PhotoHeader bucketData = new PhotoHeader();

                    bucketData.setTitle(listkeys.get(i));
                    bucketData.setPhotoList(imagesData);

                    photoList.add(bucketData);
                    photoList.addAll(imagesData);
                }
            }

        }

        runOnUiThread(() -> {
//            photoList = new ArrayList<>();
//            photoList.addAll(ImageDataService.photoList);
            setAdapter();
        });
    }

    private void setClose() {

        selected_Item = 0;
        setCloseData();
        loutSelect.setVisibility(View.GONE);
        loutSelectBottom.setVisibility(View.GONE);
        loutToolbar.setVisibility(View.VISIBLE);


        if (photoList != null && photoList.size() != 0) {
            recyclerView.setVisibility(View.VISIBLE);
            loutNoData.setVisibility(View.GONE);
        } else {
            recyclerView.setVisibility(View.GONE);
            loutNoData.setVisibility(View.VISIBLE);
        }
    }

    private void setCloseData() {
        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    model.setCheckboxVisible(false);
                    model.setSelected(false);

                }

                       /* if (photoList.get(i) instanceof ImageHeader) {

                            ImageHeader model = (ImageHeader) photoList.get(i);
                            model.setAllSelecte(false);
                            model.setCheckShow(false);

                        }*/

        }
        if (adapter != null)
            adapter.notifyDataSetChanged();
        selected_Item = 0;
    }


    private void displayDeleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DisplayDeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DisplayDeleteEvent>() {
            @Override
            public void call(DisplayDeleteEvent event) {

                if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                    ArrayList<String> deleteList = new ArrayList<>();
                    deleteList = event.getDeleteList();


                    if (photoList != null && photoList.size() != 0) {

                        for (int d = 0; d < deleteList.size(); d++) {

                            for (int i = 0; i < photoList.size(); i++) {

                                if (photoList.get(i) instanceof PhotoData) {
                                    PhotoData model = (PhotoData) photoList.get(i);

                                    if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {

                                        boolean isPre = false, isNext = false;

                                        if (i != 0) {
                                            if (photoList.get(i - 1) instanceof PhotoHeader) {
                                                isPre = true;
                                            } else {
                                                isPre = false;
                                            }
                                        }

                                        if (i < (photoList.size() - 2)) {
                                            if (photoList.get(i + 1) instanceof PhotoHeader) {
                                                isNext = true;
                                            } else {
                                                isNext = false;
                                            }
                                        }

                                        if (isPre && isNext) {
                                            //  objectList.remove(i + 1);
                                            photoList.remove(i);
                                            photoList.remove(i - 1);

                                        } else if (i == (photoList.size() - 1)) {
                                            if (isPre) {
                                                photoList.remove(i);
                                                photoList.remove(i - 1);
                                            } else {
                                                photoList.remove(i);
                                            }
                                        } else {
                                            photoList.remove(i);
                                        }

                                        if (i != 0) {
                                            i--;
                                        }

                                        if (d == deleteList.size() - 1) {
                                            break;
                                        }

                                    }

                                }

                            }
                        }

                        if (adapter != null) {
                            adapter.notifyDataSetChanged();
                        }
                        if (photoList != null && photoList.size() != 0) {
                            recyclerView.setVisibility(View.VISIBLE);
                            loutNoData.setVisibility(View.GONE);
                        } else {
                            recyclerView.setVisibility(View.GONE);
                            loutNoData.setVisibility(View.VISIBLE);
                        }
                    }

                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    private void deleteEvent() {
        Subscription subscription = RxBus.getInstance().toObservable(DeleteEvent.class).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).distinctUntilChanged().subscribe(new Action1<DeleteEvent>() {
            @Override
            public void call(DeleteEvent event) {

                if (event.getPos() != -1) {
                    if (event.getDeleteList() != null && event.getDeleteList().size() != 0) {
                        ArrayList<String> deleteList = new ArrayList<>();
                        deleteList = event.getDeleteList();


                        if (photoList != null && photoList.size() != 0) {

                            for (int d = 0; d < deleteList.size(); d++) {

                                for (int i = 0; i < photoList.size(); i++) {

                                    if (photoList.get(i) instanceof PhotoData) {
                                        PhotoData model = (PhotoData) photoList.get(i);

                                        if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {

                                            boolean isPre = false, isNext = false;

                                            if (i != 0) {
                                                if (photoList.get(i - 1) instanceof PhotoHeader) {
                                                    isPre = true;
                                                } else {
                                                    isPre = false;
                                                }
                                            }

                                            if (i < (photoList.size() - 2)) {
                                                if (photoList.get(i + 1) instanceof PhotoHeader) {
                                                    isNext = true;
                                                } else {
                                                    isNext = false;
                                                }
                                            }

                                            if (isPre && isNext) {
                                                //  objectList.remove(i + 1);
                                                photoList.remove(i);
                                                photoList.remove(i - 1);

                                            } else if (i == (photoList.size() - 1)) {
                                                if (isPre) {
                                                    photoList.remove(i);
                                                    photoList.remove(i - 1);
                                                } else {
                                                    photoList.remove(i);
                                                }
                                            } else {
                                                photoList.remove(i);
                                            }

                                            if (i != 0) {
                                                i--;
                                            }

                                            if (d == deleteList.size() - 1) {
                                                break;
                                            }

                                        }

                                    }

                                }
                            }

                            if (adapter != null) {
                                adapter.notifyDataSetChanged();
                            }
                            if (photoList != null && photoList.size() != 0) {
                                recyclerView.setVisibility(View.VISIBLE);
                                loutNoData.setVisibility(View.GONE);
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                loutNoData.setVisibility(View.VISIBLE);
                            }
                        }

                    }
                }

            }
        }, new Action1<Throwable>() {
            @Override
            public void call(Throwable throwable) {
            }
        });
        RxBus.getInstance().addSubscription(this, subscription);
    }

    public void OnSelected(boolean isShowToolbar, boolean isShowSelected, int selected) {
        if (isShowToolbar) {
            loutToolbar.setVisibility(View.VISIBLE);
        } else {
            loutToolbar.setVisibility(View.GONE);
        }

        if (isShowSelected) {
            loutSelect.setVisibility(View.VISIBLE);
            loutSelectBottom.setVisibility(View.VISIBLE);
        } else {
            loutSelect.setVisibility(View.GONE);
            loutSelectBottom.setVisibility(View.GONE);
        }
        txtSelect.setText(selected + " Selected");

    }

    private void updateDeleteImageData(ArrayList<String> deleteList) {
        if (photoList != null && photoList.size() != 0) {

            for (int d = 0; d < deleteList.size(); d++) {

                for (int i = 0; i < photoList.size(); i++) {

                    if (photoList.get(i) instanceof PhotoData) {
                        PhotoData model = (PhotoData) photoList.get(i);

                        if (model.getFilePath().equalsIgnoreCase(deleteList.get(d))) {

                            boolean isPre = false, isNext = false;

                            if (i != 0) {
                                if (photoList.get(i - 1) instanceof PhotoHeader) {
                                    isPre = true;
                                } else {
                                    isPre = false;
                                }
                            }

                            if (i < (photoList.size() - 2)) {
                                if (photoList.get(i + 1) instanceof PhotoHeader) {
                                    isNext = true;
                                } else {
                                    isNext = false;
                                }
                            }

                            if (isPre && isNext) {
                                //  objectList.remove(i + 1);
                                photoList.remove(i);
                                photoList.remove(i - 1);

                            } else if (i == (photoList.size() - 1)) {
                                if (isPre) {
                                    photoList.remove(i);
                                    photoList.remove(i - 1);
                                } else {
                                    photoList.remove(i);
                                }
                            } else {
                                photoList.remove(i);
                            }

                            if (i != 0) {
                                i--;
                            }

                            if (d == deleteList.size() - 1) {
                                break;
                            }

                        }

                    }

                }
            }

            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }

            ImageDataService.photoAlbumList = new ArrayList<>();
            ImageDataService.photoAlbumList.addAll(photoList);

            if (photoList != null && photoList.size() != 0) {
                recyclerView.setVisibility(View.VISIBLE);
                loutNoData.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                loutNoData.setVisibility(View.VISIBLE);
            }
        }

        runOnUiThread(() -> {
            if (loadingDialog != null)
                if (loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }


            RxBus.getInstance().post(new DeleteEvent(1, deleteList));
            selected_Item = 0;
            OnSelected(true, false, 0);
            if (adapter != null)
                adapter.notifyDataSetChanged();

            if (photoList != null && photoList.size() != 0) {
                recyclerView.setVisibility(View.VISIBLE);
                loutNoData.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                loutNoData.setVisibility(View.VISIBLE);
            }
            Toast.makeText(AlbumImageActivity.this, "Delete image successfully", Toast.LENGTH_SHORT).show();
        });

    }


    private void deletePhoto() {

        deleteList = new ArrayList<>();

        if (Utils.isVersionQAbove()) {

            Log.e("TAG1017", "deletePhoto: " + "isVersionQAbove");
            for (int i = 0; i < photoList.size(); i++) {
                if (photoList.get(i) != null) {
                    if (photoList.get(i) instanceof PhotoData) {

                        PhotoData photoData = (PhotoData) photoList.get(i);
//                        PictureData photoData = (PictureData) pictures.get(i);
                        if (photoData.isSelected()) {
                            deleteList.add(photoData.getFilePath());
                        } else {
                            photoData.setCheckboxVisible(false);
                        }
                    }
                }
            }
            Log.e("TAG1091", "deletePhoto: " + deleteList.size());
            IntentSender deleteFileOnAboveQ = AppUtils.deleteFileOnAboveQ(deleteList, AlbumImageActivity.this);
            if (deleteFileOnAboveQ != null) {
                deleteIntentSenderLauncher.launch(new IntentSenderRequest.Builder(deleteFileOnAboveQ).build());
                return;
            }
            Toast.makeText(AlbumImageActivity.this, "Error...!", Toast.LENGTH_SHORT).show();

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(AlbumImageActivity.this);
            builder.setMessage("Are you sure want to delete it?");
            builder.setCancelable(false);
            builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
//                    if (loadingDialog != null)
//                        if (!loadingDialog.isShowing()) {
//                            loadingDialog.setMessage("Delete image...");
//                            loadingDialog.show();
//                        }

//                    new Thread(this::deletePhoto).start();
                    deletePhoto1();

                }
            });
            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.show();
        }


    }




    public void deletePhoto1() {

        ArrayList<String> deleteList = new ArrayList<>();
        for (int i = 0; i < photoList.size(); i++) {

            if (photoList.get(i) != null)
                if (photoList.get(i) instanceof PhotoData) {

                    PhotoData model = (PhotoData) photoList.get(i);
                    if (model.isSelected()) {

                        File file = new File(model.getFilePath());
                        Uri deleteUrl = FileProvider.getUriForFile(AlbumImageActivity.this, getApplicationContext().getPackageName() + ".provider", file);
                        ContentResolver contentResolver = getContentResolver();
                        contentResolver.delete(deleteUrl, null, null);

                        try {
                            file.delete();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        try {
                            FileUtils.deleteDirectory(file);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        MediaScannerConnection.scanFile(AlbumImageActivity.this, new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                                // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                            }
                        });


                        deleteList.add(file.getPath());
                    } else {

                        model.setCheckboxVisible(false);
                    }

                }
        }

        for (int i = 0; i < photoList.size(); i++) {
            if (photoList.get(i) != null)

                if (photoList.get(i) instanceof PhotoData) {
                    PhotoData model = (PhotoData) photoList.get(i);
                    if (model.isSelected()) {
                        boolean isPre = false, isNext = false;

                        if (i != 0) {
                            if (photoList.get(i - 1) instanceof PhotoHeader) {
                                isPre = true;
                            } else {
                                isPre = false;
                            }
                        }

                        if (i < (photoList.size() - 2)) {
                            if (photoList.get(i + 1) instanceof PhotoHeader) {
                                isNext = true;
                            } else {
                                isNext = false;
                            }
                        }

                        if (isPre && isNext) {
                            //  objectList.remove(i + 1);
                            photoList.remove(i);
                            photoList.remove(i - 1);

                        } else if (i == (photoList.size() - 1)) {
                            if (isPre) {
                                photoList.remove(i);
                                photoList.remove(i - 1);
                            } else {
                                photoList.remove(i);
                            }
                        } else {
                            photoList.remove(i);
                        }

                        if (i != 0) {
                            i--;
                        }
                    }
                }
        }

        runOnUiThread(() -> {
            if (loadingDialog != null)
                if (loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }


            RxBus.getInstance().post(new DeleteEvent(1, deleteList));
            selected_Item = 0;
            OnSelected(true, false, 0);
            if (adapter != null)
                adapter.notifyDataSetChanged();

            if (photoList != null && photoList.size() != 0) {
                recyclerView.setVisibility(View.VISIBLE);
                loutNoData.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                loutNoData.setVisibility(View.VISIBLE);
            }
            Toast.makeText(AlbumImageActivity.this, "Delete image successfully", Toast.LENGTH_SHORT).show();
        });


    }

    private void showDeleteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(AlbumImageActivity.this, R.style.AppCompatAlert);
        builder.setMessage("Are you sure do you want to delete it?");
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (loadingDialog != null)
                    if (!loadingDialog.isShowing()) {
                        loadingDialog.setMessage("Delete image...");
                        loadingDialog.show();
                    }

                new Thread(this::deletePhoto).start();
            }

            private void deletePhoto() {

                ArrayList<String> deleteList = new ArrayList<>();
                for (int i = 0; i < photoList.size(); i++) {

                    if (photoList.get(i) != null)
                        if (photoList.get(i) instanceof PhotoData) {

                            PhotoData model = (PhotoData) photoList.get(i);
                            if (model.isSelected()) {

                                File file = new File(model.getFilePath());
                                Uri deleteUrl = FileProvider.getUriForFile(AlbumImageActivity.this, getApplicationContext().getPackageName() + ".provider", file);
                                ContentResolver contentResolver = getContentResolver();
                                contentResolver.delete(deleteUrl, null, null);

                                try {
                                    FileUtils.deleteDirectory(file);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                MediaScannerConnection.scanFile(AlbumImageActivity.this, new String[]{file.getPath()}, null, new MediaScannerConnection.OnScanCompletedListener() {
                                    public void onScanCompleted(String path, Uri uri) {
                                        // Log.i("ExternalStorage", "Scanned " + path + ":" + uri);
                                    }
                                });

                                deleteList.add(file.getPath());
                            } else {

                                model.setCheckboxVisible(false);
                            }

                        }
                }

                for (int i = 0; i < photoList.size(); i++) {
                    if (photoList.get(i) != null)

                        if (photoList.get(i) instanceof PhotoData) {
                            PhotoData model = (PhotoData) photoList.get(i);
                            if (model.isSelected()) {
                                boolean isPre = false, isNext = false;

                                if (i != 0) {
                                    if (photoList.get(i - 1) instanceof PhotoHeader) {
                                        isPre = true;
                                    } else {
                                        isPre = false;
                                    }
                                }

                                if (i < (photoList.size() - 2)) {
                                    if (photoList.get(i + 1) instanceof PhotoHeader) {
                                        isNext = true;
                                    } else {
                                        isNext = false;
                                    }
                                }

                                if (isPre && isNext) {
                                    //  objectList.remove(i + 1);
                                    photoList.remove(i);
                                    photoList.remove(i - 1);

                                } else if (i == (photoList.size() - 1)) {
                                    if (isPre) {
                                        photoList.remove(i);
                                        photoList.remove(i - 1);
                                    } else {
                                        photoList.remove(i);
                                    }
                                } else {
                                    photoList.remove(i);
                                }

                                if (i != 0) {
                                    i--;
                                }
                            }
                        }
                }

                runOnUiThread(() -> {
                    if (loadingDialog != null)
                        if (loadingDialog.isShowing()) {
                            loadingDialog.dismiss();
                        }


                    RxBus.getInstance().post(new DeleteEvent(1, deleteList));
                    selected_Item = 0;
                    OnSelected(true, false, 0);
                    if (adapter != null)
                        adapter.notifyDataSetChanged();

                    if (photoList != null && photoList.size() != 0) {
                        recyclerView.setVisibility(View.VISIBLE);
                        loutNoData.setVisibility(View.GONE);
                    } else {
                        recyclerView.setVisibility(View.GONE);
                        loutNoData.setVisibility(View.VISIBLE);
                    }
                    Toast.makeText(AlbumImageActivity.this, "Delete image successfully", Toast.LENGTH_SHORT).show();
                });

            }

        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }

}